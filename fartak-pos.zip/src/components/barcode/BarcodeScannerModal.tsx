import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Modal } from '../../design-system/components/Modal';
import { Button } from '../../design-system/components/Button';
import { Input } from '../../design-system/components/Input';
import { Product } from '../../types';
import { scannerService } from '../../services/barcodeScanner';
import {
  Barcode,
  Scan,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Camera,
  CameraOff,
  Flashlight,
  RefreshCw,
  Zap,
  Check,
  ShoppingBag,
  Layers,
} from 'lucide-react';
import { toPersianDigits, formatToman } from '../../design-system/tokens';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onProductScanned: (product: Product) => void;
}

interface ScannedSessionItem {
  product: Product;
  scannedAt: string;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  products = [],
  onProductScanned,
}) => {
  const [manualCode, setManualCode] = useState('');
  const [lastScannedProduct, setLastScannedProduct] = useState<Product | null>(null);
  const [notFoundCode, setNotFoundCode] = useState<string | null>(null);
  const [sessionScans, setSessionScans] = useState<ScannedSessionItem[]>([]);
  const [isSuccessFlashing, setIsSuccessFlashing] = useState(false);

  // Camera stream states
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [isFlashOn, setIsFlashOn] = useState<boolean>(false);
  const [hasTorch, setHasTorch] = useState<boolean>(false);
  const [hasNativeBarcodeDetector, setHasNativeBarcodeDetector] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const manualInputRef = useRef<HTMLInputElement | null>(null);
  const scanLoopTimeoutRef = useRef<number | null>(null);
  const lastScannedTimeRef = useRef<number>(0);
  const lastScannedCodeRef = useRef<string>('');

  // Handle Scanning Barcode Logic
  const handleScan = useCallback(
    (barcode: string) => {
      const trimmed = barcode.trim();
      if (!trimmed) return;

      const now = Date.now();
      // Cooldown for identical barcode (1.4 seconds) to prevent duplicate triggers
      // Different barcodes scan instantaneously with zero cooldown!
      if (
        trimmed === lastScannedCodeRef.current &&
        now - lastScannedTimeRef.current < 1400
      ) {
        return;
      }

      lastScannedCodeRef.current = trimmed;
      lastScannedTimeRef.current = now;

      const found = (products || []).find(
        (p) => p.barcode === trimmed || p.sku.toLowerCase() === trimmed.toLowerCase()
      );

      if (found) {
        scannerService.playBeep('success');
        setLastScannedProduct(found);
        setNotFoundCode(null);

        // Flash green viewfinder feedback
        setIsSuccessFlashing(true);
        setTimeout(() => setIsSuccessFlashing(false), 350);

        // Immediately add to sales list!
        onProductScanned(found);

        // Record in continuous session scan log
        const timeStr = new Date().toLocaleTimeString('fa-IR', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        });
        setSessionScans((prev) => [{ product: found, scannedAt: timeStr }, ...prev.slice(0, 15)]);
      } else {
        scannerService.playBeep('error');
        setNotFoundCode(trimmed);
        setLastScannedProduct(null);
      }

      // Immediately refocus input ready for next physical or hardware scan
      setTimeout(() => {
        manualInputRef.current?.focus();
      }, 50);
    },
    [products, onProductScanned]
  );

  // Setup Continuous Camera Barcode Detection Loop
  const runDetectionLoop = useCallback(() => {
    if (!videoRef.current || !isCameraActive) return;

    const video = videoRef.current;
    if (video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA) {
      if ('BarcodeDetector' in window) {
        try {
          const detector = new (window as any).BarcodeDetector({
            formats: ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_128', 'code_39', 'qr_code'],
          });

          detector
            .detect(video)
            .then((barcodes: Array<{ rawValue: string }>) => {
              if (barcodes && barcodes.length > 0) {
                const rawCode = barcodes[0].rawValue;
                if (rawCode) {
                  handleScan(rawCode);
                }
              }
            })
            .catch(() => {});
        } catch {
          // BarcodeDetector error or not supported
        }
      }
    }

    // Schedule next detection frame (continuous rapid scanning)
    scanLoopTimeoutRef.current = window.setTimeout(() => {
      runDetectionLoop();
    }, 120);
  }, [isCameraActive, handleScan]);

  // Start continuous loop when camera is active
  useEffect(() => {
    if (isCameraActive) {
      runDetectionLoop();
    }
    return () => {
      if (scanLoopTimeoutRef.current) {
        clearTimeout(scanLoopTimeoutRef.current);
        scanLoopTimeoutRef.current = null;
      }
    };
  }, [isCameraActive, runDetectionLoop]);

  // Start Camera
  const startCamera = async () => {
    setCameraError(null);
    try {
      if (typeof window !== 'undefined' && 'BarcodeDetector' in window) {
        setHasNativeBarcodeDetector(true);
      }

      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        if (streamRef.current) {
          streamRef.current.getTracks().forEach((t) => t.stop());
        }

        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: facingMode },
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
          audio: false,
        });

        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(() => {});
        }
        setIsCameraActive(true);

        // Check torch capability
        const track = stream.getVideoTracks()[0];
        const capabilities = (track as unknown as { getCapabilities?: () => { torch?: boolean } })?.getCapabilities?.();
        setHasTorch(!!capabilities?.torch);
      } else {
        setCameraError('دوربین در این مرورگر پشتیبانی نمی‌شود.');
      }
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      console.warn('Camera stream error:', errorMsg);
      setCameraError('دسترسی به دوربین برقرار نشد. می‌توانید با بارکدخوان فیزیکی یا ثبت دستی اسکن کنید.');
      setIsCameraActive(false);
    }
  };

  // Stop Camera
  const stopCamera = () => {
    if (scanLoopTimeoutRef.current) {
      clearTimeout(scanLoopTimeoutRef.current);
      scanLoopTimeoutRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
    setIsFlashOn(false);
  };

  // Toggle Torch
  const toggleFlash = async () => {
    if (!streamRef.current) return;
    const track = streamRef.current.getVideoTracks()[0];
    try {
      const nextState = !isFlashOn;
      await (track as unknown as { applyConstraints: (c: unknown) => Promise<void> }).applyConstraints({
        advanced: [{ torch: nextState }],
      });
      setIsFlashOn(nextState);
    } catch {
      // ignore
    }
  };

  // Switch between front/rear camera
  const switchCamera = () => {
    setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'));
  };

  useEffect(() => {
    if (isOpen) {
      startCamera();
      // Auto-focus manual input to also capture external USB/Bluetooth scanners
      setTimeout(() => {
        manualInputRef.current?.focus();
      }, 200);
    } else {
      stopCamera();
      setLastScannedProduct(null);
      setNotFoundCode(null);
      setManualCode('');
      setSessionScans([]);
    }

    return () => {
      stopCamera();
    };
  }, [isOpen, facingMode]);

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    handleScan(manualCode);
    setManualCode('');
    manualInputRef.current?.focus();
  };

  const quickSamples = (products || []).slice(0, 6);

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="اسکنر سریع بارکد کالا (دوربین موبایل و بارکدخوان)"
      size="md"
      footer={
        <div className="flex items-center justify-between w-full">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span className="text-[11px] text-slate-500 font-medium">
              اسکن پیوسته فعال • دوربین برای اسکن بعدی آماده است
            </span>
          </div>
          <Button variant="primary" size="sm" onClick={onClose}>
            اتمام و بازگشت به فاکتور
          </Button>
        </div>
      }
    >
      <div className="space-y-4">
        {/* Camera Viewfinder Box */}
        <div
          className={`relative bg-slate-950 rounded-2xl h-60 flex flex-col items-center justify-center overflow-hidden border-2 transition-all duration-200 shadow-inner ${
            isSuccessFlashing
              ? 'border-emerald-500 shadow-[0_0_25px_rgba(16,185,129,0.4)]'
              : 'border-slate-800'
          }`}
        >
          {/* Live Video Element */}
          <video
            ref={videoRef}
            playsInline
            muted
            autoPlay
            className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-300 ${
              isCameraActive ? 'opacity-90' : 'opacity-0'
            }`}
          />

          {/* Flash Feedback Overlay on Successful Scan */}
          {isSuccessFlashing && (
            <div className="absolute inset-0 bg-emerald-500/20 z-25 pointer-events-none animate-in fade-in duration-100" />
          )}

          {/* Fallback Camera HUD Overlay if camera is inactive */}
          {!isCameraActive && (
            <div className="text-center z-10 px-4 space-y-2 pointer-events-none">
              <div className="w-12 h-12 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center mx-auto mb-1">
                <Scan className="w-6 h-6 animate-pulse" />
              </div>
              <p className="text-white text-xs font-bold">
                حسگر اسکنر بارکد آماده دریافت بارکد کالا
              </p>
              <p className="text-slate-400 text-[11px]">
                دوربین را روشن کرده یا بارکدخوان فیزیکی را به سمت کالا بگیرید
              </p>
            </div>
          )}

          {/* Viewfinder Target Frame Corners */}
          <div
            className={`absolute inset-x-8 inset-y-6 border rounded-xl pointer-events-none flex flex-col justify-between p-2 z-10 transition-colors ${
              isSuccessFlashing
                ? 'border-emerald-400/80 bg-emerald-500/10'
                : 'border-blue-400/40'
            }`}
          >
            <div className="flex justify-between">
              <div
                className={`w-6 h-6 border-t-3 border-r-3 rounded-tr-lg transition-colors ${
                  isSuccessFlashing ? 'border-emerald-400' : 'border-blue-400'
                }`}
              />
              <div
                className={`w-6 h-6 border-t-3 border-l-3 rounded-tl-lg transition-colors ${
                  isSuccessFlashing ? 'border-emerald-400' : 'border-blue-400'
                }`}
              />
            </div>

            {/* In-viewfinder Continuous Scanning Badge */}
            <div className="text-center">
              <span className="bg-black/60 backdrop-blur-xs text-[10px] text-white px-3 py-1 rounded-full font-mono border border-white/10 shadow-xs">
                بارکد را در این کادر قرار دهید
              </span>
            </div>

            <div className="flex justify-between">
              <div
                className={`w-6 h-6 border-b-3 border-r-3 rounded-br-lg transition-colors ${
                  isSuccessFlashing ? 'border-emerald-400' : 'border-blue-400'
                }`}
              />
              <div
                className={`w-6 h-6 border-b-3 border-l-3 rounded-bl-lg transition-colors ${
                  isSuccessFlashing ? 'border-emerald-400' : 'border-blue-400'
                }`}
              />
            </div>
          </div>

          {/* Animated Red Laser Scanning Beam */}
          <div className="absolute inset-x-10 h-0.5 bg-rose-500 shadow-[0_0_16px_3px_rgba(244,63,94,0.95)] z-20 animate-bounce" />

          {/* Camera Controls Bar (Overlaid on top of camera feed) */}
          <div className="absolute top-2.5 inset-x-3 flex items-center justify-between z-30 pointer-events-auto">
            <div className="flex items-center gap-1.5 bg-black/70 backdrop-blur-xs px-2.5 py-1 rounded-lg text-[10px] text-white font-medium border border-white/10">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>{isCameraActive ? 'اسکن دوربین فعال' : 'اسکنر دستی'}</span>
              {hasNativeBarcodeDetector && (
                <span className="bg-emerald-600 text-[9px] px-1.5 py-0.2 rounded text-white font-bold">
                  سریع (AI)
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5">
              {hasTorch && (
                <button
                  type="button"
                  onClick={toggleFlash}
                  className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors cursor-pointer ${
                    isFlashOn
                      ? 'bg-amber-500 text-black shadow-sm'
                      : 'bg-black/70 text-white hover:bg-black/90'
                  }`}
                  title="چراغ قوه"
                >
                  <Flashlight className="w-3.5 h-3.5" />
                </button>
              )}

              <button
                type="button"
                onClick={switchCamera}
                className="w-7 h-7 rounded-lg bg-black/70 hover:bg-black/90 text-white flex items-center justify-center cursor-pointer transition-colors"
                title="تغییر دوربین جلو / پشت"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={isCameraActive ? stopCamera : startCamera}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-colors ${
                  isCameraActive
                    ? 'bg-rose-600/90 text-white hover:bg-rose-700'
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                }`}
              >
                {isCameraActive ? (
                  <>
                    <CameraOff className="w-3 h-3" />
                    <span>توقف</span>
                  </>
                ) : (
                  <>
                    <Camera className="w-3 h-3" />
                    <span>روشن</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Bottom Live Scan Counter on Viewfinder */}
          {sessionScans.length > 0 && (
            <div className="absolute bottom-2 inset-x-3 flex items-center justify-between z-30 pointer-events-none">
              <span className="bg-emerald-600/90 backdrop-blur-xs text-white text-[10px] font-bold px-2.5 py-1 rounded-lg shadow-sm flex items-center gap-1">
                <Check className="w-3 h-3" />
                تعداد اسکن شده: {toPersianDigits(sessionScans.length)} قلم
              </span>
            </div>
          )}
        </div>

        {/* Camera Info / Warning message if failed */}
        {cameraError && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-2.5 text-[11px] text-amber-800 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>{cameraError}</span>
          </div>
        )}

        {/* Scan Status Alert (Success feedback banner) */}
        {lastScannedProduct && (
          <div className="bg-emerald-50 border-2 border-emerald-300 rounded-xl p-3 flex items-center justify-between text-xs text-emerald-900 animate-in fade-in duration-150">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                <Check className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold text-emerald-950 flex items-center gap-1.5">
                  <span>{lastScannedProduct.name}</span>
                  <span className="bg-emerald-200 text-emerald-800 text-[10px] px-1.5 py-0.2 rounded font-mono font-bold">
                    به فاکتور اضافه شد
                  </span>
                </div>
                <div className="text-[11px] text-emerald-700 mt-0.5">
                  قیمت واحد: {formatToman(lastScannedProduct.retailPrice)} • موجودی: {toPersianDigits(lastScannedProduct.currentStock)} {lastScannedProduct.unit}
                </div>
              </div>
            </div>
            <span className="font-mono text-emerald-800 font-bold bg-white px-2 py-1 rounded-lg border border-emerald-200 text-xs">
              {toPersianDigits(lastScannedProduct.barcode)}
            </span>
          </div>
        )}

        {notFoundCode && (
          <div className="bg-rose-50 border border-rose-200 rounded-xl p-3 flex items-center justify-between text-xs text-rose-900 animate-in fade-in duration-150">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
              <div>
                <div className="font-bold">کالایی با این بارکد در انبار تعریف نشده است!</div>
                <div className="text-[10px] text-rose-700 font-mono mt-0.5">بارکد اسکن شده: {notFoundCode}</div>
              </div>
            </div>
          </div>
        )}

        {/* Manual Barcode Input Form (Keeps focus automatically) */}
        <form onSubmit={handleManualSubmit} className="flex gap-2">
          <Input
            ref={manualInputRef}
            placeholder="ورود دستی بارکد یا کد کالا (آماده اسکن)..."
            value={manualCode}
            onChange={(e) => setManualCode(e.target.value)}
            startIcon={<Barcode className="w-4 h-4 text-slate-400" />}
          />
          <Button type="submit" variant="primary" size="sm" className="shrink-0 cursor-pointer">
            ثبت اسکن
          </Button>
        </form>

        {/* Real-time Session Scanned Items Stream */}
        {sessionScans.length > 0 && (
          <div className="bg-slate-50 rounded-2xl p-3 border border-slate-200/80 space-y-2">
            <div className="flex items-center justify-between text-[11px] text-slate-600 font-bold">
              <span className="flex items-center gap-1">
                <ShoppingBag className="w-3.5 h-3.5 text-blue-600" />
                اقلام اسکن شده در این مرحله ({toPersianDigits(sessionScans.length)} مورد):
              </span>
              <span className="text-[10px] text-slate-400 font-normal">آماده برای اسکن کدهای بعدی</span>
            </div>

            <div className="max-h-28 overflow-y-auto divide-y divide-slate-100 text-xs">
              {sessionScans.map((item, idx) => (
                <div key={idx} className="py-1.5 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono text-slate-400">#{toPersianDigits(idx + 1)}</span>
                    <span className="font-bold text-slate-800">{item.product.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-sans font-bold text-blue-600">
                      {formatToman(item.product.retailPrice)}
                    </span>
                    <span className="text-[9px] font-mono text-slate-400">{item.scannedAt}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Quick Test Barcode Pills for instant testing */}
        <div className="space-y-2 pt-2 border-t border-slate-100">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-600 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              تست سریع اسکن و افزودن فوری کالاها به فاکتور:
            </span>
            <span className="text-[10px] text-slate-400 font-mono">اسکن بدون بستن پنجره</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {quickSamples.map((product) => (
              <button
                key={product.id}
                type="button"
                onClick={() => handleScan(product.barcode)}
                className="text-right p-2 rounded-xl border border-slate-200 bg-white hover:bg-blue-50 hover:border-blue-300 transition-all cursor-pointer group shadow-2xs"
              >
                <div className="font-bold text-[11px] text-slate-800 group-hover:text-blue-700 truncate">
                  {product.name}
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-400 mt-0.5">
                  <span className="font-mono">{toPersianDigits(product.barcode)}</span>
                  <span className="font-bold text-slate-700 font-sans">{formatToman(product.retailPrice)}</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </Modal>
  );
};
