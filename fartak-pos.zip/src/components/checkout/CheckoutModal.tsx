import React, { useState } from 'react';
import { Modal } from '../../design-system/components/Modal';
import { Button } from '../../design-system/components/Button';
import { Input } from '../../design-system/components/Input';
import { CartItem, Customer, PaymentMethod, Sale, StoreInfo } from '../../types';
import { formatToman, toPersianDigits } from '../../design-system/tokens';
import { CreditCard, Banknote, UserCheck, Split, CheckCircle2, User } from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  customers: Customer[];
  store: StoreInfo;
  onSuccess: (sale: Sale) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  customers,
  store,
  onSuccess,
}) => {
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('کارتخوان');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [discountAmount, setDiscountAmount] = useState<number>(0);
  const [cashReceived, setCashReceived] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Totals calculation
  const subtotal = cartItems.reduce(
    (sum, item) => sum + (item.unitPrice - item.discount) * item.quantity,
    0
  );
  const tax = Math.round((subtotal * store.taxRate) / 100);
  const finalTotal = Math.max(0, subtotal + tax - discountAmount);

  const selectedCustomer = customers.find((c) => c.id === selectedCustomerId);
  const cashNum = parseInt(cashReceived.replace(/,/g, ''), 10) || 0;
  const changeDue = Math.max(0, cashNum - finalTotal);

  const handleCompleteSale = () => {
    setIsSubmitting(true);

    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const dateStr = '۱۴۰۳/۰۶/۲۵';

    setTimeout(() => {
      const sale: Omit<Sale, 'id' | 'invoiceNumber'> = {
        date: dateStr,
        time: timeStr,
        items: cartItems.map((item) => ({
          productId: item.product.id,
          productName: item.product.name,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          total: (item.unitPrice - item.discount) * item.quantity,
        })),
        subtotal,
        discount: discountAmount,
        tax,
        finalTotal,
        paymentMethod,
        customerId: selectedCustomer?.id,
        customerName: selectedCustomer?.name,
        cashierName: 'علی محمدی',
      };

      // Import StorageService dynamically
      import('../../services/storage').then(({ StorageService }) => {
        const createdSale = StorageService.addSale(sale);
        setIsSubmitting(false);
        onSuccess(createdSale);
      });
    }, 400);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="تسویه حساب و پرداخت فاکتور"
      size="lg"
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={isSubmitting}>
            انصراف
          </Button>
          <Button
            variant="primary"
            size="lg"
            onClick={handleCompleteSale}
            loading={isSubmitting}
            icon={<CheckCircle2 className="w-5 h-5" />}
          >
            تکمیل و ثبت فاکتور ({formatToman(finalTotal)})
          </Button>
        </>
      }
    >
      <div className="space-y-6">
        {/* Total Banner */}
        <div className="bg-blue-50/80 border border-blue-100 rounded-2xl p-4 flex items-center justify-between">
          <div>
            <span className="text-xs text-blue-700 font-bold block">مبلغ قابل پرداخت نهایی:</span>
            <span className="text-2xl font-black text-blue-900 tracking-tight">
              {formatToman(finalTotal)}
            </span>
          </div>
          <div className="text-left text-xs text-slate-500 space-y-0.5">
            <div>جمع اقلام: {formatToman(subtotal)}</div>
            {discountAmount > 0 && <div className="text-emerald-600">تخفیف: {formatToman(discountAmount)} -</div>}
            {tax > 0 && <div>مالیات: {formatToman(tax)} +</div>}
          </div>
        </div>

        {/* Payment Methods Grid */}
        <div className="space-y-2">
          <label className="block text-xs font-bold text-slate-700">روش پرداخت:</label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <button
              type="button"
              onClick={() => setPaymentMethod('کارتخوان')}
              className={`p-3.5 rounded-xl border text-right transition-all flex flex-col items-start gap-2 cursor-pointer ${
                paymentMethod === 'کارتخوان'
                  ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                  : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <CreditCard className="w-5 h-5" />
              <div>
                <div className="font-bold text-xs">دستگاه کارتخوان</div>
                <div className={`text-[10px] ${paymentMethod === 'کارتخوان' ? 'text-blue-100' : 'text-slate-400'}`}>
                  ارسال خودکار به POS
                </div>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMethod('نقدی')}
              className={`p-3.5 rounded-xl border text-right transition-all flex flex-col items-start gap-2 cursor-pointer ${
                paymentMethod === 'نقدی'
                  ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                  : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <Banknote className="w-5 h-5" />
              <div>
                <div className="font-bold text-xs">پرداخت نقدی</div>
                <div className={`text-[10px] ${paymentMethod === 'نقدی' ? 'text-blue-100' : 'text-slate-400'}`}>
                  محاسبه باقی‌مانده پول
                </div>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMethod('اعتباری')}
              className={`p-3.5 rounded-xl border text-right transition-all flex flex-col items-start gap-2 cursor-pointer ${
                paymentMethod === 'اعتباری'
                  ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                  : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <UserCheck className="w-5 h-5" />
              <div>
                <div className="font-bold text-xs">اعتباری / دفتری</div>
                <div className={`text-[10px] ${paymentMethod === 'اعتباری' ? 'text-blue-100' : 'text-slate-400'}`}>
                  ثبت در حساب مشتری
                </div>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMethod('ترکیبی')}
              className={`p-3.5 rounded-xl border text-right transition-all flex flex-col items-start gap-2 cursor-pointer ${
                paymentMethod === 'ترکیبی'
                  ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                  : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <Split className="w-5 h-5" />
              <div>
                <div className="font-bold text-xs">پرداخت ترکیبی</div>
                <div className={`text-[10px] ${paymentMethod === 'ترکیبی' ? 'text-blue-100' : 'text-slate-400'}`}>
                  نقد + کارت
                </div>
              </div>
            </button>
          </div>
        </div>

        {/* Cash Drawer Calculator when Cash selected */}
        {paymentMethod === 'نقدی' && (
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
            <div className="flex flex-col sm:flex-row gap-3 items-center">
              <div className="flex-1 w-full">
                <Input
                  label="مبلغ دریافتی از مشتری (تومان)"
                  placeholder="مثال: ۳۵۰,۰۰۰"
                  value={cashReceived}
                  onChange={(e) => setCashReceived(e.target.value)}
                  type="text"
                />
              </div>
              <div className="w-full sm:w-auto flex items-center gap-1.5 pt-4">
                {[finalTotal, Math.ceil(finalTotal / 50000) * 50000, Math.ceil(finalTotal / 100000) * 100000].map(
                  (val, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setCashReceived(val.toLocaleString('fa-IR'))}
                      className="text-xs bg-white border border-slate-200 hover:border-blue-500 rounded-lg px-2.5 py-1.5 text-slate-700 font-sans cursor-pointer transition-all"
                    >
                      {formatToman(val)}
                    </button>
                  )
                )}
              </div>
            </div>

            {cashNum > 0 && (
              <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-200">
                <span className="font-medium text-slate-600">باقی‌مانده پول مشتری (پول خرد):</span>
                <span className={`font-bold text-sm ${changeDue >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                  {changeDue >= 0 ? formatToman(changeDue) : 'مبلغ دریافتی کمتر از فاکتور است!'}
                </span>
              </div>
            )}
          </div>
        )}

        {/* Customer Selection */}
        <div className="space-y-1.5">
          <label className="block text-xs font-bold text-slate-700 flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 text-blue-600" />
            <span>انتخاب مشتری (اختیاری):</span>
          </label>
          <select
            value={selectedCustomerId}
            onChange={(e) => setSelectedCustomerId(e.target.value)}
            className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 cursor-pointer"
          >
            <option value="">مشتری عمومی (حضوری)</option>
            {customers.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} ({toPersianDigits(c.phone)}) - مانده حساب: {formatToman(c.creditBalance)}
              </option>
            ))}
          </select>
          {paymentMethod === 'اعتباری' && !selectedCustomerId && (
            <p className="text-[11px] text-amber-600 font-medium">
              * برای پرداخت اعتباری، لطفاً نام مشتری را از لیست بالا انتخاب فرمایید.
            </p>
          )}
        </div>

        {/* Quick Discount */}
        <div className="space-y-1.5">
          <label className="block text-xs font-bold text-slate-700">تخفیف کلی فاکتور (تومان):</label>
          <div className="flex items-center gap-2">
            <input
              type="number"
              value={discountAmount || ''}
              onChange={(e) => setDiscountAmount(Math.max(0, parseInt(e.target.value, 10) || 0))}
              placeholder="۰ تومان"
              className="flex-1 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600"
            />
            <button
              type="button"
              onClick={() => setDiscountAmount(Math.round(subtotal * 0.05))}
              className="px-3 py-2 text-xs font-bold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-xl transition-all cursor-pointer"
            >
              ۵٪
            </button>
            <button
              type="button"
              onClick={() => setDiscountAmount(Math.round(subtotal * 0.1))}
              className="px-3 py-2 text-xs font-bold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-xl transition-all cursor-pointer"
            >
              ۱۰٪
            </button>
          </div>
        </div>
      </div>
    </Modal>
  );
};
