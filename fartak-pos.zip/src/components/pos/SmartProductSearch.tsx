import React, { useState, useRef, useEffect } from 'react';
import { Product } from '../../types';
import { formatToman, toPersianDigits } from '../../design-system/tokens';
import { scannerService } from '../../services/barcodeScanner';
import {
  Search,
  Barcode,
  Sparkles,
  Plus,
  Boxes,
  Check,
  Zap,
  Tag,
  AlertTriangle,
  X,
} from 'lucide-react';

interface SmartProductSearchProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onOpenScanner: () => void;
  placeholder?: string;
}

export const SmartProductSearch: React.FC<SmartProductSearchProps> = ({
  products,
  onSelectProduct,
  onOpenScanner,
  placeholder = 'جستجوی هوشمند کالا (نام، بارکد، کد SKU)...',
}) => {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [filterMode, setFilterMode] = useState<'all' | 'bestsellers' | 'lowstock' | 'discount'>('all');

  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Filter products based on search query and active filter chip
  const filteredResults = React.useMemo(() => {
    let result = products || [];

    if (filterMode === 'lowstock') {
      result = result.filter((p) => p.currentStock <= p.minStock);
    } else if (filterMode === 'discount') {
      // Mock discount or items on sale
      result = result.filter((p) => p.retailPrice < 30000);
    } else if (filterMode === 'bestsellers') {
      result = (result || []).slice(0, 8);
    }

    if (!query.trim()) {
      return (result || []).slice(0, 6);
    }

    const q = query.trim().toLowerCase();
    return (result || [])
      .filter((p) => {
        const nameMatch = p.name.toLowerCase().includes(q);
        const barcodeMatch = p.barcode.includes(q);
        const skuMatch = p.sku.toLowerCase().includes(q);
        const categoryMatch = p.categoryId?.toLowerCase().includes(q);
        return nameMatch || barcodeMatch || skuMatch || categoryMatch;
      })
      .slice(0, 8);
  }, [products, query, filterMode]);

  // Handle outside click to close dropdown
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Handle keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!isOpen) {
      if (e.key === 'ArrowDown' || e.key === 'Enter') {
        setIsOpen(true);
      }
      return;
    }

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % Math.max(1, filteredResults.length));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) =>
        prev <= 0 ? filteredResults.length - 1 : prev - 1
      );
    } else if (e.key === 'Enter') {
      e.preventDefault();
      // Check exact barcode first
      const exactBarcode = products.find(
        (p) => p.barcode === query.trim() || p.sku.toLowerCase() === query.trim().toLowerCase()
      );
      if (exactBarcode) {
        onSelectProduct(exactBarcode);
        setQuery('');
        setIsOpen(false);
        return;
      }

      if (filteredResults.length > 0 && selectedIndex < filteredResults.length) {
        onSelectProduct(filteredResults[selectedIndex]);
        setQuery('');
        setIsOpen(false);
      }
    } else if (e.key === 'Escape') {
      setIsOpen(false);
    }
  };

  const handlePickProduct = (product: Product) => {
    onSelectProduct(product);
    setQuery('');
    setIsOpen(false);
    inputRef.current?.focus();
  };

  return (
    <div ref={containerRef} className="relative w-full">
      {/* Search Input Box */}
      <div className="relative flex items-center">
        <input
          ref={inputRef}
          type="text"
          placeholder={placeholder}
          value={query}
          onFocus={() => setIsOpen(true)}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
            setSelectedIndex(0);
          }}
          onKeyDown={handleKeyDown}
          className="w-full pl-16 pr-9 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/15 transition-all shadow-2xs"
        />

        {/* Search Icon */}
        <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />

        {/* Clear & Barcode actions */}
        <div className="absolute left-2.5 top-1/2 -translate-y-1/2 flex items-center gap-1.5">
          {query && (
            <button
              type="button"
              onClick={() => {
                setQuery('');
                setIsOpen(false);
              }}
              className="text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}

          <button
            type="button"
            onClick={onOpenScanner}
            className="w-6.5 h-6.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-600 flex items-center justify-center cursor-pointer transition-colors"
            title="باز کردن اسکنر بارکد"
          >
            <Barcode className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Floating Smart Suggestions Dropdown */}
      {isOpen && (
        <div className="absolute top-full mt-1.5 inset-x-0 bg-white rounded-xl border border-slate-200 shadow-xl z-50 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-150">
          {/* Filter Chips Bar */}
          <div className="flex items-center gap-1.5 p-2 bg-slate-50/80 border-b border-slate-100 overflow-x-auto text-[11px] font-bold">
            <span className="text-slate-400 text-[10px] shrink-0 flex items-center gap-1 mr-1">
              <Sparkles className="w-3 h-3 text-blue-600" />
              فیلتر هوشمند:
            </span>
            <button
              type="button"
              onClick={() => setFilterMode('all')}
              className={`px-2 py-0.5 rounded-md transition-colors cursor-pointer shrink-0 ${
                filterMode === 'all'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              همه
            </button>
            <button
              type="button"
              onClick={() => setFilterMode('bestsellers')}
              className={`px-2 py-0.5 rounded-md transition-colors cursor-pointer shrink-0 ${
                filterMode === 'bestsellers'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              پرفروش‌ترین‌ها
            </button>
            <button
              type="button"
              onClick={() => setFilterMode('lowstock')}
              className={`px-2 py-0.5 rounded-md transition-colors cursor-pointer shrink-0 ${
                filterMode === 'lowstock'
                  ? 'bg-amber-600 text-white'
                  : 'bg-white text-amber-700 hover:bg-amber-50 border border-amber-200'
              }`}
            >
              کم‌موجودی
            </button>
          </div>

          {/* Results List */}
          <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
            {filteredResults.length > 0 ? (
              filteredResults.map((product, idx) => {
                const isSelected = idx === selectedIndex;
                const isLowStock = product.currentStock <= product.minStock;

                return (
                  <div
                    key={product.id}
                    onClick={() => handlePickProduct(product)}
                    onMouseEnter={() => setSelectedIndex(idx)}
                    className={`flex items-center justify-between p-2.5 transition-colors cursor-pointer ${
                      isSelected ? 'bg-blue-50/70' : 'hover:bg-slate-50/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      {/* Product Thumbnail or Placeholder */}
                      <div className="w-9 h-9 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center shrink-0 overflow-hidden">
                        {product.image ? (
                          <img
                            src={product.image}
                            alt={product.name}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <Boxes className="w-4 h-4 text-slate-400" />
                        )}
                      </div>

                      {/* Product Details */}
                      <div className="min-w-0 space-y-0.5">
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-xs text-slate-900 truncate">
                            {product.name}
                          </span>
                          {isLowStock && (
                            <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-rose-50 text-rose-600 border border-rose-200 shrink-0">
                              کم‌موجودی
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2 text-[10px] text-slate-400">
                          <span className="font-mono">{toPersianDigits(product.barcode)}</span>
                          <span>•</span>
                          <span>موجودی: {toPersianDigits(product.currentStock)} {product.unit}</span>
                        </div>
                      </div>
                    </div>

                    {/* Price & Quick Add Button */}
                    <div className="flex items-center gap-2.5 shrink-0">
                      <div className="text-left font-mono font-bold text-xs text-blue-700">
                        {formatToman(product.retailPrice)}
                      </div>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handlePickProduct(product);
                        }}
                        className="w-7 h-7 rounded-lg bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center transition-transform active:scale-90 cursor-pointer shadow-2xs"
                        title="افزودن به فاکتور"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="p-6 text-center text-slate-400 space-y-1">
                <p className="text-xs font-bold text-slate-600">کالایی با این مشخصات یافت نشد</p>
                <p className="text-[11px]">می‌توانید بارکد کالا را مستقیماً اسکن یا وارد کنید.</p>
              </div>
            )}
          </div>

          {/* Bottom quick shortcut tip */}
          <div className="p-2 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400">
            <span>کلیدهای <strong>↑</strong> و <strong>↓</strong> جهت انتخاب • <strong>Enter</strong> جهت افزودن</span>
            <span className="font-mono text-blue-600 font-bold">{toPersianDigits(filteredResults.length)} نتیجه</span>
          </div>
        </div>
      )}
    </div>
  );
};
