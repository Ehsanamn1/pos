import React, { useState } from 'react';
import { Modal } from '../../design-system/components/Modal';
import { Button } from '../../design-system/components/Button';
import { ProformaInvoice, StoreInfo } from '../../types';
import { PrinterService } from '../../services/printer';
import { formatToman, toPersianDigits } from '../../design-system/tokens';
import {
  FileText,
  Printer,
  Calendar,
  Building2,
  CheckCircle,
  FileCheck2,
  Clock,
  Send,
  Download,
} from 'lucide-react';

interface ProformaModalProps {
  isOpen: boolean;
  onClose: () => void;
  proforma: ProformaInvoice | null;
  store: StoreInfo;
  onConvertToSale?: (proforma: ProformaInvoice) => void;
}

export const ProformaModal: React.FC<ProformaModalProps> = ({
  isOpen,
  onClose,
  proforma,
  store,
  onConvertToSale,
}) => {
  const [printFormat, setPrintFormat] = useState<'A4' | 'thermal'>('A4');

  if (!proforma) return null;

  const handlePrint = () => {
    PrinterService.printProforma(proforma, store, printFormat);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`پیش‌فاکتور شماره ${proforma.proformaNumber}`}
      size="lg"
      footer={
        <div className="flex flex-wrap items-center justify-between gap-3 w-full">
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={onClose}>
              بستن
            </Button>
            {onConvertToSale && (
              <Button
                variant="success"
                size="sm"
                icon={<FileCheck2 className="w-3.5 h-3.5" />}
                onClick={() => {
                  onConvertToSale(proforma);
                  onClose();
                }}
              >
                ثبت و تبدیل به فروش قطعی
              </Button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="primary"
              size="sm"
              icon={<Printer className="w-3.5 h-3.5" />}
              onClick={handlePrint}
            >
              چاپ پیش‌فاکتور ({printFormat === 'A4' ? 'رسمی A4' : 'فیش حرارتی'})
            </Button>
          </div>
        </div>
      }
    >
      <div className="space-y-4">
        {/* Top Format Selector Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs">
          <div className="flex items-center gap-2 text-slate-700 font-medium">
            <FileText className="w-4 h-4 text-blue-600" />
            <span>فرمت چاپی پیش‌فاکتور:</span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setPrintFormat('A4')}
              className={`px-3 py-1 rounded-lg font-bold text-xs transition-all cursor-pointer ${
                printFormat === 'A4'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              قالب رسمی شرکتی (A4)
            </button>
            <button
              type="button"
              onClick={() => setPrintFormat('thermal')}
              className={`px-3 py-1 rounded-lg font-bold text-xs transition-all cursor-pointer ${
                printFormat === 'thermal'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              فیش حرارتی (۸۰mm)
            </button>
          </div>
        </div>

        {/* Proforma Document Preview */}
        {printFormat === 'A4' ? (
          /* Official A4 Sheet Preview */
          <div className="border border-slate-300 rounded-xl p-4 sm:p-6 bg-white shadow-sm font-sans text-slate-900 space-y-4">
            {/* Header */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-3 border-b-2 border-slate-900 gap-3">
              <div>
                <h3 className="font-black text-base sm:text-lg text-slate-900">{store.name}</h3>
                <span className="text-[11px] text-slate-500 font-medium">{store.branch} • توزیع و فروش</span>
              </div>
              <div className="bg-slate-900 text-white px-3.5 py-1.5 rounded-lg text-xs font-black self-center sm:self-auto">
                « پـیـش‌فـاکـتـور فـروش کـالا »
              </div>
              <div className="text-left sm:text-left text-[11px] space-y-0.5 self-end sm:self-auto font-mono">
                <div>شماره: <strong className="text-blue-700">{proforma.proformaNumber}</strong></div>
                <div>تاریخ صدور: {proforma.issueDate}</div>
                <div className="text-rose-600 font-bold">مهلت اعتبار: {proforma.validUntil}</div>
              </div>
            </div>

            {/* Parties Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 space-y-1">
                <span className="font-bold text-blue-700 block border-b border-slate-200 pb-1">
                  مشخصات فروشنده
                </span>
                <div><strong>واحد تجاری:</strong> {store.name} ({store.branch})</div>
                <div><strong>نشانی:</strong> {store.address}</div>
                <div><strong>تلفن:</strong> {toPersianDigits(store.phone)}</div>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 space-y-1">
                <span className="font-bold text-blue-700 block border-b border-slate-200 pb-1">
                  مشخصات متقاضی استعلام (خریدار)
                </span>
                <div><strong>نام شخص / شرکت:</strong> {proforma.customerName || 'مشتری بدون نام'}</div>
                <div><strong>شماره تماس:</strong> {proforma.customerPhone || '---'}</div>
                <div><strong>نشانی / پروژه:</strong> {proforma.customerAddress || '---'}</div>
              </div>
            </div>

            {/* Items Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-right border border-slate-300">
                <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-300">
                  <tr>
                    <th className="p-2 text-center w-10">ردیف</th>
                    <th className="p-2">شرح کالا</th>
                    <th className="p-2 text-center w-16">تعداد</th>
                    <th className="p-2 text-left w-28">قیمت واحد (تومان)</th>
                    <th className="p-2 text-left w-32">مبلغ کل (تومان)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {proforma.items.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50">
                      <td className="p-2 text-center font-mono text-slate-500">{toPersianDigits(idx + 1)}</td>
                      <td className="p-2 font-medium text-slate-900">{item.productName}</td>
                      <td className="p-2 text-center font-mono">{toPersianDigits(item.quantity)}</td>
                      <td className="p-2 text-left font-mono">{formatToman(item.unitPrice)}</td>
                      <td className="p-2 text-left font-mono font-bold text-slate-900">{formatToman(item.total)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Totals & Terms */}
            <div className="flex flex-col sm:flex-row justify-between gap-4 pt-2">
              <div className="flex-1 bg-amber-50/60 border border-amber-200 rounded-lg p-3 text-[11px] text-amber-900 space-y-1">
                <span className="font-bold block text-amber-950">شرایط و مفاد پیش‌فاکتور:</span>
                <p>• این برگه پیش‌فاکتور استعلام قیمت بوده و تا تاریخ {proforma.validUntil} دارای اعتبار می‌باشد.</p>
                <p>• {proforma.notes || 'تسویه حساب نقدی در زمان تحویل کالا انجام می‌گردد.'}</p>
                <p>• پس از پایان مهلت اعتبار، قیمت‌ها نیازمند استعلام و تمدید مجدد خواهد بود.</p>
              </div>

              <div className="w-full sm:w-64 bg-slate-50 border border-slate-200 rounded-lg p-3 space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>جمع اقلام:</span>
                  <span className="font-mono font-bold">{formatToman(proforma.subtotal)}</span>
                </div>
                {proforma.discount > 0 && (
                  <div className="flex justify-between text-emerald-600">
                    <span>تخفیف:</span>
                    <span className="font-mono font-bold">- {formatToman(proforma.discount)}</span>
                  </div>
                )}
                {proforma.tax > 0 && (
                  <div className="flex justify-between text-slate-600">
                    <span>مالیات و عوارض:</span>
                    <span className="font-mono font-bold">+ {formatToman(proforma.tax)}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-900 font-black pt-2 border-t border-slate-300 text-sm">
                  <span>مبلغ کل پیش‌فاکتور:</span>
                  <span className="text-blue-700 font-mono">{formatToman(proforma.finalTotal)}</span>
                </div>
              </div>
            </div>

            {/* Stamp and Signatures */}
            <div className="grid grid-cols-2 gap-4 pt-6 border-t border-dashed border-slate-300 text-center text-xs">
              <div className="h-16 flex flex-col justify-between">
                <span className="font-bold text-slate-700">مهر و امضای فروشنده:</span>
                <span className="text-[10px] text-slate-400 font-mono">{proforma.cashierName}</span>
              </div>
              <div className="h-16 flex flex-col justify-between">
                <span className="font-bold text-slate-700">تأیید و امضای متقاضی (خریدار):</span>
                <span className="text-[10px] text-slate-400">محل امضا و تاریخ</span>
              </div>
            </div>
          </div>
        ) : (
          /* Thermal Receipt Style Preview */
          <div className="bg-slate-200/70 p-4 rounded-xl flex justify-center">
            <div className="w-[300px] bg-white p-4 rounded shadow-md border border-slate-300 text-xs space-y-3 font-sans text-slate-900">
              <div className="text-center pb-2 border-b-2 border-dashed border-slate-400">
                <div className="border border-slate-800 text-[11px] font-black py-0.5 mb-1">
                  « پـیـش‌فـاکـتـور فـروش »
                </div>
                <h4 className="font-black text-sm">{store.name}</h4>
                <div className="text-[10px] text-slate-500">{store.branch} - تلفن: {toPersianDigits(store.phone)}</div>
              </div>

              <div className="text-[11px] space-y-1 border-b border-dashed border-slate-400 pb-2">
                <div className="flex justify-between">
                  <span>شماره پیش‌فاکتور:</span>
                  <span className="font-mono font-bold">{proforma.proformaNumber}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>تاریخ صدور:</span>
                  <span>{proforma.issueDate}</span>
                </div>
                <div className="flex justify-between text-rose-600 font-medium">
                  <span>اعتبار تا:</span>
                  <span>{proforma.validUntil}</span>
                </div>
                {proforma.customerName && (
                  <div className="flex justify-between text-blue-700">
                    <span>مشتری:</span>
                    <span>{proforma.customerName}</span>
                  </div>
                )}
              </div>

              <div className="border-b border-dashed border-slate-400 pb-2">
                <table className="w-full text-right text-[11px]">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 text-[10px]">
                      <th>شرح</th>
                      <th className="text-center">تعداد</th>
                      <th className="text-left">جمع</th>
                    </tr>
                  </thead>
                  <tbody>
                    {proforma.items.map((item, idx) => (
                      <tr key={idx} className="py-1">
                        <td className="py-1 text-[10px] font-medium">{item.productName}</td>
                        <td className="py-1 text-center font-mono">{toPersianDigits(item.quantity)}</td>
                        <td className="py-1 text-left font-mono">{formatToman(item.total)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="space-y-1 text-xs border-b-2 border-slate-900 pb-2">
                <div className="flex justify-between text-slate-600">
                  <span>جمع اقلام:</span>
                  <span>{formatToman(proforma.subtotal)}</span>
                </div>
                {proforma.discount > 0 && (
                  <div className="flex justify-between text-emerald-600">
                    <span>تخفیف:</span>
                    <span>- {formatToman(proforma.discount)}</span>
                  </div>
                )}
                {proforma.tax > 0 && (
                  <div className="flex justify-between text-slate-600">
                    <span>مالیات:</span>
                    <span>+ {formatToman(proforma.tax)}</span>
                  </div>
                )}
                <div className="flex justify-between font-black text-sm pt-1 text-slate-950">
                  <span>مبلغ قابل پرداخت:</span>
                  <span className="font-mono">{formatToman(proforma.finalTotal)}</span>
                </div>
              </div>

              <div className="text-[9px] text-slate-500 text-center pt-1 leading-tight">
                این برگه پیش‌فاکتور غیرمالیاتی و معتبر تا تاریخ قید شده است.<br />
                Fartak POS • سامانه هوشمند فرتاک
              </div>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
};
