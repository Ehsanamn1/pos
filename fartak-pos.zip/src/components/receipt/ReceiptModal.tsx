import React, { useState } from 'react';
import { Modal } from '../../design-system/components/Modal';
import { Button } from '../../design-system/components/Button';
import { Sale, StoreInfo } from '../../types';
import { PrinterService } from '../../services/printer';
import { formatToman, toPersianDigits } from '../../design-system/tokens';
import { Printer, CheckCircle2, RotateCcw } from 'lucide-react';

interface ReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  sale: Sale | null;
  store: StoreInfo;
  onNewSale: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  isOpen,
  onClose,
  sale,
  store,
  onNewSale,
}) => {
  const [paperWidth, setPaperWidth] = useState<'58mm' | '80mm'>('80mm');

  if (!sale) return null;

  const handlePrint = () => {
    PrinterService.printReceipt(sale, store, paperWidth);
  };

  const handleStartNext = () => {
    onClose();
    onNewSale();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="فاکتور فروش صادر شده"
      size="md"
      footer={
        <div className="flex items-center justify-between w-full">
          <Button variant="ghost" onClick={handleStartNext} icon={<RotateCcw className="w-4 h-4" />}>
            فروش جدید
          </Button>
          <div className="flex items-center gap-2">
            <Button variant="primary" onClick={handlePrint} icon={<Printer className="w-4 h-4" />}>
              چاپ فیش حرارتی
            </Button>
          </div>
        </div>
      }
    >
      <div className="space-y-4">
        {/* Success Alert */}
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-center gap-3 text-emerald-800 text-xs">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <div>
            <div className="font-bold">فاکتور #{toPersianDigits(sale.invoiceNumber)} با موفقیت ثبت شد</div>
            <div className="text-emerald-700 text-[11px] mt-0.5">
              موجودی کالاها کسر شد و اطلاعات در پایگاه داده فروشگاه ذخیره گردید.
            </div>
          </div>
        </div>

        {/* Paper Width Selector */}
        <div className="flex items-center justify-between text-xs bg-slate-100 p-2 rounded-xl">
          <span className="font-medium text-slate-600">عرض رول کاغذ حرارتی:</span>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setPaperWidth('80mm')}
              className={`px-3 py-1 rounded-lg font-mono font-bold transition-all cursor-pointer ${
                paperWidth === '80mm'
                  ? 'bg-white shadow-xs text-blue-600'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              80mm (استاندارد)
            </button>
            <button
              type="button"
              onClick={() => setPaperWidth('58mm')}
              className={`px-3 py-1 rounded-lg font-mono font-bold transition-all cursor-pointer ${
                paperWidth === '58mm'
                  ? 'bg-white shadow-xs text-blue-600'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              58mm (مینی)
            </button>
          </div>
        </div>

        {/* Realistic Thermal Receipt Paper Preview */}
        <div className="bg-slate-200/60 p-4 rounded-2xl flex justify-center overflow-hidden">
          <div
            className={`bg-white shadow-md border border-slate-300 p-4 rounded-sm font-sans transition-all duration-300 text-slate-900 ${
              paperWidth === '58mm' ? 'w-[260px] text-[11px]' : 'w-[320px] text-xs'
            }`}
            style={{
              boxShadow: '0 4px 20px -2px rgba(0,0,0,0.1)',
            }}
          >
            {/* Header */}
            <div className="text-center pb-2 border-b border-dashed border-slate-400">
              <h3 className="font-black text-sm text-slate-900">{store.name}</h3>
              <div className="text-[10px] text-slate-600 mt-0.5">{store.branch}</div>
              <div className="text-[10px] text-slate-500 font-mono mt-0.5">تلفن: {toPersianDigits(store.phone)}</div>
              <div className="text-[9px] text-slate-400 mt-0.5 leading-tight">{store.address}</div>
            </div>

            {/* Invoice meta */}
            <div className="py-2 border-b border-dashed border-slate-400 space-y-1 text-[10px]">
              <div className="flex justify-between">
                <span>شماره فاکتور:</span>
                <span className="font-bold font-mono">#{toPersianDigits(sale.invoiceNumber)}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>تاریخ و زمان:</span>
                <span>{toPersianDigits(sale.date)} - {toPersianDigits(sale.time)}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>صندوق‌دار:</span>
                <span>{sale.cashierName}</span>
              </div>
              {sale.customerName && (
                <div className="flex justify-between text-blue-800 font-medium">
                  <span>مشتری:</span>
                  <span>{sale.customerName}</span>
                </div>
              )}
            </div>

            {/* Line items table */}
            <div className="py-2 border-b border-dashed border-slate-400">
              <table className="w-full text-right text-[11px]">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 text-[10px]">
                    <th className="pb-1 font-bold">شرح کالا</th>
                    <th className="pb-1 text-center font-bold">تعداد</th>
                    <th className="pb-1 text-left font-bold">مبلغ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {sale.items.map((item, idx) => (
                    <tr key={idx} className="py-1">
                      <td className="py-1.5 leading-tight font-medium text-slate-800">
                        {item.productName}
                      </td>
                      <td className="py-1.5 text-center font-mono text-slate-600">
                        {toPersianDigits(item.quantity)}
                      </td>
                      <td className="py-1.5 text-left font-sans font-bold text-slate-900 whitespace-nowrap">
                        {formatToman(item.total)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Summary Totals */}
            <div className="py-2 border-b-2 border-slate-900 space-y-1 text-[11px]">
              <div className="flex justify-between text-slate-600">
                <span>جمع کل:</span>
                <span>{formatToman(sale.subtotal)}</span>
              </div>
              {sale.discount > 0 && (
                <div className="flex justify-between text-emerald-600 font-medium">
                  <span>تخفیف:</span>
                  <span>- {formatToman(sale.discount)}</span>
                </div>
              )}
              {sale.tax > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>مالیات:</span>
                  <span>+ {formatToman(sale.tax)}</span>
                </div>
              )}
              <div className="flex justify-between text-sm font-black text-slate-900 pt-1">
                <span>قابل پرداخت:</span>
                <span>{formatToman(sale.finalTotal)}</span>
              </div>
              <div className="flex justify-between text-[10px] text-slate-500 pt-0.5">
                <span>روش پرداخت:</span>
                <span>{sale.paymentMethod}</span>
              </div>
            </div>

            {/* Barcode & Footer */}
            <div className="pt-3 text-center space-y-1">
              <div className="font-mono text-xs tracking-widest font-black text-slate-800 py-1 bg-slate-50 rounded">
                *{sale.invoiceNumber}*
              </div>
              <div className="text-[9px] text-slate-500 pt-1">
                از خرید شما سپاسگزاریم<br />
                Fartak POS • سامانه فروشگاهی فرتاک
              </div>
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
};
