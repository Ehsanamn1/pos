import React, { useState } from 'react';
import { Modal } from '../../design-system/components/Modal';
import { Button } from '../../design-system/components/Button';
import { Sale, StoreInfo } from '../../types';
import { StorageService } from '../../services/storage';
import { PrinterService } from '../../services/printer';
import { scannerService } from '../../services/barcodeScanner';
import { formatToman, toPersianDigits } from '../../design-system/tokens';
import {
  Printer,
  RotateCcw,
  Ban,
  CheckCircle2,
  AlertTriangle,
  Clock,
  User,
  CreditCard,
  FileText,
  Copy,
  Check,
  Building2,
  Phone,
  Receipt,
  X,
  Store,
} from 'lucide-react';

interface TransactionDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  sale: Sale | null;
  store: StoreInfo;
  onSaleUpdated?: () => void;
}

export const TransactionDetailModal: React.FC<TransactionDetailModalProps> = ({
  isOpen,
  onClose,
  sale,
  store,
  onSaleUpdated,
}) => {
  const [currentSale, setCurrentSale] = useState<Sale | null>(sale);
  const [paperWidth, setPaperWidth] = useState<'58mm' | '80mm'>('80mm');
  const [showVoidConfirm, setShowVoidConfirm] = useState(false);
  const [voidSuccessMessage, setVoidSuccessMessage] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'details' | 'receiptPreview'>('details');

  // Keep internal state in sync with prop
  React.useEffect(() => {
    setCurrentSale(sale);
    setShowVoidConfirm(false);
    setVoidSuccessMessage(null);
    setCopied(false);
  }, [sale]);

  if (!currentSale) return null;

  const isVoided = currentSale.status === 'مرجوع شده';

  // Handle Void / Refund
  const handleConfirmVoid = () => {
    if (!currentSale) return;
    const res = StorageService.refundSale(currentSale.id);
    if (res.success) {
      scannerService.playBeep('success');
      const updated = { ...currentSale, status: 'مرجوع شده' as const };
      setCurrentSale(updated);
      setShowVoidConfirm(false);
      setVoidSuccessMessage('فاکتور با موفقیت باطل شد و موجودی اقلام به انبار بازگردانده شد.');
      if (onSaleUpdated) {
        onSaleUpdated();
      }
    } else {
      scannerService.playBeep('error');
      alert(res.message);
    }
  };

  // Handle Print Receipt
  const handlePrint = () => {
    if (!currentSale) return;
    PrinterService.printReceipt(currentSale, store, paperWidth);
  };

  // Copy Invoice Number
  const handleCopyInvoiceNumber = () => {
    if (!currentSale) return;
    navigator.clipboard?.writeText(currentSale.invoiceNumber);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`جزئیات تراکنش #${toPersianDigits(currentSale.invoiceNumber)}`}
      size="lg"
      footer={
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 w-full">
          <div className="flex items-center gap-2 w-full sm:w-auto">
            {!isVoided && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowVoidConfirm(true)}
                className="text-rose-600 hover:text-rose-700 hover:bg-rose-50 border-rose-200 cursor-pointer"
                icon={<Ban className="w-4 h-4" />}
              >
                ابطال و مرجوع فاکتور
              </Button>
            )}
            {isVoided && (
              <span className="text-xs font-bold text-rose-600 flex items-center gap-1.5 bg-rose-50 px-3 py-1.5 rounded-xl border border-rose-200">
                <Ban className="w-3.5 h-3.5" />
                این فاکتور باطل گردیده است
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <Button variant="ghost" size="sm" onClick={onClose}>
              بستن
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={handlePrint}
              icon={<Printer className="w-4 h-4" />}
            >
              چاپ فیش فاکتور
            </Button>
          </div>
        </div>
      }
    >
      <div className="space-y-4">
        {/* Void Success Notification */}
        {voidSuccessMessage && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center justify-between animate-in fade-in">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{voidSuccessMessage}</span>
            </div>
            <button
              type="button"
              onClick={() => setVoidSuccessMessage(null)}
              className="text-emerald-700 hover:text-emerald-900 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Void Confirmation Popover/Banner */}
        {showVoidConfirm && (
          <div className="p-4 bg-rose-50 border-2 border-rose-300 rounded-2xl text-xs text-rose-900 space-y-3 animate-in fade-in">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-black text-sm text-rose-950">
                  تأیید ابطال فاکتور #{toPersianDigits(currentSale.invoiceNumber)}
                </h4>
                <p className="text-rose-700 text-[11px] mt-1 leading-relaxed">
                  آیا از ابطال کامل این فاکتور اطمینان دارید؟
                  اقلام موجود در این فاکتور بلافاصله به موجودی انبار فروشگاه بازگردانده خواهند شد و در صورت تسویه اعتباری، مانده حساب مشتری اصلاح می‌شود.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-1 border-t border-rose-200/60">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowVoidConfirm(false)}
              >
                انصراف
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={handleConfirmVoid}
                className="bg-rose-600 hover:bg-rose-700 text-white"
                icon={<Ban className="w-4 h-4" />}
              >
                بله، فاکتور باطل شود
              </Button>
            </div>
          </div>
        )}

        {/* Header Tabs: Full Details vs. Receipt Paper Preview */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
            <button
              type="button"
              onClick={() => setActiveTab('details')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'details'
                  ? 'bg-white text-blue-600 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              مشخصات و اقلام
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('receiptPreview')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'receiptPreview'
                  ? 'bg-white text-blue-600 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              پیش‌نمایش رول حرارتی
            </button>
          </div>

          {/* Status Badge & Copy Button */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopyInvoiceNumber}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors flex items-center gap-1 text-[11px] cursor-pointer"
              title="کپی شماره فاکتور"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-600 font-bold">کپی شد</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>کپی کد</span>
                </>
              )}
            </button>

            {isVoided ? (
              <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-700 border border-rose-200 flex items-center gap-1">
                <Ban className="w-3.5 h-3.5" />
                مرجوع شده (باطل)
              </span>
            ) : (
              <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                تکمیل شده (معتبر)
              </span>
            )}
          </div>
        </div>

        {activeTab === 'details' ? (
          <div className="space-y-4">
            {/* Meta summary grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 bg-slate-50/80 p-3 rounded-2xl border border-slate-200/80 text-xs">
              <div>
                <span className="text-[10px] text-slate-400 block">تاریخ و ساعت صدور:</span>
                <span className="font-bold text-slate-800 font-mono mt-0.5 block">
                  {toPersianDigits(currentSale.date)} - {toPersianDigits(currentSale.time)}
                </span>
              </div>

              <div>
                <span className="text-[10px] text-slate-400 block">روش پرداخت:</span>
                <span className="font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md inline-block mt-0.5 border border-blue-100">
                  {currentSale.paymentMethod}
                </span>
              </div>

              <div>
                <span className="text-[10px] text-slate-400 block">صندوق‌دار / کاربر:</span>
                <span className="font-bold text-slate-800 truncate block mt-0.5">
                  {currentSale.cashierName || 'رضا کمالی'}
                </span>
              </div>

              <div>
                <span className="text-[10px] text-slate-400 block">مشتری:</span>
                <span className="font-bold text-slate-800 truncate block mt-0.5">
                  {currentSale.customerName || 'مشتری عمومی (گذری)'}
                </span>
              </div>
            </div>

            {/* Line Items Table */}
            <div className="border border-slate-200/80 rounded-2xl overflow-hidden bg-white shadow-2xs">
              <div className="bg-slate-50 px-3.5 py-2 border-b border-slate-200 flex items-center justify-between text-xs font-bold text-slate-700">
                <span>اقلام خریداری شده ({(currentSale.items || []).length} ردیف)</span>
                <span className="text-[11px] text-slate-400 font-normal">
                  تعداد کل قطعات: {toPersianDigits((currentSale.items || []).reduce((acc, i) => acc + i.quantity, 0))} عدد
                </span>
              </div>

              <div className="divide-y divide-slate-100 max-h-64 overflow-y-auto">
                {(currentSale.items || []).map((item, idx) => (
                  <div
                    key={item.productId || idx}
                    className="p-3 flex items-center justify-between gap-3 text-xs hover:bg-slate-50/50 transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="w-5 h-5 rounded-md bg-slate-100 text-slate-500 text-[10px] font-mono font-bold flex items-center justify-center shrink-0">
                        {toPersianDigits(idx + 1)}
                      </span>
                      <div>
                        <h5 className="font-bold text-slate-900">{item.productName}</h5>
                        <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                          {toPersianDigits(item.quantity)} عدد × {formatToman(item.unitPrice)}
                        </div>
                      </div>
                    </div>

                    <div className="font-sans font-bold text-slate-900">
                      {formatToman(item.total)}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Financial Settlement Totals */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>جمع کل اقلام (ناخالص):</span>
                <span className="font-sans font-bold">{formatToman(currentSale.subtotal)}</span>
              </div>

              {currentSale.discount > 0 && (
                <div className="flex justify-between text-emerald-600">
                  <span>تخفیف ویژه:</span>
                  <span className="font-sans font-bold">-{formatToman(currentSale.discount)}</span>
                </div>
              )}

              {currentSale.tax > 0 && (
                <div className="flex justify-between text-slate-500">
                  <span>مالیات بر ارزش افزوده ({toPersianDigits(store?.taxRate || 10)}٪):</span>
                  <span className="font-sans font-bold">+{formatToman(currentSale.tax)}</span>
                </div>
              )}

              <div className="pt-2.5 mt-2 border-t border-slate-200 flex justify-between items-center text-sm font-black">
                <span className="text-slate-900">مبلغ نهایی پرداختی:</span>
                <span className={`font-sans text-base ${isVoided ? 'line-through text-slate-400' : 'text-blue-700'}`}>
                  {formatToman(currentSale.finalTotal)}
                </span>
              </div>
            </div>
          </div>
        ) : (
          /* Receipt Thermal Preview Tab */
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs bg-slate-100 p-2 rounded-xl">
              <span className="font-medium text-slate-600">عرض رول کاغذ حرارتی:</span>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setPaperWidth('80mm')}
                  className={`px-3 py-1 rounded-lg font-mono font-bold transition-all cursor-pointer ${
                    paperWidth === '80mm'
                      ? 'bg-white shadow-2xs text-blue-600'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  80mm (استاندارد)
                </button>
                <button
                  type="button"
                  onClick={() => setPaperWidth('58mm')}
                  className={`px-3 py-1 rounded-lg font-mono font-bold transition-all cursor-pointer ${
                    paperWidth === '58mm'
                      ? 'bg-white shadow-2xs text-blue-600'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  58mm (مینی)
                </button>
              </div>
            </div>

            <div className="bg-slate-200/70 p-4 rounded-2xl flex justify-center overflow-hidden">
              <div
                className={`bg-white shadow-md border border-slate-300 p-4 rounded-sm font-sans transition-all duration-300 text-slate-900 ${
                  paperWidth === '80mm' ? 'w-[320px]' : 'w-[240px]'
                } ${isVoided ? 'relative' : ''}`}
              >
                {/* Voided Watermark if refunded */}
                {isVoided && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
                    <span className="rotate-[-25deg] text-rose-500/25 border-4 border-rose-500/30 text-3xl font-black px-6 py-2 rounded-xl uppercase tracking-widest">
                      باطل شد
                    </span>
                  </div>
                )}

                {/* Header */}
                <div className="text-center pb-3 border-b border-dashed border-slate-300 space-y-1">
                  <div className="font-black text-sm text-slate-900">{store?.name || 'هایپرمارکت فرتاک'}</div>
                  <div className="text-[10px] text-slate-500">{store?.branch || 'شعبه مرکزی'}</div>
                  <div className="text-[10px] text-slate-400 font-mono">
                    تلفن: {toPersianDigits(store?.phone || '۰۲۱-۸۸۸۸۹۹۹۹')}
                  </div>
                  <div className="text-[11px] font-bold text-slate-800 pt-1 font-mono">
                    فاکتور فروش #{toPersianDigits(currentSale.invoiceNumber)}
                  </div>
                </div>

                {/* Metadata */}
                <div className="py-2 border-b border-dashed border-slate-300 text-[10px] text-slate-600 space-y-0.5 font-mono">
                  <div className="flex justify-between">
                    <span>تاریخ: {toPersianDigits(currentSale.date)}</span>
                    <span>ساعت: {toPersianDigits(currentSale.time)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>صندوق‌دار: {currentSale.cashierName}</span>
                    <span>روش: {currentSale.paymentMethod}</span>
                  </div>
                  {currentSale.customerName && (
                    <div className="text-right">مشتری: {currentSale.customerName}</div>
                  )}
                </div>

                {/* Items */}
                <div className="py-2 border-b border-dashed border-slate-300 space-y-1.5 text-[11px]">
                  {(currentSale.items || []).map((item, idx) => (
                    <div key={idx} className="flex justify-between items-start gap-1">
                      <div className="text-right flex-1">
                        <div className="font-bold leading-tight">{item.productName}</div>
                        <div className="text-[9px] text-slate-500 font-mono">
                          {toPersianDigits(item.quantity)} × {formatToman(item.unitPrice)}
                        </div>
                      </div>
                      <div className="font-bold text-left shrink-0 font-mono">
                        {formatToman(item.total)}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Totals */}
                <div className="py-2 space-y-1 text-[10px] font-mono border-b border-dashed border-slate-300">
                  <div className="flex justify-between text-slate-600">
                    <span>جمع اقلام:</span>
                    <span>{formatToman(currentSale.subtotal)}</span>
                  </div>
                  {currentSale.discount > 0 && (
                    <div className="flex justify-between text-emerald-600">
                      <span>تخفیف:</span>
                      <span>-{formatToman(currentSale.discount)}</span>
                    </div>
                  )}
                  {currentSale.tax > 0 && (
                    <div className="flex justify-between text-slate-500">
                      <span>مالیات ({toPersianDigits(store?.taxRate || 10)}٪):</span>
                      <span>+{formatToman(currentSale.tax)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-black text-xs pt-1 text-slate-900 border-t border-slate-200">
                    <span>مبلغ کل نهایی:</span>
                    <span className="font-sans">{formatToman(currentSale.finalTotal)}</span>
                  </div>
                </div>

                {/* Footer Barcode Simulation */}
                <div className="pt-3 text-center space-y-1.5">
                  <div className="font-mono text-[9px] text-slate-400">
                    * * {currentSale.invoiceNumber} * *
                  </div>
                  <div className="h-7 bg-slate-800 rounded-xs flex items-center justify-center text-[9px] text-white font-mono tracking-widest">
                    |||| ||| ||||| |||| || |||||
                  </div>
                  <div className="text-[9px] text-slate-500">
                    {store?.receiptFooter || 'از خرید شما سپاسگزاریم • سامانه فروش فرتاک'}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
};
