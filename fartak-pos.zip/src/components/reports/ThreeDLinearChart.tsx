import React, { useState } from 'react';
import { formatToman, toPersianDigits } from '../../design-system/tokens';
import {
  TrendingUp,
  Layers,
  Sparkles,
  Calendar,
  Eye,
  BarChart3,
  CircleDot,
  Maximize2,
} from 'lucide-react';

interface ChartPoint {
  label: string;
  value: number;
  secondaryValue: number; // e.g. profit or count
  count: number;
}

const WEEK_DATA: ChartPoint[] = [
  { label: 'شنبه', value: 18200000, secondaryValue: 4004000, count: 64 },
  { label: 'یکشنبه', value: 22500000, secondaryValue: 4950000, count: 78 },
  { label: 'دوشنبه', value: 13100000, secondaryValue: 2882000, count: 46 },
  { label: 'سه‌شنبه', value: 19800000, secondaryValue: 4356000, count: 71 },
  { label: 'چهارشنبه', value: 24850000, secondaryValue: 5467000, count: 82 },
  { label: 'پنج‌شنبه', value: 23400000, secondaryValue: 5148000, count: 79 },
  { label: 'جمعه', value: 14600000, secondaryValue: 3212000, count: 52 },
];

const MONTH_DATA: ChartPoint[] = [
  { label: 'هفته ۱', value: 112000000, secondaryValue: 24640000, count: 390 },
  { label: 'هفته ۲', value: 145000000, secondaryValue: 31900000, count: 480 },
  { label: 'هفته ۳', value: 138000000, secondaryValue: 30360000, count: 465 },
  { label: 'هفته ۴', value: 165000000, secondaryValue: 36300000, count: 540 },
];

const YEAR_DATA: ChartPoint[] = [
  { label: 'فروردین', value: 420000000, secondaryValue: 92400000, count: 1450 },
  { label: 'اردیبهشت', value: 480000000, secondaryValue: 105600000, count: 1680 },
  { label: 'خرداد', value: 510000000, secondaryValue: 112200000, count: 1790 },
  { label: 'تیر', value: 490000000, secondaryValue: 107800000, count: 1710 },
  { label: 'مرداد', value: 540000000, secondaryValue: 118800000, count: 1890 },
  { label: 'شهریور', value: 620000000, secondaryValue: 136400000, count: 2150 },
  { label: 'مهر', value: 580000000, secondaryValue: 127600000, count: 2020 },
  { label: 'آبان', value: 560000000, secondaryValue: 123200000, count: 1950 },
  { label: 'آذر', value: 610000000, secondaryValue: 134200000, count: 2120 },
  { label: 'دی', value: 590000000, secondaryValue: 129800000, count: 2060 },
  { label: 'بهمن', value: 650000000, secondaryValue: 143000000, count: 2280 },
  { label: 'اسفند', value: 780000000, secondaryValue: 171600000, count: 2740 },
];

export const ThreeDLinearChart: React.FC = () => {
  const [timeframe, setTimeframe] = useState<'week' | 'month' | 'year'>('week');
  const [metric, setMetric] = useState<'sales' | 'profit' | 'count'>('sales');
  const [is3DMode, setIs3DMode] = useState<boolean>(true);
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(4); // default select Wednesday

  const data = timeframe === 'week' ? WEEK_DATA : timeframe === 'month' ? MONTH_DATA : YEAR_DATA;

  // Extract values based on metric
  const rawValues = data.map((d) =>
    metric === 'sales' ? d.value : metric === 'profit' ? d.secondaryValue : d.count
  );
  const maxValue = Math.max(...rawValues, 1);
  const minValue = Math.min(...rawValues, 0);

  // Chart coordinate math (SVG viewBox: 800 x 300)
  const chartWidth = 760;
  const chartHeight = 220;
  const paddingX = 40;
  const paddingY = 30;

  const points = data.map((d, idx) => {
    const val = metric === 'sales' ? d.value : metric === 'profit' ? d.secondaryValue : d.count;
    const x = paddingX + (idx / Math.max(1, data.length - 1)) * (chartWidth - paddingX * 2);
    const normalized = (val - minValue) / (maxValue - minValue || 1);
    const y = chartHeight - paddingY - normalized * (chartHeight - paddingY * 2);
    return { ...d, x, y, val };
  });

  // Build SVG path
  const linePath = points.reduce((acc, pt, idx, arr) => {
    if (idx === 0) return `M ${pt.x},${pt.y}`;
    const prev = arr[idx - 1];
    const cx1 = prev.x + (pt.x - prev.x) / 2;
    const cy1 = prev.y;
    const cx2 = prev.x + (pt.x - prev.x) / 2;
    const cy2 = pt.y;
    return `${acc} C ${cx1},${cy1} ${cx2},${cy2} ${pt.x},${pt.y}`;
  }, '');

  // 3D Extrusion Area Fill
  const areaPath = `${linePath} L ${points[points.length - 1].x},${chartHeight - paddingY} L ${points[0].x},${chartHeight - paddingY} Z`;

  // Secondary depth 3D shadow line (shifted 14px down and 8px left)
  const depthLinePath = points.reduce((acc, pt, idx, arr) => {
    const dx = pt.x - 8;
    const dy = pt.y + 14;
    if (idx === 0) return `M ${dx},${dy}`;
    const prev = arr[idx - 1];
    const cx1 = prev.x - 8 + (dx - (prev.x - 8)) / 2;
    const cy1 = prev.y + 14;
    const cx2 = prev.x - 8 + (dx - (prev.x - 8)) / 2;
    const cy2 = dy;
    return `${acc} C ${cx1},${cy1} ${cx2},${cy2} ${dx},${dy}`;
  }, '');

  const hoveredPoint = hoveredIdx !== null ? points[hoveredIdx] : points[points.length - 1];

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 p-4 sm:p-5 shadow-xs space-y-4">
      {/* Header controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
            <Layers className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-black text-sm text-slate-900">
                گزارش نموداری خطی سه‌بعدی (3D Chart)
              </h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200">
                هوشمند فرتاک
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              نمایش عمق‌دار و سه‌بعدی خطی با تفکیک حجم فروش، سود ناخالص و تعداد تراکنش‌ها
            </p>
          </div>
        </div>

        {/* Action controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* 3D vs 2D toggle */}
          <button
            type="button"
            onClick={() => setIs3DMode(!is3DMode)}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              is3DMode
                ? 'bg-blue-600 text-white shadow-2xs shadow-blue-500/30'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{is3DMode ? 'نمای سه‌بعدی (3D)' : 'نمای دوبعدی (تخت)'}</span>
          </button>

          {/* Timeframe selector */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200">
            <button
              type="button"
              onClick={() => setTimeframe('week')}
              className={`px-2.5 py-1 text-[11px] font-bold rounded-md transition-all cursor-pointer ${
                timeframe === 'week' ? 'bg-white text-blue-700 shadow-2xs' : 'text-slate-500'
              }`}
            >
              هفته
            </button>
            <button
              type="button"
              onClick={() => setTimeframe('month')}
              className={`px-2.5 py-1 text-[11px] font-bold rounded-md transition-all cursor-pointer ${
                timeframe === 'month' ? 'bg-white text-blue-700 shadow-2xs' : 'text-slate-500'
              }`}
            >
              ماه
            </button>
            <button
              type="button"
              onClick={() => setTimeframe('year')}
              className={`px-2.5 py-1 text-[11px] font-bold rounded-md transition-all cursor-pointer ${
                timeframe === 'year' ? 'bg-white text-blue-700 shadow-2xs' : 'text-slate-500'
              }`}
            >
              سالانه
            </button>
          </div>
        </div>
      </div>

      {/* Metric Selector Pills */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setMetric('sales')}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              metric === 'sales'
                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                : 'text-slate-500 hover:bg-slate-50'
            }`}
          >
            فروش ریالی (تومان)
          </button>
          <button
            type="button"
            onClick={() => setMetric('profit')}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              metric === 'profit'
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                : 'text-slate-500 hover:bg-slate-50'
            }`}
          >
            سود ناخالص
          </button>
          <button
            type="button"
            onClick={() => setMetric('count')}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              metric === 'count'
                ? 'bg-purple-50 text-purple-700 border border-purple-200'
                : 'text-slate-500 hover:bg-slate-50'
            }`}
          >
            تعداد فاکتور
          </button>
        </div>

        {/* Hovered Point Badge */}
        {hoveredPoint && (
          <div className="text-xs flex items-center gap-2 bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200">
            <span className="font-bold text-slate-700">{hoveredPoint.label}:</span>
            <span className="font-mono font-black text-blue-700">
              {metric === 'count'
                ? `${toPersianDigits(hoveredPoint.val)} فاکتور`
                : formatToman(hoveredPoint.val)}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              ({toPersianDigits(hoveredPoint.count)} تراکنش)
            </span>
          </div>
        )}
      </div>

      {/* The 3D Canvas Stage */}
      <div className="relative w-full overflow-hidden rounded-xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 p-3 sm:p-5 border border-slate-800 shadow-inner">
        {/* Ambient Top Glow */}
        <div className="absolute top-0 left-1/4 w-1/2 h-20 bg-blue-500/10 blur-3xl pointer-events-none" />

        {/* 3D Perspective Wrapper */}
        <div
          className="w-full transition-transform duration-500 ease-out py-2"
          style={{
            perspective: is3DMode ? '1000px' : 'none',
          }}
        >
          <div
            className="transition-transform duration-500 ease-out"
            style={{
              transform: is3DMode
                ? 'rotateX(20deg) rotateY(-4deg) rotateZ(0.5deg) translateZ(10px)'
                : 'none',
              transformStyle: 'preserve-3d',
            }}
          >
            <svg
              viewBox={`0 0 ${chartWidth} ${chartHeight}`}
              className="w-full h-48 sm:h-64 overflow-visible"
            >
              <defs>
                {/* 3D Gradient Fill for Area Ribbon */}
                <linearGradient id="gradient3DArea" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.45" />
                  <stop offset="60%" stopColor="#1d4ed8" stopOpacity="0.15" />
                  <stop offset="100%" stopColor="#0f172a" stopOpacity="0.0" />
                </linearGradient>

                {/* 3D Glow Line Gradient */}
                <linearGradient id="lineGlow" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#60a5fa" />
                  <stop offset="50%" stopColor="#38bdf8" />
                  <stop offset="100%" stopColor="#818cf8" />
                </linearGradient>

                {/* 3D Depth Ribbon Gradient */}
                <linearGradient id="depthRibbon" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#1e3a8a" stopOpacity="0.6" />
                  <stop offset="100%" stopColor="#020617" stopOpacity="0.1" />
                </linearGradient>

                {/* Filter for Drop Shadow */}
                <filter id="shadow3D" x="-10%" y="-10%" width="130%" height="130%">
                  <feDropShadow dx="0" dy="6" stdDeviation="6" floodColor="#2563eb" floodOpacity="0.4" />
                </filter>
              </defs>

              {/* Isometric 3D Grid Floor Lines */}
              <g className="opacity-20 stroke-slate-600" strokeDasharray="3 3">
                {[0.25, 0.5, 0.75, 1].map((ratio, i) => {
                  const y = chartHeight - paddingY - ratio * (chartHeight - paddingY * 2);
                  return (
                    <line
                      key={i}
                      x1={paddingX - 10}
                      y1={y}
                      x2={chartWidth - paddingX + 10}
                      y2={y}
                      strokeWidth="1"
                    />
                  );
                })}
              </g>

              {/* 3D Extrusion Depth Floor Wall (Shadow Layer) */}
              {is3DMode && (
                <path
                  d={depthLinePath}
                  fill="none"
                  stroke="#1e293b"
                  strokeWidth="4"
                  opacity="0.8"
                  strokeLinecap="round"
                />
              )}

              {/* Volume Area Gradient */}
              <path d={areaPath} fill="url(#gradient3DArea)" />

              {/* Secondary 3D Depth Area Ribbon */}
              {is3DMode && (
                <g opacity="0.35">
                  {points.map((pt, i) => (
                    <line
                      key={`drop-${i}`}
                      x1={pt.x}
                      y1={pt.y}
                      x2={pt.x - 6}
                      y2={chartHeight - paddingY + 8}
                      stroke="#3b82f6"
                      strokeWidth="1"
                      strokeDasharray="2 2"
                    />
                  ))}
                </g>
              )}

              {/* Primary 3D Neon Curved Line */}
              <path
                d={linePath}
                fill="none"
                stroke="url(#lineGlow)"
                strokeWidth="3.5"
                strokeLinecap="round"
                filter={is3DMode ? 'url(#shadow3D)' : undefined}
              />

              {/* 3D Floating Data Points */}
              {points.map((pt, idx) => {
                const isHovered = hoveredIdx === idx;
                return (
                  <g
                    key={idx}
                    className="cursor-pointer transition-transform duration-200"
                    onMouseEnter={() => setHoveredIdx(idx)}
                    onClick={() => setHoveredIdx(idx)}
                  >
                    {/* Pulsing ring on hover */}
                    {isHovered && (
                      <circle
                        cx={pt.x}
                        cy={pt.y}
                        r="12"
                        fill="none"
                        stroke="#38bdf8"
                        strokeWidth="1.5"
                        className="animate-ping opacity-75"
                      />
                    )}

                    {/* Main Node Point */}
                    <circle
                      cx={pt.x}
                      cy={pt.y}
                      r={isHovered ? '6' : '4'}
                      fill={isHovered ? '#ffffff' : '#38bdf8'}
                      stroke={isHovered ? '#2563eb' : '#1e3a8a'}
                      strokeWidth="2.5"
                      className="transition-all duration-200"
                    />

                    {/* X-axis Persian Labels */}
                    <text
                      x={pt.x}
                      y={chartHeight - 8}
                      textAnchor="middle"
                      fill={isHovered ? '#60a5fa' : '#94a3b8'}
                      fontSize="10"
                      fontWeight={isHovered ? 'bold' : 'normal'}
                      fontFamily="system-ui"
                    >
                      {pt.label}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Interactive Floating 3D Detail Card at bottom */}
        {hoveredPoint && (
          <div className="mt-2 bg-white/10 backdrop-blur-md border border-white/15 rounded-xl p-2.5 sm:p-3 text-white flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-300 flex items-center justify-center font-bold font-mono">
                {hoveredPoint.label}
              </div>
              <div>
                <span className="text-[10px] text-slate-300 block">شاخص روز انتخابی:</span>
                <span className="font-bold text-sm text-white font-sans">
                  {metric === 'count'
                    ? `${toPersianDigits(hoveredPoint.val)} فاکتور`
                    : formatToman(hoveredPoint.val)}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-4 text-[11px] text-slate-300 font-mono">
              <div>
                <span className="text-slate-400 block text-[9px]">سود تخمینی:</span>
                <span className="text-emerald-400 font-bold">{formatToman(hoveredPoint.secondaryValue)}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[9px]">تراکنش:</span>
                <span className="text-blue-300 font-bold">{toPersianDigits(hoveredPoint.count)} عدد</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
