import React, { useState, useEffect } from 'react';
import { Sidebar } from './Sidebar';
import { Header } from './Header';
import { MobileBottomNav } from './MobileBottomNav';
import { DevicePreviewBar } from './DevicePreviewBar';
import { CurrentUser, DeviceMode, NavItemKey, StoreInfo } from '@/src/types';
import { StorageService } from '@/src/services/storage';
import { ThemeService, ThemeMode } from '@/src/services/theme';
import { HomePlaceholderView } from '@/src/views/HomePlaceholderView';
import { DesignSystemView } from '@/src/views/DesignSystemView';
import { PosView } from '@/src/views/PosView';
import { ProductsView } from '@/src/views/ProductsView';
import { InventoryView } from '@/src/views/InventoryView';
import { PurchasingView } from '@/src/views/PurchasingView';
import { CustomersView } from '@/src/views/CustomersView';
import { ReportsView } from '@/src/views/ReportsView';
import { DevicesView } from '@/src/views/DevicesView';
import { SettingsView } from '@/src/views/SettingsView';

export const AppShell: React.FC = () => {
  const [activeTab, setActiveTab] = useState<NavItemKey>('home');
  const [deviceMode, setDeviceMode] = useState<DeviceMode>('auto');
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);

  // Theme state
  const [currentTheme, setCurrentTheme] = useState<ThemeMode>(() => ThemeService.initTheme());

  const handleToggleTheme = () => {
    const next = ThemeService.toggleTheme();
    setCurrentTheme(next);
  };

  // Store information from StorageService
  const [store, setStore] = useState<StoreInfo>(() => StorageService.getStoreInfo());

  // Current logged in user
  const [user, setUser] = useState<CurrentUser>({
    id: 'u-1',
    name: 'علی محمدی',
    role: 'مدیر',
  });

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <HomePlaceholderView onNavigate={setActiveTab} />;
      case 'design-system':
        return <DesignSystemView />;
      case 'sales':
        return <PosView onNavigate={setActiveTab} store={store} />;
      case 'products':
        return <ProductsView />;
      case 'inventory':
        return <InventoryView />;
      case 'purchases':
        return <PurchasingView />;
      case 'customers':
        return <CustomersView />;
      case 'reports':
        return <ReportsView store={store} />;
      case 'devices':
        return <DevicesView store={store} />;
      case 'settings':
        return (
          <SettingsView
            store={store}
            onUpdateStore={setStore}
            currentTheme={currentTheme}
            onToggleTheme={handleToggleTheme}
          />
        );
      default:
        return <HomePlaceholderView onNavigate={setActiveTab} />;
    }
  };

  // Device simulation wrapper style
  const getDeviceContainerClass = () => {
    switch (deviceMode) {
      case 'desktop':
        return 'w-full max-w-[1280px] my-6 shadow-2xl rounded-2xl border border-slate-300 dark:border-slate-800 overflow-hidden bg-white dark:bg-slate-900 mx-auto';
      case 'tablet':
        return 'w-full max-w-[820px] my-6 shadow-2xl rounded-2xl border border-slate-300 dark:border-slate-800 overflow-hidden bg-white dark:bg-slate-900 mx-auto min-h-[900px]';
      case 'mobile':
        return 'w-full max-w-[395px] my-6 shadow-2xl rounded-[36px] border-[10px] border-slate-800 dark:border-slate-700 overflow-hidden bg-white dark:bg-slate-900 mx-auto min-h-[820px] ring-1 ring-slate-900/10';
      case 'auto':
      default:
        return 'w-full min-h-screen bg-[#F8FAFC] dark:bg-[#0B0F19]';
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950/5 dark:bg-slate-950/40 text-slate-900 dark:text-slate-100 transition-colors">
      {/* Device Mode Switcher bar at the top */}
      <DevicePreviewBar mode={deviceMode} onModeChange={setDeviceMode} />

      {/* Main Container */}
      <div className={`transition-all duration-300 flex-1 flex ${getDeviceContainerClass()}`}>
        {/* Desktop Sidebar (RTL: on the right) */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          store={store}
          user={user}
          isMobileDrawerOpen={isMobileDrawerOpen}
          onCloseMobileDrawer={() => setIsMobileDrawerOpen(false)}
          forceHideDesktop={deviceMode === 'mobile'}
          currentTheme={currentTheme}
          onToggleTheme={handleToggleTheme}
        />

        {/* Content Area */}
        <div className="flex-1 flex flex-col min-w-0 bg-[#F8FAFC] dark:bg-[#0B0F19]">
          <Header
            store={store}
            user={user}
            onOpenMobileMenu={() => setIsMobileDrawerOpen(true)}
            onNewSaleClick={() => setActiveTab('sales')}
            onNavigate={setActiveTab}
            currentTheme={currentTheme}
            onToggleTheme={handleToggleTheme}
            onSwitchUser={setUser}
          />

          <main className={`flex-1 p-2.5 sm:p-4 md:p-6 ${deviceMode === 'mobile' ? 'pb-24' : 'pb-20 lg:pb-6'} overflow-y-auto`}>
            {renderContent()}
          </main>

          {/* Footer Branding */}
          <footer className="py-4 px-6 border-t border-slate-100 dark:border-slate-800/80 bg-white dark:bg-slate-900 text-center text-xs text-slate-400 dark:text-slate-500 transition-colors">
            <div className="flex flex-col sm:flex-row items-center justify-between max-w-7xl mx-auto gap-2">
              <span className="font-medium">
                Fartak POS • <strong className="text-slate-600 dark:text-slate-300 font-semibold">فروش هوشمند، مدیریت ساده</strong>
              </span>
              <span className="text-[11px] text-slate-400 dark:text-slate-500">
                Powered by <strong className="text-slate-700 dark:text-slate-300 font-semibold">TRANOS</strong>
              </span>
            </div>
          </footer>
        </div>
      </div>

      {/* Mobile Bottom Navigation */}
      <MobileBottomNav
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenMoreMenu={() => setIsMobileDrawerOpen(true)}
        forceShow={deviceMode === 'mobile'}
      />
    </div>
  );
};
