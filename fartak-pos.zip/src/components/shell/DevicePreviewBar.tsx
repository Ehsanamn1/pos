import React from 'react';
import { Monitor, Tablet, Smartphone, Maximize2, Sparkles, Activity } from 'lucide-react';
import { DeviceMode } from '@/src/types';

interface DevicePreviewBarProps {
  mode: DeviceMode;
  onModeChange: (mode: DeviceMode) => void;
}

export const DevicePreviewBar: React.FC<DevicePreviewBarProps> = ({
  mode,
  onModeChange,
}) => {
  return (
    <div className="bg-slate-950 text-slate-300 px-4 py-2 flex flex-wrap items-center justify-between text-xs border-b border-slate-800/80 gap-2 z-50 select-none">
      {/* Right side in RTL: Brand & System Status */}
      <div className="flex items-center gap-2.5">
        <span className="relative flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
        </span>
        <span className="font-black text-white font-mono tracking-wide">فرتاک POS</span>
        <span className="text-slate-600">•</span>
        <span className="text-slate-300 text-[11px] font-medium hidden sm:inline">
          سامانه هوشمند صندوق فروشگاهی TRANOS
        </span>
      </div>

      {/* Center: Device Switcher segmented control */}
      <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800 shadow-inner">
        <button
          type="button"
          onClick={() => onModeChange('auto')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs transition-all cursor-pointer ${
            mode === 'auto'
              ? 'bg-blue-600 text-white font-bold shadow-xs'
              : 'text-slate-400 hover:text-white'
          }`}
          title="پاسخگو خودکار بر اساس ابعاد مرورگر"
        >
          <Maximize2 className="w-3.5 h-3.5" />
          <span>پاسخگو خودکار</span>
        </button>

        <button
          type="button"
          onClick={() => onModeChange('desktop')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs transition-all cursor-pointer ${
            mode === 'desktop'
              ? 'bg-blue-600 text-white font-bold shadow-xs'
              : 'text-slate-400 hover:text-white'
          }`}
          title="نمایشگر دسکتاپ و مانیتور لمسی POS"
        >
          <Monitor className="w-3.5 h-3.5" />
          <span>مانیتور دسکتاپ</span>
        </button>

        <button
          type="button"
          onClick={() => onModeChange('tablet')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs transition-all cursor-pointer ${
            mode === 'tablet'
              ? 'bg-blue-600 text-white font-bold shadow-xs'
              : 'text-slate-400 hover:text-white'
          }`}
          title="تبلت پیشخوان فروشگاهی"
        >
          <Tablet className="w-3.5 h-3.5" />
          <span>تبلت فروشگاهی</span>
        </button>

        <button
          type="button"
          onClick={() => onModeChange('mobile')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs transition-all cursor-pointer ${
            mode === 'mobile'
              ? 'bg-blue-600 text-white font-bold shadow-xs'
              : 'text-slate-400 hover:text-white'
          }`}
          title="اپلیکیشن موبایل اندروید فرتاک"
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>اپلیکیشن موبایل</span>
        </button>
      </div>

      {/* Left side in RTL: Cloud status & ping */}
      <div className="hidden xl:flex items-center gap-2 text-[11px] text-slate-400 font-mono">
        <Activity className="w-3.5 h-3.5 text-emerald-400" />
        <span>ابری • پینگ: ۱۲ms</span>
      </div>
    </div>
  );
};
