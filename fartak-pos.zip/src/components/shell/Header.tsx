import React, { useState, useEffect } from 'react';
import {
  Bell,
  Printer,
  ChevronDown,
  Store,
  Menu,
  Sparkles,
  Barcode,
  Wifi,
  Clock,
  Circle,
  Calendar,
  Layers,
  Moon,
  Sun,
  Shield,
} from 'lucide-react';
import { CurrentUser, StoreInfo, NavItemKey } from '@/src/types';
import { toPersianDigits } from '@/src/design-system/tokens';
import { ThemeMode } from '@/src/services/theme';
import { NotificationsModal } from './NotificationsModal';
import { UserProfileModal } from './UserProfileModal';

interface HeaderProps {
  store: StoreInfo;
  user: CurrentUser;
  onOpenMobileMenu?: () => void;
  onNewSaleClick?: () => void;
  onNavigate?: (tab: NavItemKey) => void;
  currentTheme?: ThemeMode;
  onToggleTheme?: () => void;
  onSwitchUser?: (newUser: CurrentUser) => void;
}

export const Header: React.FC<HeaderProps> = ({
  store,
  user,
  onOpenMobileMenu,
  onNewSaleClick,
  onNavigate,
  currentTheme = 'light',
  onToggleTheme,
  onSwitchUser,
}) => {
  const [timeStr, setTimeStr] = useState('');
  const [dateStr, setDateStr] = useState('چهارشنبه ۲۶ شهریور ۱۴۰۵');
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      setTimeStr(`${toPersianDigits(hours)}:${toPersianDigits(minutes)}`);

      try {
        const persianDate = now.toLocaleDateString('fa-IR', {
          weekday: 'long',
          day: 'numeric',
          month: 'long',
          year: 'numeric',
        });
        setDateStr(persianDate);
      } catch {
        setDateStr('چهارشنبه ۲۶ شهریور ۱۴۰۵');
      }
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <header className="sticky top-0 z-30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl border-b border-slate-200/80 dark:border-slate-800 px-3 sm:px-5 py-2 flex items-center justify-between transition-all duration-200 shadow-2xs">
        {/* Right Side (RTL Start): Store Branding, Branch & Real-time Live Clock */}
        <div className="flex items-center gap-2.5">
          {/* Mobile menu hamburger button */}
          <button
            type="button"
            onClick={onOpenMobileMenu}
            className="lg:hidden p-1.5 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-all cursor-pointer active:scale-95 border border-slate-200/60 dark:border-slate-800"
            aria-label="منوی گزینه‌ها"
          >
            <Menu className="w-4 h-4" />
          </button>

          <div className="flex flex-col text-right">
            <div className="flex items-center gap-1.5">
              <h1 className="text-xs sm:text-sm font-black text-slate-900 dark:text-slate-100 tracking-tight flex items-center gap-1">
                <span>{store.name}</span>
              </h1>

              {/* Online Status Pill */}
              <div className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded-full bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/70 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400 text-[10px] font-bold">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span>آنلاین</span>
              </div>
            </div>

            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1">
                <Calendar className="w-2.5 h-2.5 text-slate-400" />
                <span className="text-[10px]">{dateStr}</span>
              </span>

              {timeStr && (
                <>
                  <span className="text-slate-300 dark:text-slate-700">•</span>
                  <span className="flex items-center gap-1 font-mono font-bold text-slate-600 dark:text-slate-300 text-[10px]">
                    <Clock className="w-2.5 h-2.5 text-slate-400" />
                    <span>{timeStr}</span>
                  </span>
                </>
              )}

              <span className="hidden md:inline text-slate-300 dark:text-slate-700">•</span>
              <span className="hidden md:inline-flex items-center gap-1 text-slate-500 dark:text-slate-400 font-medium text-[10px]">
                <Store className="w-2.5 h-2.5 text-slate-400" />
                <span>{store.branch}</span>
              </span>
            </div>
          </div>
        </div>

        {/* Left Side (RTL End): Theme toggle, Chic Actions, Quick New Sale & Profile */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Fast "+ فروش جدید (POS)" CTA button */}
          {onNewSaleClick && (
            <button
              type="button"
              onClick={onNewSaleClick}
              className="hidden sm:inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-2xs transition-all cursor-pointer active:scale-95"
            >
              <Sparkles className="w-3.5 h-3.5 text-blue-200" />
              <span>فروش جدید</span>
            </button>
          )}

          {/* Quick Hardware Status Indicator (Clickable to Devices) */}
          <button
            type="button"
            onClick={() => onNavigate?.('devices')}
            title="مشاهده وضعیت تجهیزات سخت‌افزاری"
            className="hidden xl:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100/70 dark:bg-slate-800/80 hover:bg-slate-200/80 dark:hover:bg-slate-700 border border-slate-200/80 dark:border-slate-700 text-[10px] font-semibold text-slate-600 dark:text-slate-300 cursor-pointer transition-colors"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
            <span>پایانه ۱ • چاپگر آماده</span>
          </button>

          {/* Dark / Light Theme Toggle Button */}
          {onToggleTheme && (
            <button
              type="button"
              onClick={onToggleTheme}
              title={currentTheme === 'dark' ? 'تغییر به حالت روز (روشن)' : 'تغییر به حالت شب (تاریک)'}
              className="p-1.5 text-slate-600 dark:text-amber-400 hover:text-slate-900 dark:hover:text-amber-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-all cursor-pointer border border-transparent hover:border-slate-200/60 dark:hover:border-slate-700 active:scale-90"
              aria-label="تغییر تم تاریک/روشن"
            >
              {currentTheme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-400 animate-in spin-in-180 duration-300" />
              ) : (
                <Moon className="w-4 h-4 text-slate-600 animate-in spin-in-180 duration-300" />
              )}
            </button>
          )}

          {/* Notifications Icon with Badge (Clickable) */}
          <button
            type="button"
            onClick={() => setIsNotificationsOpen(true)}
            title="اطلاعیه‌ها و هشدارها"
            className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-all relative cursor-pointer border border-transparent hover:border-slate-200/60 dark:hover:border-slate-700 active:scale-95"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1 left-1 w-1.5 h-1.5 rounded-full bg-blue-600 ring-1 ring-white dark:ring-slate-900 animate-ping" />
            <span className="absolute top-1 left-1 w-1.5 h-1.5 rounded-full bg-blue-600 ring-1 ring-white dark:ring-slate-900" />
          </button>

          <div className="h-5 w-px bg-slate-200 dark:bg-slate-700 mx-0.5 hidden sm:block" />

          {/* User Profile Pill (Clickable) */}
          <div
            onClick={() => setIsProfileOpen(true)}
            title="پروفایل کاربر و تغییر صندوق‌دار"
            className="flex items-center gap-2 pr-1 pl-1 py-0.5 rounded-lg hover:bg-slate-100/80 dark:hover:bg-slate-800 transition-colors cursor-pointer select-none border border-transparent hover:border-slate-200 dark:hover:border-slate-700"
          >
            <div className="relative">
              <div className="w-7.5 h-7.5 rounded-lg bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-black text-[11px] flex items-center justify-center shadow-2xs ring-1 ring-white dark:ring-slate-800">
                {(user?.name || 'کاربر').slice(0, 2)}
              </div>
              <span className="absolute -bottom-0.5 -left-0.5 w-2 h-2 rounded-full bg-emerald-500 ring-1 ring-white dark:ring-slate-800" />
            </div>

            <div className="hidden md:flex flex-col text-right">
              <span className="text-xs font-bold text-slate-900 dark:text-slate-100 leading-tight flex items-center gap-1">
                <span>{user?.name || 'کاربر'}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </span>
              <span className="text-[9px] text-blue-600 dark:text-blue-400 font-semibold leading-tight mt-0.5">
                {user?.role || 'صندوقدار'}
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Notifications Modal */}
      <NotificationsModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        onNavigate={(tab) => {
          onNavigate?.(tab);
          setIsNotificationsOpen(false);
        }}
      />

      {/* User Profile Modal */}
      <UserProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        currentUser={user}
        store={store}
        onNavigate={(tab) => {
          onNavigate?.(tab);
          setIsProfileOpen(false);
        }}
        currentTheme={currentTheme}
        onToggleTheme={onToggleTheme || (() => {})}
        onSwitchUser={(newUser) => {
          onSwitchUser?.(newUser);
          setIsProfileOpen(false);
        }}
      />
    </>
  );
};
