import React from 'react';
import {
  Home,
  ShoppingCart,
  Package,
  Boxes,
  BarChart3,
  Menu,
  Sparkles,
} from 'lucide-react';
import { NavItemKey } from '@/src/types';

interface MobileBottomNavProps {
  activeTab: NavItemKey;
  onSelectTab: (tab: NavItemKey) => void;
  onOpenMoreMenu: () => void;
  forceShow?: boolean;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  onSelectTab,
  onOpenMoreMenu,
  forceShow = false,
}) => {
  return (
    <div className={`fixed bottom-0 left-0 right-0 z-40 px-3 pb-2 pt-1 pointer-events-none ${forceShow ? 'block' : 'lg:hidden'}`}>
      <nav className="pointer-events-auto max-w-sm mx-auto bg-white/95 dark:bg-slate-900/95 backdrop-blur-2xl border border-slate-200/90 dark:border-slate-800 rounded-2xl px-2 py-1 flex items-center justify-around shadow-[0_8px_30px_rgba(15,23,42,0.12)] ring-1 ring-black/5 dark:ring-white/10 transition-colors">
        {/* Home */}
        <button
          type="button"
          onClick={() => onSelectTab('home')}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-lg transition-all cursor-pointer ${
            activeTab === 'home'
              ? 'text-blue-600 dark:text-blue-400 font-black'
              : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
          }`}
        >
          <Home className="w-4.5 h-4.5 mb-0.5" />
          <span className="text-[10px] leading-tight font-medium">خانه</span>
          {activeTab === 'home' && (
            <span className="w-1 h-1 rounded-full bg-blue-600 dark:bg-blue-400 mt-0.5" />
          )}
        </button>

        {/* Products */}
        <button
          type="button"
          onClick={() => onSelectTab('products')}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-lg transition-all cursor-pointer ${
            activeTab === 'products'
              ? 'text-blue-600 dark:text-blue-400 font-black'
              : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
          }`}
        >
          <Package className="w-4.5 h-4.5 mb-0.5" />
          <span className="text-[10px] leading-tight font-medium">کالاها</span>
          {activeTab === 'products' && (
            <span className="w-1 h-1 rounded-full bg-blue-600 dark:bg-blue-400 mt-0.5" />
          )}
        </button>

        {/* Center Prominent Compact Glowing Button: صندوق */}
        <div className="relative -top-3.5">
          <button
            type="button"
            onClick={() => onSelectTab('sales')}
            className={`
              flex flex-col items-center justify-center w-11 h-11 rounded-xl
              bg-gradient-to-tr from-blue-600 via-blue-600 to-indigo-600 text-white
              shadow-md shadow-blue-600/35 hover:shadow-blue-600/50
              active:scale-95 transition-all cursor-pointer border-2 border-white dark:border-slate-800
              ${activeTab === 'sales' ? 'ring-3 ring-blue-500/30' : ''}
            `}
            aria-label="صندوق فروش"
          >
            <ShoppingCart className="w-5 h-5" />
          </button>
          <span className="block text-center text-[10px] font-black text-blue-700 dark:text-blue-400 mt-0.5">
            صندوق
          </span>
        </div>

        {/* Inventory */}
        <button
          type="button"
          onClick={() => onSelectTab('inventory')}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-lg transition-all cursor-pointer ${
            activeTab === 'inventory'
              ? 'text-blue-600 dark:text-blue-400 font-black'
              : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
          }`}
        >
          <Boxes className="w-4.5 h-4.5 mb-0.5" />
          <span className="text-[10px] leading-tight font-medium">انبار</span>
          {activeTab === 'inventory' && (
            <span className="w-1 h-1 rounded-full bg-blue-600 dark:bg-blue-400 mt-0.5" />
          )}
        </button>

        {/* More / Menu */}
        <button
          type="button"
          onClick={onOpenMoreMenu}
          className="flex flex-col items-center justify-center py-1 px-2.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-all cursor-pointer"
        >
          <Menu className="w-4.5 h-4.5 mb-0.5" />
          <span className="text-[10px] leading-tight font-medium">بیشتر</span>
        </button>
      </nav>
    </div>
  );
};
