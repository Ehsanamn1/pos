import React, { useState } from 'react';
import { Product, NavItemKey } from '@/src/types';
import { StorageService } from '@/src/services/storage';
import { toPersianDigits } from '@/src/design-system/tokens';
import {
  Bell,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Printer,
  ChevronLeft,
  Check,
  X,
} from 'lucide-react';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: NavItemKey) => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
}) => {
  if (!isOpen) return null;

  const products = StorageService.getProducts();
  const lowStock = products.filter((p) => p.currentStock > 0 && p.currentStock <= p.minStock);
  const outOfStock = products.filter((p) => p.currentStock === 0);
  const nearExpiry = products.filter((p) => p.expiryDate && p.expiryDate.includes('۱۴۰۵/۰۶'));

  const [dismissed, setDismissed] = useState<string[]>([]);

  const handleAction = (tab: NavItemKey) => {
    onNavigate(tab);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center sm:justify-end sm:p-6 p-3 bg-black/40 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="w-full max-w-sm sm:mt-12 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[85vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/70 dark:bg-slate-800/40">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-xs text-slate-900 dark:text-slate-100">مرکز اعلان‌ها و هشدارها</h3>
              <span className="text-[10px] text-slate-400">سیستم مدیریت لحظه‌ای فروشگاه</span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-3 space-y-2.5 overflow-y-auto flex-1">
          {/* Out of stock alert */}
          {outOfStock.length > 0 && !dismissed.includes('outOfStock') && (
            <div className="p-3 rounded-xl bg-rose-50/80 dark:bg-rose-950/30 border border-rose-200/80 dark:border-rose-900/40 flex items-start gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-rose-100 dark:bg-rose-900/50 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0 mt-0.5">
                <AlertTriangle className="w-3.5 h-3.5" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-bold text-xs text-rose-950 dark:text-rose-200">
                  {toPersianDigits(outOfStock.length)} کالا اتمام موجودی!
                </h4>
                <p className="text-[11px] text-rose-700 dark:text-rose-300/80 mt-0.5 leading-relaxed">
                  موجودی کالاهایی نظیر {outOfStock[0]?.name} به صفر رسیده و نیازمند سفارش خرید فوری است.
                </p>
                <div className="mt-2 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleAction('inventory')}
                    className="text-[11px] font-bold text-rose-700 dark:text-rose-300 hover:underline flex items-center gap-0.5 cursor-pointer"
                  >
                    <span>بررسی در انبارداری</span>
                    <ChevronLeft className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Low stock alert */}
          {lowStock.length > 0 && !dismissed.includes('lowStock') && (
            <div className="p-3 rounded-xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-900/40 flex items-start gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-400 flex items-center justify-center shrink-0 mt-0.5">
                <AlertTriangle className="w-3.5 h-3.5" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-bold text-xs text-amber-950 dark:text-amber-200">
                  {toPersianDigits(lowStock.length)} کالا رو به اتمام
                </h4>
                <p className="text-[11px] text-amber-700 dark:text-amber-300/80 mt-0.5 leading-relaxed">
                  موجودی اقلامی مانند {lowStock[0]?.name} زیر حداقل حد سفارش است.
                </p>
                <div className="mt-2 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleAction('purchases')}
                    className="text-[11px] font-bold text-amber-800 dark:text-amber-300 hover:underline flex items-center gap-0.5 cursor-pointer"
                  >
                    <span>ثبت سفارش خرید</span>
                    <ChevronLeft className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Near expiry alert */}
          {nearExpiry.length > 0 && !dismissed.includes('nearExpiry') && (
            <div className="p-3 rounded-xl bg-blue-50/80 dark:bg-blue-950/30 border border-blue-200/80 dark:border-blue-900/40 flex items-start gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-400 flex items-center justify-center shrink-0 mt-0.5">
                <Clock className="w-3.5 h-3.5" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-bold text-xs text-blue-950 dark:text-blue-200">
                  کالاهای در آستانه انقضا (سال ۱۴۰۵)
                </h4>
                <p className="text-[11px] text-blue-700 dark:text-blue-300/80 mt-0.5 leading-relaxed">
                  {toPersianDigits(nearExpiry.length)} محصول در شهریور ۱۴۰۵ منقضی خواهند شد؛ تخفیف ویژه یا مرجوعی پیشنهاد می‌شود.
                </p>
                <div className="mt-2 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleAction('inventory')}
                    className="text-[11px] font-bold text-blue-800 dark:text-blue-300 hover:underline flex items-center gap-0.5 cursor-pointer"
                  >
                    <span>بررسی تاریخ‌های انقضا</span>
                    <ChevronLeft className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Device status */}
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700 flex items-start gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
              <Printer className="w-3.5 h-3.5" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-bold text-xs text-slate-900 dark:text-slate-100">وضعیت سخت‌افزارهای صندوق</h4>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                چاپگر حرارتی فیش ۸۰mm و بارکدخوان در وضعیت آنلاین و متصل می‌باشند.
              </p>
              <div className="mt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleAction('devices')}
                  className="text-[11px] font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-0.5 cursor-pointer"
                >
                  <span>مدیریت تجهیزات</span>
                  <ChevronLeft className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/20 flex items-center justify-between">
          <button
            type="button"
            onClick={() => setDismissed(['outOfStock', 'lowStock', 'nearExpiry'])}
            className="text-[11px] font-bold text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 flex items-center gap-1 cursor-pointer"
          >
            <Check className="w-3 h-3" />
            <span>خواندن همه اعلان‌ها</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-lg cursor-pointer transition-colors"
          >
            بستن
          </button>
        </div>
      </div>
    </div>
  );
};
