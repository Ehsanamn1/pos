import React from 'react';
import {
  Home,
  ShoppingCart,
  Package,
  Boxes,
  Truck,
  Users,
  BarChart3,
  Cpu,
  Settings,
  Palette,
  LogOut,
  ChevronLeft,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  Moon,
  Sun,
} from 'lucide-react';
import { FartakLogo } from '@/src/design-system/FartakLogo';
import { CurrentUser, NavItemKey, StoreInfo } from '@/src/types';
import { ThemeMode } from '@/src/services/theme';

interface NavItemConfig {
  key: NavItemKey;
  label: string;
  subLabel?: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
  badgeVariant?: 'primary' | 'success' | 'neutral';
}

const navItems: NavItemConfig[] = [
  { key: 'home', label: 'داشبورد اصلی', icon: Home },
  { key: 'sales', label: 'صندوق فروش و POS', icon: ShoppingCart, badge: 'زنده', badgeVariant: 'primary' },
  { key: 'products', label: 'مدیریت کالاها', icon: Package },
  { key: 'inventory', label: 'انبارداری و انقضا', icon: Boxes },
  { key: 'purchases', label: 'خرید و تأمین‌کنندگان', icon: Truck },
  { key: 'customers', label: 'مشتریان و حساب‌ها', icon: Users },
  { key: 'reports', label: 'گزارش‌ها و آمار', icon: BarChart3 },
  { key: 'devices', label: 'دستگاه‌ها و چاپگرها', icon: Cpu },
  { key: 'settings', label: 'تنظیمات فروشگاه', icon: Settings },
  { key: 'design-system', label: 'سیستم طراحی UI', icon: Palette, badge: 'مستندات', badgeVariant: 'neutral' },
];

interface SidebarProps {
  activeTab: NavItemKey;
  onSelectTab: (tab: NavItemKey) => void;
  store: StoreInfo;
  user: CurrentUser;
  isMobileDrawerOpen?: boolean;
  onCloseMobileDrawer?: () => void;
  forceHideDesktop?: boolean;
  currentTheme?: ThemeMode;
  onToggleTheme?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  store,
  user,
  isMobileDrawerOpen = false,
  onCloseMobileDrawer,
  forceHideDesktop = false,
  currentTheme = 'light',
  onToggleTheme,
}) => {
  const content = (
    <div className="h-full flex flex-col justify-between bg-white dark:bg-slate-900 select-none border-l border-slate-200/80 dark:border-slate-800 transition-colors">
      {/* Top section: Brand Logo & Navigation */}
      <div className="flex-1 overflow-y-auto">
        {/* Brand Header */}
        <div className="p-5 border-b border-slate-100/90 dark:border-slate-800 bg-gradient-to-b from-slate-50/80 to-white dark:from-slate-800/50 dark:to-slate-900 flex items-center justify-between">
          <FartakLogo size="md" showSubtitle showTagline={false} />
          {onToggleTheme && (
            <button
              type="button"
              onClick={onToggleTheme}
              title={currentTheme === 'dark' ? 'حالت روز' : 'حالت شب'}
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              {currentTheme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
            </button>
          )}
        </div>

        {/* Navigation list */}
        <div className="p-3.5 space-y-1">
          <div className="px-3 pt-2 pb-1.5 text-[11px] font-black text-slate-400 dark:text-slate-500 tracking-wider">
            منوی مدیریت فروشگاه
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.key;
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => {
                  onSelectTab(item.key);
                  if (onCloseMobileDrawer) onCloseMobileDrawer();
                }}
                className={`
                  w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold
                  transition-all duration-200 cursor-pointer group relative
                  ${
                    isActive
                      ? 'bg-gradient-to-l from-blue-50/90 to-blue-50/40 dark:from-blue-900/40 dark:to-blue-900/10 text-blue-700 dark:text-blue-300 shadow-xs border-r-4 border-blue-600 font-black'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50/80 dark:hover:bg-slate-800/60'
                  }
                `}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${
                      isActive
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-slate-100/70 dark:bg-slate-800 text-slate-500 dark:text-slate-400 group-hover:bg-slate-200/70 dark:group-hover:bg-slate-700 group-hover:text-slate-800 dark:group-hover:text-white'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className="text-right">{item.label}</span>
                </div>

                {item.badge ? (
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full transition-all ${
                      isActive
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 group-hover:bg-slate-200 dark:group-hover:bg-slate-700'
                    }`}
                  >
                    {item.badge}
                  </span>
                ) : (
                  <ChevronLeft
                    className={`w-3.5 h-3.5 transition-transform duration-200 ${
                      isActive
                        ? 'text-blue-600 dark:text-blue-400 translate-x-0'
                        : 'text-slate-300 dark:text-slate-600 opacity-0 group-hover:opacity-100 group-hover:-translate-x-0.5'
                    }`}
                  />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Bottom section: System Health Status & User Profile */}
      <div className="p-3.5 border-t border-slate-100 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 space-y-3">
        {/* Hardware Status Widget - Clickable to Devices view */}
        <button
          type="button"
          onClick={() => {
            onSelectTab('devices');
            if (onCloseMobileDrawer) onCloseMobileDrawer();
          }}
          className="w-full text-right p-2.5 bg-white dark:bg-slate-800/80 rounded-xl border border-slate-200/70 dark:border-slate-700 shadow-2xs text-[11px] space-y-1.5 hover:border-blue-300 dark:hover:border-blue-600 transition-colors cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-700 dark:text-slate-200 font-bold">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              <span>پایانه صندوق آماده</span>
            </span>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-md font-bold">
              متصل
            </span>
          </div>
          <div className="text-[10px] text-slate-400 dark:text-slate-400 flex items-center justify-between">
            <span>چاپگر: ۸۰mm</span>
            <span className="text-blue-600 dark:text-blue-400 group-hover:underline">مدیریت دستگاه‌ها ←</span>
          </div>
        </button>

        {/* User Card */}
        <div
          onClick={() => {
            onSelectTab('settings');
            if (onCloseMobileDrawer) onCloseMobileDrawer();
          }}
          className="p-2.5 bg-white dark:bg-slate-800/80 rounded-xl border border-slate-200/70 dark:border-slate-700 shadow-2xs flex items-center justify-between cursor-pointer hover:border-blue-300 dark:hover:border-blue-600 transition-colors"
          title="تنظیمات حساب کاربری"
        >
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
              {(user?.name || 'کاربر').slice(0, 2)}
            </div>
            <div className="flex flex-col truncate text-right">
              <span className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">{store?.name || 'فروشگاه'}</span>
              <span className="text-[10px] text-slate-400 truncate">{user?.name || 'صندوقدار'} ({user?.role || 'کاربر'})</span>
            </div>
          </div>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onSelectTab('settings');
              if (onCloseMobileDrawer) onCloseMobileDrawer();
            }}
            title="تنظیمات"
            className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>

        {/* Branding footer */}
        <div className="text-center pt-1">
          <p className="text-[10px] text-slate-400 dark:text-slate-500 font-medium">
            Fartak POS • Powered by <strong className="text-slate-700 dark:text-slate-300 font-bold">TRANOS</strong>
          </p>
          <p className="text-[9px] text-blue-600 dark:text-blue-400 mt-0.5 font-bold">
            فروش هوشمند، مدیریت ساده
          </p>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar (RTL: on the right side) */}
      <aside className={`${forceHideDesktop ? 'hidden' : 'hidden lg:block'} w-68 shrink-0 h-screen sticky top-0 z-40 bg-white dark:bg-slate-900`}>
        {content}
      </aside>

      {/* Mobile Drawer */}
      {isMobileDrawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          {/* Backdrop */}
          <div
            onClick={onCloseMobileDrawer}
            className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs transition-opacity animate-in fade-in"
          />

          {/* Drawer Content (slide from right in RTL) */}
          <div className="relative w-72 max-w-[85vw] bg-white dark:bg-slate-900 h-full shadow-2xl z-10 flex flex-col animate-in slide-in-from-right duration-200">
            {content}
          </div>
        </div>
      )}
    </>
  );
};
