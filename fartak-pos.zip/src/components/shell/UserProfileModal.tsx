import React, { useState } from 'react';
import { CurrentUser, NavItemKey, StoreInfo } from '@/src/types';
import { StorageService } from '@/src/services/storage';
import { ThemeService, ThemeMode } from '@/src/services/theme';
import {
  User,
  LogOut,
  Shield,
  Settings,
  Moon,
  Sun,
  Store,
  Check,
  X,
  UserCheck,
} from 'lucide-react';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: CurrentUser;
  store: StoreInfo;
  onNavigate: (tab: NavItemKey) => void;
  currentTheme: ThemeMode;
  onToggleTheme: () => void;
  onSwitchUser: (newUser: CurrentUser) => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  store,
  onNavigate,
  currentTheme,
  onToggleTheme,
  onSwitchUser,
}) => {
  if (!isOpen) return null;

  const users = StorageService.getUsers();

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center sm:justify-end sm:p-6 p-3 bg-black/40 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="w-full max-w-xs sm:mt-12 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Profile Info */}
        <div className="p-4 bg-gradient-to-br from-blue-600 to-indigo-700 text-white relative">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3 left-3 p-1 text-white/80 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-sm text-white font-black text-lg flex items-center justify-center border border-white/30 shadow-xs">
              {(currentUser?.name || 'کاربر').slice(0, 2)}
            </div>
            <div>
              <h3 className="font-black text-sm">{currentUser?.name || 'کاربر'}</h3>
              <div className="text-[11px] text-blue-100 flex items-center gap-1 mt-0.5">
                <Shield className="w-3 h-3 text-blue-200" />
                <span>نقش: {currentUser?.role || 'کاربر'}</span>
              </div>
              <div className="text-[10px] text-blue-200 flex items-center gap-1 mt-0.5">
                <Store className="w-2.5 h-2.5" />
                <span>{store?.name || 'فروشگاه'} ({store?.branch || 'شعبه اصلی'})</span>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions List */}
        <div className="p-3 space-y-1 text-xs">
          {/* Theme Switcher in User Menu */}
          <button
            type="button"
            onClick={onToggleTheme}
            className="w-full p-2.5 rounded-xl flex items-center justify-between hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer text-slate-700 dark:text-slate-200"
          >
            <div className="flex items-center gap-2.5">
              {currentTheme === 'dark' ? (
                <Moon className="w-4 h-4 text-blue-400" />
              ) : (
                <Sun className="w-4 h-4 text-amber-500" />
              )}
              <span className="font-bold">حالت شب و روز (تم تاریک)</span>
            </div>
            <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 font-bold">
              {currentTheme === 'dark' ? 'حالت شب' : 'حالت روز'}
            </span>
          </button>

          {/* Settings Navigation */}
          <button
            type="button"
            onClick={() => {
              onNavigate('settings');
              onClose();
            }}
            className="w-full p-2.5 rounded-xl flex items-center gap-2.5 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer text-slate-700 dark:text-slate-200"
          >
            <Settings className="w-4 h-4 text-slate-400" />
            <span className="font-bold">تنظیمات فروشگاه و فاکتور</span>
          </button>

          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 my-1">
            <span className="text-[10px] font-bold text-slate-400 px-2 uppercase tracking-wider block mb-1">
              تغییر سریع کاربر / صندوق‌دار:
            </span>

            <div className="space-y-1">
              {users.map((u) => {
                const isSelected = u.name === currentUser.name;
                return (
                  <button
                    key={u.id}
                    type="button"
                    onClick={() => {
                      onSwitchUser({
                        id: u.id,
                        name: u.name,
                        role: u.role,
                        avatar: '',
                      });
                      onClose();
                    }}
                    className={`w-full p-2 rounded-xl flex items-center justify-between transition-colors cursor-pointer text-xs ${
                      isSelected
                        ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 font-bold'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-[10px] font-bold">
                        {(u?.name || 'ک').slice(0, 1)}
                      </div>
                      <span>{u?.name || 'کاربر'}</span>
                      <span className="text-[10px] text-slate-400">({u?.role || 'کاربر'})</span>
                    </div>
                    {isSelected && <Check className="w-3.5 h-3.5 text-blue-600" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-1.5 px-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-bold transition-colors cursor-pointer text-center"
          >
            بستن
          </button>
        </div>
      </div>
    </div>
  );
};
