import React from 'react';

interface FartakLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
  showTagline?: boolean;
  align?: 'start' | 'center';
  className?: string;
}

export const FartakLogo: React.FC<FartakLogoProps> = ({
  size = 'md',
  showSubtitle = true,
  showTagline = false,
  align = 'start',
  className = '',
}) => {
  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16',
  };

  const titleSizes = {
    sm: 'text-base',
    md: 'text-lg',
    lg: 'text-2xl',
    xl: 'text-3xl',
  };

  const subtitleSizes = {
    sm: 'text-[9px]',
    md: 'text-[11px]',
    lg: 'text-xs',
    xl: 'text-sm',
  };

  return (
    <div
      id="fartak-brand-logo"
      className={`flex items-center gap-3 select-none ${
        align === 'center' ? 'flex-col justify-center text-center' : 'justify-start'
      } ${className}`}
    >
      {/* Origami / Ribbon Stylized 'F' Logo Icon */}
      <div className={`relative flex items-center justify-center ${iconSizes[size]} shrink-0`}>
        <svg
          viewBox="0 0 48 48"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-sm"
        >
          {/* Back fold / base */}
          <path
            d="M12 40L24 28L36 28L24 40H12Z"
            fill="#1D4ED8"
          />
          {/* Main vertical & upper bar stem */}
          <path
            d="M14 8C14 6.89543 14.8954 6 16 6H38C39.1046 6 40 6.89543 40 8V16C40 17.1046 39.1046 18 38 18H26L18 26H14V8Z"
            fill="#2563EB"
          />
          {/* Mid horizontal crossbar */}
          <path
            d="M18 20H32C33.1046 20 34 20.8954 34 22V26C34 27.1046 33.1046 28 32 28H22L18 24V20Z"
            fill="#3B82F6"
          />
          {/* Highlight light accent reflection */}
          <path
            d="M20 10H36V14H22L20 10Z"
            fill="#93C5FD"
            opacity="0.8"
          />
        </svg>
      </div>

      <div className={`flex flex-col ${align === 'center' ? 'items-center' : 'items-start'}`}>
        <div className="flex items-center gap-1.5 leading-none">
          <span className={`font-bold tracking-tight text-slate-900 font-display ${titleSizes[size]}`}>
            Fartak POS
          </span>
        </div>

        {showSubtitle && (
          <span className={`font-medium tracking-wider text-slate-400 mt-1 uppercase ${subtitleSizes[size]}`}>
            Powered by <strong className="text-slate-600 font-semibold">TRANOS</strong>
          </span>
        )}

        {showTagline && (
          <span className="text-xs text-blue-600 font-medium mt-1">
            فروش هوشمند، مدیریت ساده
          </span>
        )}
      </div>
    </div>
  );
};
