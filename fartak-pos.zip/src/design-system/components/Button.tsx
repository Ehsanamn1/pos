import React from 'react';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger' | 'success';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  icon?: React.ReactNode;
  iconPosition?: 'start' | 'end';
  fullWidth?: boolean;
  loading?: boolean;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  icon,
  iconPosition = 'start',
  fullWidth = false,
  loading = false,
  className = '',
  disabled,
  ...props
}) => {
  const baseClasses =
    'inline-flex items-center justify-center font-medium transition-all duration-150 active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none select-none cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500/20';

  const sizeClasses = {
    sm: 'text-[11px] h-7 px-2.5 rounded-lg gap-1 font-medium',
    md: 'text-xs h-8.5 px-3.5 rounded-lg gap-1.5 font-medium',
    lg: 'text-xs sm:text-sm h-10 px-4 rounded-xl gap-2 font-semibold',
    xl: 'text-sm sm:text-base h-11 px-5 rounded-xl gap-2 font-semibold shadow-xs',
  };

  const variantClasses = {
    primary:
      'bg-blue-600 text-white hover:bg-blue-700 active:bg-blue-800 shadow-sm shadow-blue-500/10 border border-blue-600',
    secondary:
      'bg-blue-50 text-blue-700 hover:bg-blue-100 active:bg-blue-200 border border-blue-100',
    outline:
      'bg-white text-slate-700 hover:bg-slate-50 active:bg-slate-100 border border-slate-200 hover:border-slate-300 shadow-xs',
    ghost:
      'bg-transparent text-slate-600 hover:bg-slate-100/70 active:bg-slate-200/70 border border-transparent',
    danger:
      'bg-rose-500 text-white hover:bg-rose-600 active:bg-rose-700 border border-rose-500 shadow-sm shadow-rose-500/10',
    success:
      'bg-emerald-600 text-white hover:bg-emerald-700 active:bg-emerald-800 border border-emerald-600 shadow-sm shadow-emerald-500/10',
  };

  return (
    <button
      className={`
        ${baseClasses}
        ${sizeClasses[size]}
        ${variantClasses[variant]}
        ${fullWidth ? 'w-full' : ''}
        ${className}
      `}
      disabled={disabled || loading}
      {...props}
    >
      {loading ? (
        <span className="inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
      ) : (
        <>
          {icon && iconPosition === 'start' && <span className="shrink-0">{icon}</span>}
          {children && <span>{children}</span>}
          {icon && iconPosition === 'end' && <span className="shrink-0">{icon}</span>}
        </>
      )}
    </button>
  );
};
