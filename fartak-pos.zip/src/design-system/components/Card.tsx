import React from 'react';

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  interactive?: boolean;
  padded?: boolean;
  className?: string;
}

export const Card: React.FC<CardProps> = ({
  children,
  interactive = false,
  padded = true,
  className = '',
  ...props
}) => {
  return (
    <div
      className={`
        bg-white dark:bg-slate-900 rounded-2xl border border-slate-100/90 dark:border-slate-800/90
        shadow-[0_2px_10px_-2px_rgba(15,23,42,0.04),0_1px_3px_-1px_rgba(15,23,42,0.02)]
        dark:shadow-[0_4px_20px_-4px_rgba(0,0,0,0.5)]
        ${padded ? 'p-5' : ''}
        ${interactive ? 'transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_10px_20px_-5px_rgba(15,23,42,0.06)] hover:border-slate-200 dark:hover:border-slate-700 cursor-pointer' : ''}
        ${className}
      `}
      {...props}
    >
      {children}
    </div>
  );
};

export const CardHeader: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({
  children,
  className = '',
  ...props
}) => (
  <div className={`flex items-center justify-between pb-3 mb-3 border-b border-slate-100 dark:border-slate-800 ${className}`} {...props}>
    {children}
  </div>
);

export const CardTitle: React.FC<React.HTMLAttributes<HTMLHeadingElement>> = ({
  children,
  className = '',
  ...props
}) => (
  <h3 className={`text-base font-bold text-slate-900 dark:text-slate-100 tracking-tight ${className}`} {...props}>
    {children}
  </h3>
);

export interface MetricCardProps {
  title: string;
  value: string;
  trend?: {
    text: string;
    isPositive?: boolean;
    isNeutral?: boolean;
  };
  icon?: React.ReactNode;
  subtitle?: string;
  className?: string;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  trend,
  icon,
  subtitle,
  className = '',
}) => {
  return (
    <Card className={`relative overflow-hidden ${className}`}>
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">{title}</p>
          <div className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight font-sans">
            {value}
          </div>
        </div>
        {icon && (
          <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0 border border-blue-100/60 dark:border-blue-800/40">
            {icon}
          </div>
        )}
      </div>

      {(trend || subtitle) && (
        <div className="mt-3 pt-3 border-t border-slate-50 dark:border-slate-800 flex items-center justify-between text-xs">
          {trend && (
            <span
              className={`inline-flex items-center gap-1 font-semibold ${
                trend.isNeutral
                  ? 'text-slate-500 dark:text-slate-400'
                  : trend.isPositive
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : 'text-rose-600 dark:text-rose-400'
              }`}
            >
              {trend.text}
            </span>
          )}
          {subtitle && <span className="text-slate-400 dark:text-slate-500 mr-auto">{subtitle}</span>}
        </div>
      )}
    </Card>
  );
};

export interface AlertBannerProps {
  type: 'warning' | 'danger' | 'info' | 'success';
  title: string;
  subtitle?: string;
  badgeText?: string;
  actionText?: string;
  onAction?: () => void;
  icon?: React.ReactNode;
  className?: string;
}

export const AlertBanner: React.FC<AlertBannerProps> = ({
  type,
  title,
  subtitle,
  badgeText,
  actionText,
  onAction,
  icon,
  className = '',
}) => {
  const styles = {
    warning: {
      card: 'border-amber-200/80 dark:border-amber-800/60 bg-gradient-to-r from-amber-50/50 dark:from-amber-950/20 to-white dark:to-slate-900',
      badge: 'bg-amber-100 dark:bg-amber-900/40 text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-800',
      icon: 'text-amber-600 dark:text-amber-400 bg-amber-100/80 dark:bg-amber-900/40',
      text: 'text-amber-900 dark:text-amber-200',
    },
    danger: {
      card: 'border-rose-200/80 dark:border-rose-800/60 bg-gradient-to-r from-rose-50/50 dark:from-rose-950/20 to-white dark:to-slate-900',
      badge: 'bg-rose-100 dark:bg-rose-900/40 text-rose-800 dark:text-rose-300 border-rose-200 dark:border-rose-800',
      icon: 'text-rose-600 dark:text-rose-400 bg-rose-100/80 dark:bg-rose-900/40',
      text: 'text-rose-900 dark:text-rose-200',
    },
    info: {
      card: 'border-blue-200/80 dark:border-blue-800/60 bg-gradient-to-r from-blue-50/50 dark:from-blue-950/20 to-white dark:to-slate-900',
      badge: 'bg-blue-100 dark:bg-blue-900/40 text-blue-800 dark:text-blue-300 border-blue-200 dark:border-blue-800',
      icon: 'text-blue-600 dark:text-blue-400 bg-blue-100/80 dark:bg-blue-900/40',
      text: 'text-blue-900 dark:text-blue-200',
    },
    success: {
      card: 'border-emerald-200/80 dark:border-emerald-800/60 bg-gradient-to-r from-emerald-50/50 dark:from-emerald-950/20 to-white dark:to-slate-900',
      badge: 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
      icon: 'text-emerald-600 dark:text-emerald-400 bg-emerald-100/80 dark:bg-emerald-900/40',
      text: 'text-emerald-900 dark:text-emerald-200',
    },
  };

  const current = styles[type];

  return (
    <div
      onClick={onAction}
      className={`
        p-3.5 sm:p-4 rounded-2xl border transition-all duration-150 flex items-center justify-between gap-3
        ${current.card}
        ${onAction ? 'cursor-pointer hover:shadow-sm active:scale-[0.99]' : ''}
        ${className}
      `}
    >
      <div className="flex items-center gap-3">
        {icon && (
          <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${current.icon}`}>
            {icon}
          </div>
        )}
        <div>
          <div className="flex items-center gap-2">
            <span className={`text-sm font-bold ${current.text}`}>{title}</span>
            {badgeText && (
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium border ${current.badge}`}>
                {badgeText}
              </span>
            )}
          </div>
          {subtitle && <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{subtitle}</p>}
        </div>
      </div>

      {actionText && (
        <span className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:text-blue-700 shrink-0">
          {actionText} ←
        </span>
      )}
    </div>
  );
};
