import React from 'react';
import { Search, ScanLine } from 'lucide-react';

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helperText?: string;
  startIcon?: React.ReactNode;
  endIcon?: React.ReactNode;
  fullWidth?: boolean;
}

export const Input: React.FC<InputProps> = ({
  label,
  error,
  helperText,
  startIcon,
  endIcon,
  fullWidth = true,
  className = '',
  id,
  ...props
}) => {
  const inputId = id || (label ? `input-${label.replace(/\s+/g, '-').toLowerCase()}` : undefined);

  return (
    <div className={`${fullWidth ? 'w-full' : ''} space-y-1.5 text-right`}>
      {label && (
        <label htmlFor={inputId} className="block text-xs font-semibold text-slate-700">
          {label}
        </label>
      )}

      <div className="relative flex items-center">
        {startIcon && (
          <div className="absolute right-3.5 flex items-center pointer-events-none text-slate-400">
            {startIcon}
          </div>
        )}

        <input
          id={inputId}
          className={`
            w-full bg-white text-slate-800 placeholder:text-slate-400 text-xs sm:text-sm font-medium
            border rounded-lg sm:rounded-xl transition-all duration-150
            focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500
            ${startIcon ? 'pr-9' : 'pr-3'}
            ${endIcon ? 'pl-9' : 'pl-3'}
            py-2
            ${error ? 'border-rose-400 focus:border-rose-500 focus:ring-rose-500/20' : 'border-slate-200 hover:border-slate-300'}
            disabled:bg-slate-50 disabled:text-slate-400 disabled:cursor-not-allowed
            ${className}
          `}
          {...props}
        />

        {endIcon && (
          <div className="absolute left-3.5 flex items-center text-slate-400">
            {endIcon}
          </div>
        )}
      </div>

      {error ? (
        <p className="text-[11px] text-rose-500 font-medium">{error}</p>
      ) : helperText ? (
        <p className="text-[11px] text-slate-400">{helperText}</p>
      ) : null}
    </div>
  );
};

export interface SearchBarProps {
  placeholder?: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onScanClick?: () => void;
  className?: string;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  placeholder = 'جستجو کالا / اسکن بارکد...',
  value,
  onChange,
  onScanClick,
  className = '',
}) => {
  return (
    <div className={`relative flex items-center w-full ${className}`}>
      <div className="absolute right-3.5 flex items-center pointer-events-none text-slate-400">
        <Search className="w-4 h-4" />
      </div>

      <input
        type="text"
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="w-full bg-white text-slate-800 placeholder:text-slate-400 text-xs sm:text-sm font-medium
          border border-slate-200 rounded-lg sm:rounded-xl pr-9 pl-9 py-2
          focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500
          transition-all duration-150 shadow-2xs"
      />

      {onScanClick && (
        <button
          type="button"
          onClick={onScanClick}
          title="اسکن بارکد"
          className="absolute left-2.5 p-1.5 text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
        >
          <ScanLine className="w-4 h-4" />
        </button>
      )}
    </div>
  );
};
