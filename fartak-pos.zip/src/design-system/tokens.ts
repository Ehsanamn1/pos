/**
 * Fartak POS Design Tokens
 * Extracted directly from reference designs:
 * - Light premium UI
 * - White surfaces (#FFFFFF)
 * - Soft cool off-white background (#F8FAFC)
 * - Soft royal blue primary accents (#2563EB)
 * - Subtle green success (#10B981)
 * - Orange warning states (#F59E0B)
 * - Red danger states (#EF4444)
 * - Persian RTL typography with Vazirmatn
 */

export const colors = {
  brand: {
    50: '#EFF6FF',
    100: '#DBEAFE',
    200: '#BFDBFE',
    300: '#93C5FD',
    400: '#60A5FA',
    500: '#3B82F6',
    600: '#2563EB', // Primary Brand Blue
    700: '#1D4ED8',
    800: '#1E40AF',
    900: '#1E3A8A',
  },
  surface: {
    bg: '#F8FAFC',
    card: '#FFFFFF',
    border: '#F1F5F9',
    borderLight: 'rgba(241, 245, 249, 0.9)',
    borderHover: '#CBD5E1',
    divider: '#E2E8F0',
  },
  text: {
    primary: '#0F172A',
    secondary: '#475569',
    muted: '#94A3B8',
    inverse: '#FFFFFF',
  },
  success: {
    50: '#ECFDF5',
    100: '#D1FAE5',
    500: '#10B981',
    600: '#059669',
    700: '#047857',
  },
  warning: {
    50: '#FFFBEB',
    100: '#FEF3C7',
    500: '#F59E0B',
    600: '#D97706',
    700: '#B45309',
  },
  danger: {
    50: '#FEF2F2',
    100: '#FEE2E2',
    500: '#EF4444',
    600: '#DC2626',
    700: '#B91C1C',
  },
} as const;

/** Convert English digits to Persian digits */
export function toPersianDigits(num: string | number | undefined | null): string {
  if (num === undefined || num === null) return '';
  const str = String(num);
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return str.replace(/[0-9]/g, (w) => persianDigits[+w]);
}

/** Format currency with Persian separators and Tomans */
export function formatToman(amount: number): string {
  const formatted = new Intl.NumberFormat('en-US').format(amount);
  return `${toPersianDigits(formatted)} تومان`;
}

/** Format percentage with Persian digits */
export function formatPercent(percent: number, withSign = true): string {
  const sign = withSign && percent > 0 ? '+' : '';
  return `${toPersianDigits(percent)}${sign}٪`;
}
