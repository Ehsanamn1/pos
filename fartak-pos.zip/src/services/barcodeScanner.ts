import { Product } from '../types';

type ScanCallback = (barcode: string, product?: Product) => void;

class BarcodeScannerService {
  private buffer = '';
  private lastKeyTime = 0;
  private listeners: ScanCallback[] = [];
  private productsGetter: () => Product[] = () => [];
  private isInitialized = false;

  constructor() {
    this.handleKeyDown = this.handleKeyDown.bind(this);
  }

  public init(getProducts: () => Product[]): () => void {
    this.productsGetter = getProducts;

    if (!this.isInitialized && typeof window !== 'undefined') {
      window.addEventListener('keydown', this.handleKeyDown);
      this.isInitialized = true;
    }

    return () => {
      this.destroy();
    };
  }

  public destroy(): void {
    if (this.isInitialized && typeof window !== 'undefined') {
      window.removeEventListener('keydown', this.handleKeyDown);
      this.isInitialized = false;
    }
  }

  public subscribe(callback: ScanCallback): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter((cb) => cb !== callback);
    };
  }

  public simulateScan(barcode: string): void {
    this.playBeep();
    const products = this.productsGetter();
    const product = products.find((p) => p.barcode === barcode.trim());
    this.listeners.forEach((cb) => cb(barcode.trim(), product));
  }

  private handleKeyDown(e: KeyboardEvent): void {
    // Ignore keystrokes inside regular input fields
    const target = e.target as HTMLElement;
    if (
      target.tagName === 'INPUT' ||
      target.tagName === 'TEXTAREA' ||
      target.isContentEditable
    ) {
      return;
    }

    const currentTime = Date.now();
    const char = e.key;

    // Barcode scanners type very quickly (<50ms per key)
    if (currentTime - this.lastKeyTime > 80) {
      this.buffer = '';
    }
    this.lastKeyTime = currentTime;

    if (char === 'Enter') {
      if (this.buffer.length >= 3) {
        this.simulateScan(this.buffer);
      }
      this.buffer = '';
    } else if (char.length === 1) {
      this.buffer += char;
    }
  }

  public playBeep(type: 'success' | 'error' = 'success'): void {
    try {
      const AudioContext = window.AudioContext || (window as unknown as { webkitAudioContext: typeof window.AudioContext }).webkitAudioContext;
      if (!AudioContext) return;

      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.connect(gain);
      gain.connect(ctx.destination);

      if (type === 'success') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1800, ctx.currentTime);
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12);
        osc.start();
        osc.stop(ctx.currentTime + 0.12);
      } else {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(350, ctx.currentTime);
        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
        osc.start();
        osc.stop(ctx.currentTime + 0.25);
      }
    } catch {
      // Audio not permitted or not supported
    }
  }
}

export const scannerService = new BarcodeScannerService();
