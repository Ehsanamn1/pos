import { Sale, StoreInfo, ProformaInvoice } from '../types';
import { toPersianDigits, formatToman } from '../design-system/tokens';

export class PrinterService {
  public static printReceipt(sale: Sale, store: StoreInfo, paperWidth: '58mm' | '80mm' = '80mm'): void {
    const printWindow = window.open('', '_blank', 'width=420,height=700');
    if (!printWindow) {
      alert('لطفاً اجازه باز شدن پنجره پاپ‌آپ چاپگر را در مرورگر فعال کنید.');
      return;
    }

    const is58 = paperWidth === '58mm';
    const containerWidth = is58 ? '54mm' : '76mm';
    const fontSize = is58 ? '11px' : '13px';

    const itemsHtml = sale.items
      .map(
        (item, idx) => `
        <tr style="border-bottom: 1px dashed #ddd;">
          <td style="padding: 4px 0; text-align: right;">
            <div><strong>${item.productName}</strong></div>
            <div style="font-size: 10px; color: #666;">${toPersianDigits(item.quantity)} × ${formatToman(item.unitPrice)}</div>
          </td>
          <td style="padding: 4px 0; text-align: left; vertical-align: top; white-space: nowrap;">
            <strong>${formatToman(item.total)}</strong>
          </td>
        </tr>
      `
      )
      .join('');

    const html = `
      <!DOCTYPE html>
      <html dir="rtl" lang="fa">
      <head>
        <meta charset="utf-8">
        <title>فاکتور فروش #${toPersianDigits(sale.invoiceNumber)}</title>
        <style>
          @page {
            margin: 0;
            size: ${paperWidth} auto;
          }
          body {
            font-family: system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            margin: 0;
            padding: 8px;
            background: #fff;
            color: #000;
            font-size: ${fontSize};
            line-height: 1.4;
            direction: rtl;
          }
          .receipt {
            width: ${containerWidth};
            margin: 0 auto;
          }
          .text-center { text-align: center; }
          .text-left { text-align: left; }
          .text-right { text-align: right; }
          .bold { font-weight: bold; }
          .divider { border-top: 1px dashed #444; margin: 6px 0; }
          .double-divider { border-top: 2px solid #000; margin: 8px 0; }
          table { width: 100%; border-collapse: collapse; margin: 6px 0; }
          .footer-text { font-size: 10px; color: #555; text-align: center; margin-top: 12px; }
          .barcode-box {
            font-family: monospace;
            letter-spacing: 4px;
            font-size: 15px;
            font-weight: bold;
            text-align: center;
            margin: 8px 0;
          }
        </style>
      </head>
      <body>
        <div class="receipt">
          <div class="text-center">
            <h2 style="margin: 0 0 4px 0; font-size: 16px;">${store.name}</h2>
            <div style="font-size: 11px; color: #333;">${store.branch}</div>
            <div style="font-size: 10px; color: #666;">تلفن: ${toPersianDigits(store.phone)}</div>
            <div style="font-size: 9px; color: #666;">${store.address}</div>
          </div>

          <div class="divider"></div>

          <div style="display: flex; justify-content: space-between; font-size: 11px;">
            <span>شماره فاکتور: <strong>#${toPersianDigits(sale.invoiceNumber)}</strong></span>
            <span>صندوق‌دار: ${sale.cashierName}</span>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 10px; color: #555;">
            <span>تاریخ: ${toPersianDigits(sale.date)}</span>
            <span>ساعت: ${toPersianDigits(sale.time)}</span>
          </div>
          ${
            sale.customerName
              ? `<div style="font-size: 10px; margin-top: 2px;">مشتری: <strong>${sale.customerName}</strong></div>`
              : ''
          }

          <div class="divider"></div>

          <table>
            <thead>
              <tr style="border-bottom: 1px solid #000; font-size: 11px;">
                <th style="text-align: right; padding-bottom: 4px;">کالا</th>
                <th style="text-align: left; padding-bottom: 4px;">مبلغ کل</th>
              </tr>
            </thead>
            <tbody>
              ${itemsHtml}
            </tbody>
          </table>

          <div class="divider"></div>

          <table style="font-size: 11px;">
            <tr>
              <td style="text-align: right;">جمع کل:</td>
              <td style="text-align: left;">${formatToman(sale.subtotal)}</td>
            </tr>
            ${
              sale.discount > 0
                ? `<tr>
                    <td style="text-align: right; color: #059669;">تخفیف:</td>
                    <td style="text-align: left; color: #059669;">- ${formatToman(sale.discount)}</td>
                  </tr>`
                : ''
            }
            ${
              sale.tax > 0
                ? `<tr>
                    <td style="text-align: right;">مالیات و عوارض:</td>
                    <td style="text-align: left;">${formatToman(sale.tax)}</td>
                  </tr>`
                : ''
            }
          </table>

          <div class="double-divider"></div>

          <div style="display: flex; justify-content: space-between; font-size: 14px; font-weight: bold; margin: 4px 0;">
            <span>مبلغ قابل پرداخت:</span>
            <span>${formatToman(sale.finalTotal)}</span>
          </div>

          <div style="display: flex; justify-content: space-between; font-size: 10px; color: #444; margin-top: 2px;">
            <span>روش پرداخت:</span>
            <span>${sale.paymentMethod}</span>
          </div>

          <div class="divider"></div>

          <div class="barcode-box">
            *${sale.invoiceNumber}*
          </div>

          <div class="footer-text">
            از خرید و اعتماد شما سپاسگزاریم<br>
            نرم‌افزار فروشگاهی فرتاک • Fartak POS
          </div>
        </div>

        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 250);
          }
        </script>
      </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(html);
    printWindow.document.close();
  }

  public static printProforma(
    proforma: ProformaInvoice,
    store: StoreInfo,
    format: 'A4' | 'A5' | 'thermal' = 'A4'
  ): void {
    const printWindow = window.open('', '_blank', 'width=800,height=900');
    if (!printWindow) {
      alert('لطفاً اجازه باز شدن پنجره پاپ‌آپ چاپگر را در مرورگر فعال کنید.');
      return;
    }

    if (format === 'thermal') {
      const itemsHtml = proforma.items
        .map(
          (item) => `
          <tr style="border-bottom: 1px dashed #ccc;">
            <td style="padding: 4px 0; text-align: right;">
              <div><strong>${item.productName}</strong></div>
              <div style="font-size: 10px; color: #666;">${toPersianDigits(item.quantity)} × ${formatToman(item.unitPrice)}</div>
            </td>
            <td style="padding: 4px 0; text-align: left; vertical-align: top;">
              <strong>${formatToman(item.total)}</strong>
            </td>
          </tr>`
        )
        .join('');

      const html = `
        <!DOCTYPE html>
        <html dir="rtl" lang="fa">
        <head>
          <meta charset="utf-8">
          <title>پیش‌فاکتور ${proforma.proformaNumber}</title>
          <style>
            @page { margin: 0; size: 80mm auto; }
            body {
              font-family: system-ui, -apple-system, sans-serif;
              margin: 0; padding: 10px; background: #fff; color: #000;
              font-size: 12px; line-height: 1.4; direction: rtl;
            }
            .header-badge {
              border: 2px solid #000; padding: 4px; text-align: center;
              font-weight: 900; font-size: 14px; margin-bottom: 8px;
            }
            table { width: 100%; border-collapse: collapse; }
            .divider { border-top: 1px dashed #333; margin: 6px 0; }
          </style>
        </head>
        <body>
          <div class="header-badge">« پـیـش‌فـاکـتـور فـروش »</div>
          <div style="text-align: center; font-size: 11px;">
            <div style="font-size: 14px; font-weight: bold;">${store.name}</div>
            <div>${store.branch} - تلفن: ${toPersianDigits(store.phone)}</div>
          </div>
          <div class="divider"></div>
          <div style="font-size: 11px; display: flex; justify-content: space-between;">
            <span>شماره پیش‌فاکتور: <strong>${proforma.proformaNumber}</strong></span>
            <span>تاریخ: ${proforma.issueDate}</span>
          </div>
          <div style="font-size: 10px; color: #555; display: flex; justify-content: space-between; margin-top: 2px;">
            <span>اعتبار تا: <strong>${proforma.validUntil}</strong></span>
            <span>صندوق‌دار: ${proforma.cashierName}</span>
          </div>
          ${proforma.customerName ? `<div style="font-size: 11px; margin-top: 4px;">مشتری: <strong>${proforma.customerName}</strong></div>` : ''}
          <div class="divider"></div>
          <table>
            <thead>
              <tr style="border-bottom: 1px solid #000; font-size: 10px;">
                <th style="text-align: right;">کالا</th>
                <th style="text-align: left;">مبلغ کل</th>
              </tr>
            </thead>
            <tbody>${itemsHtml}</tbody>
          </table>
          <div class="divider"></div>
          <div style="font-size: 11px;">
            <div style="display: flex; justify-content: space-between;">
              <span>جمع اقلام:</span>
              <span>${formatToman(proforma.subtotal)}</span>
            </div>
            ${proforma.discount > 0 ? `<div style="display: flex; justify-content: space-between; color: green;"><span>تخفیف:</span><span>- ${formatToman(proforma.discount)}</span></div>` : ''}
            ${proforma.tax > 0 ? `<div style="display: flex; justify-content: space-between;"><span>مالیات و عوارض:</span><span>+ ${formatToman(proforma.tax)}</span></div>` : ''}
            <div style="display: flex; justify-content: space-between; font-weight: bold; font-size: 13px; border-top: 2px solid #000; margin-top: 4px; padding-top: 4px;">
              <span>مبلغ نهایی پیش‌فاکتور:</span>
              <span>${formatToman(proforma.finalTotal)}</span>
            </div>
          </div>
          <div style="margin-top: 10px; font-size: 9px; color: #555; text-align: center; border-top: 1px dashed #aaa; padding-top: 6px;">
            این برگه پیش‌فاکتور بوده و فاقد ارزش قطعی مالیاتی است.<br>
            ${proforma.notes || 'مدت اعتبار پیش‌فاکتور تا تاریخ قید شده معتبر است.'}
          </div>
          <script>
            window.onload = function() { setTimeout(function() { window.print(); }, 250); }
          </script>
        </body>
        </html>
      `;
      printWindow.document.open();
      printWindow.document.write(html);
      printWindow.document.close();
      return;
    }

    // Official A4 / A5 Proforma Template
    const isA5 = format === 'A5';
    const itemsRows = proforma.items
      .map(
        (item, idx) => `
        <tr style="border-bottom: 1px solid #e2e8f0; font-size: 11px;">
          <td style="padding: 8px 6px; text-align: center;">${toPersianDigits(idx + 1)}</td>
          <td style="padding: 8px 6px; text-align: right; font-weight: 600;">${item.productName}</td>
          <td style="padding: 8px 6px; text-align: center;">${toPersianDigits(item.quantity)}</td>
          <td style="padding: 8px 6px; text-align: left;">${formatToman(item.unitPrice)}</td>
          <td style="padding: 8px 6px; text-align: left; font-weight: bold;">${formatToman(item.total)}</td>
        </tr>
      `
      )
      .join('');

    const html = `
      <!DOCTYPE html>
      <html dir="rtl" lang="fa">
      <head>
        <meta charset="utf-8">
        <title>پیش‌فاکتور رسمی ${proforma.proformaNumber} - ${store.name}</title>
        <style>
          @page {
            size: ${isA5 ? 'A5 landscape' : 'A4 portrait'};
            margin: 12mm;
          }
          body {
            font-family: system-ui, -apple-system, 'Vazirmatn', 'Segoe UI', Tahoma, sans-serif;
            background: #fff;
            color: #1e293b;
            font-size: ${isA5 ? '11px' : '12px'};
            line-height: 1.5;
            direction: rtl;
            margin: 0;
            padding: 16px;
          }
          .proforma-container {
            border: 2px solid #0f172a;
            border-radius: 8px;
            padding: 16px;
            max-width: 100%;
          }
          .header-box {
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 2px solid #0f172a;
            padding-bottom: 12px;
            margin-bottom: 12px;
          }
          .title-tag {
            background: #0f172a;
            color: #fff;
            padding: 6px 16px;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 900;
            letter-spacing: 0.5px;
          }
          .meta-table {
            font-size: 11px;
            border-collapse: collapse;
          }
          .meta-table td {
            padding: 2px 6px;
          }
          .party-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 12px;
          }
          .party-box {
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            padding: 8px 10px;
            background: #f8fafc;
          }
          .party-title {
            font-weight: bold;
            font-size: 11px;
            color: #2563eb;
            border-bottom: 1px dashed #cbd5e1;
            padding-bottom: 4px;
            margin-bottom: 6px;
          }
          table.items-table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid #94a3b8;
            margin-bottom: 12px;
          }
          table.items-table th {
            background: #f1f5f9;
            color: #0f172a;
            border: 1px solid #cbd5e1;
            padding: 8px 6px;
            font-weight: bold;
            font-size: 11px;
          }
          table.items-table td {
            border: 1px solid #e2e8f0;
          }
          .summary-grid {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 16px;
            margin-bottom: 16px;
          }
          .totals-table {
            width: 300px;
            border-collapse: collapse;
          }
          .totals-table td {
            padding: 4px 8px;
            border-bottom: 1px solid #e2e8f0;
          }
          .signatures-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-top: 24px;
            padding-top: 12px;
            border-top: 1px dashed #cbd5e1;
          }
          .sig-box {
            text-align: center;
            height: 90px;
            display: flex;
            flex-col: column;
            justify-content: space-between;
          }
        </style>
      </head>
      <body>
        <div class="proforma-container">
          <!-- Header -->
          <div class="header-box">
            <div>
              <div style="font-size: 18px; font-weight: 900; color: #0f172a;">${store.name}</div>
              <div style="font-size: 11px; color: #64748b;">${store.branch} • سامانه فروش و توزیع کالا</div>
            </div>
            <div class="title-tag">پـیـش‌فـاکـتـور فـروش (استعلام قیمت)</div>
            <table class="meta-table">
              <tr>
                <td style="color: #64748b;">شماره:</td>
                <td><strong>${proforma.proformaNumber}</strong></td>
              </tr>
              <tr>
                <td style="color: #64748b;">تاریخ صدور:</td>
                <td><strong>${proforma.issueDate}</strong></td>
              </tr>
              <tr>
                <td style="color: #64748b;">مهلت اعتبار:</td>
                <td style="color: #dc2626;"><strong>${proforma.validUntil}</strong></td>
              </tr>
            </table>
          </div>

          <!-- Parties Info -->
          <div class="party-grid">
            <div class="party-box">
              <div class="party-title">مشخصات فروشنده</div>
              <div><strong>نام / واحد تجاری:</strong> ${store.name} (${store.branch})</div>
              <div><strong>نشانی:</strong> ${store.address}</div>
              <div><strong>تلفن تماس:</strong> ${toPersianDigits(store.phone)} • کد فروشگاه: ${store.code}</div>
            </div>
            <div class="party-box">
              <div class="party-title">مشخصات خریدار / متقاضی استعلام</div>
              <div><strong>نام خریدار:</strong> ${proforma.customerName || 'مشتری آزاد / بدون نام'}</div>
              <div><strong>شماره تماس:</strong> ${proforma.customerPhone || '---'}</div>
              <div><strong>نشانی / پروژه:</strong> ${proforma.customerAddress || '---'}</div>
            </div>
          </div>

          <!-- Items Table -->
          <table class="items-table">
            <thead>
              <tr>
                <th style="width: 35px;">ردیف</th>
                <th style="text-align: right;">شرح کالا / خدمات</th>
                <th style="width: 60px;">تعداد</th>
                <th style="width: 110px; text-align: left;">مبلغ واحد (تومان)</th>
                <th style="width: 130px; text-align: left;">مبلغ کل (تومان)</th>
              </tr>
            </thead>
            <tbody>
              ${itemsRows}
            </tbody>
          </table>

          <!-- Totals and Notes -->
          <div class="summary-grid">
            <div style="flex: 1; font-size: 11px; color: #475569; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px;">
              <strong style="color: #0f172a;">شرایط و توضیحات پیش‌فاکتور:</strong>
              <div style="margin-top: 4px; line-height: 1.6;">
                ۱. این سند به عنوان پیش‌فاکتور صادر شده و تا تاریخ ${proforma.validUntil} معتبر است.<br>
                ۲. قیمت‌های اعلامی تا زمان پایان مهلت اعتبار بدون تغییر خواهد ماند.<br>
                ۳. ${proforma.notes || 'تحویل کالا پس از تسویه نهایی حساب یا هماهنگی با انبار انجام می‌گیرد.'}
              </div>
            </div>

            <table class="totals-table">
              <tr>
                <td style="color: #64748b;">جمع کل اقلام:</td>
                <td style="text-align: left; font-weight: 600;">${formatToman(proforma.subtotal)}</td>
              </tr>
              ${
                proforma.discount > 0
                  ? `<tr>
                      <td style="color: #16a34a;">تخفیف ویژه:</td>
                      <td style="text-align: left; color: #16a34a; font-weight: 600;">- ${formatToman(proforma.discount)}</td>
                    </tr>`
                  : ''
              }
              ${
                proforma.tax > 0
                  ? `<tr>
                      <td style="color: #64748b;">مالیات بر ارزش افزوده:</td>
                      <td style="text-align: left; font-weight: 600;">+ ${formatToman(proforma.tax)}</td>
                    </tr>`
                  : ''
              }
              <tr style="background: #f1f5f9;">
                <td style="font-weight: 900; font-size: 13px; color: #0f172a;">مبلغ نهایی قابل پرداخت:</td>
                <td style="text-align: left; font-weight: 900; font-size: 14px; color: #1e3a8a;">
                  ${formatToman(proforma.finalTotal)}
                </td>
              </tr>
            </table>
          </div>

          <!-- Signatures -->
          <div class="signatures-grid">
            <div class="sig-box">
              <span style="font-weight: bold; color: #334155;">مهر و امضای فروشنده:</span>
              <span style="font-size: 10px; color: #94a3b8;">${proforma.cashierName}</span>
            </div>
            <div class="sig-box">
              <span style="font-weight: bold; color: #334155;">امضا و تأیید خریدار:</span>
              <span style="font-size: 10px; color: #94a3b8;">تاریخ تأیید و مهر شرکت</span>
            </div>
          </div>
        </div>

        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 300);
          }
        </script>
      </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(html);
    printWindow.document.close();
  }
}
