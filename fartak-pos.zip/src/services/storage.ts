import {
  Product,
  Category,
  Sale,
  ProformaInvoice,
  Customer,
  Supplier,
  Purchase,
  Device,
  UserAccount,
  StoreInfo,
} from '../types';
import {
  INITIAL_CATEGORIES,
  INITIAL_PRODUCTS,
  INITIAL_CUSTOMERS,
  INITIAL_SUPPLIERS,
  INITIAL_DEVICES,
  INITIAL_USERS,
  INITIAL_SALES,
  STORE_CONFIG,
} from '../data/mockData';

const INITIAL_PROFORMAS: ProformaInvoice[] = [
  {
    id: 'prof-1',
    proformaNumber: 'PF-108',
    issueDate: '۱۴۰۵/۰۶/۲۴',
    validUntil: '۱۴۰۵/۰۶/۲۹',
    customerName: 'شرکت مهندسی فراگستر',
    customerPhone: '۰۹۱۲۹۸۷۶۵۴۳',
    customerAddress: 'تهران، میدان ونک، برج نگار',
    items: [
      {
        productId: 'p-1',
        productName: 'روغن سرخ‌کردنی بهار ۲.۵ لیتری',
        quantity: 12,
        unitPrice: 185000,
        total: 2220000,
      },
      {
        productId: 'p-2',
        productName: 'برنج طارم هاشمی درجه یک ۵ کیلویی',
        quantity: 4,
        unitPrice: 650000,
        total: 2600000,
      },
    ],
    subtotal: 4820000,
    discount: 120000,
    tax: 423000,
    finalTotal: 5123000,
    notes: 'اعتبار پیش‌فاکتور ۵ روز کاری از تاریخ صدور می‌باشد.',
    cashierName: 'رضا کمالی (مدیر فروشگاه)',
  },
  {
    id: 'prof-2',
    proformaNumber: 'PF-107',
    issueDate: '۱۴۰۵/۰۶/۲۲',
    validUntil: '۱۴۰۵/۰۶/۲۷',
    customerName: 'فروشگاه آریا',
    customerPhone: '۰۹۱۲۳۳۳۴۴۵۵',
    items: [
      {
        productId: 'p-4',
        productName: 'چای سیاه‌ باروتی زرین ۴۵۰ گرمی',
        quantity: 10,
        unitPrice: 145000,
        total: 1450000,
      },
      {
        productId: 'p-5',
        productName: 'تن ماهی ۱۸۰ گرمی در روغن شیلتون',
        quantity: 24,
        unitPrice: 88000,
        total: 2112000,
      },
    ],
    subtotal: 3562000,
    discount: 100000,
    tax: 311580,
    finalTotal: 3773580,
    notes: 'تحویل در محل انبار خریدار',
    cashierName: 'سارا احمدی',
  },
];

const STORAGE_KEYS = {
  PRODUCTS: 'fartak_products_v1',
  CATEGORIES: 'fartak_categories_v1',
  SALES: 'fartak_sales_v1',
  PROFORMAS: 'fartak_proformas_v1',
  CUSTOMERS: 'fartak_customers_v1',
  SUPPLIERS: 'fartak_suppliers_v1',
  PURCHASES: 'fartak_purchases_v1',
  DEVICES: 'fartak_devices_v1',
  USERS: 'fartak_users_v1',
  STORE: 'fartak_store_v1',
  SYNC_QUEUE: 'fartak_sync_queue_v1',
};

function loadItem<T>(key: string, fallback: T): T {
  try {
    let raw = localStorage.getItem(key);
    if (!raw || raw === 'undefined' || raw === 'null') return fallback;
    // Auto-migrate legacy 1403/۱۴۰۳ dates to 1405/۱۴۰۵
    if (raw.includes('۱۴۰۳') || raw.includes('1403')) {
      raw = raw.replace(/۱۴۰۳/g, '۱۴۰۵').replace(/1403/g, '1405');
      localStorage.setItem(key, raw);
    }
    const parsed = JSON.parse(raw);
    if (parsed === null || parsed === undefined) return fallback;
    if (Array.isArray(fallback) && !Array.isArray(parsed)) return fallback;
    return parsed as T;
  } catch {
    return fallback;
  }
}

function saveItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error(`Failed to save to ${key}:`, e);
  }
}

export class StorageService {
  // Products
  static getProducts(): Product[] {
    return loadItem<Product[]>(STORAGE_KEYS.PRODUCTS, INITIAL_PRODUCTS);
  }

  static saveProducts(products: Product[]): void {
    saveItem(STORAGE_KEYS.PRODUCTS, products);
  }

  static addProduct(product: Omit<Product, 'id'>): Product {
    const products = this.getProducts();
    const newProduct: Product = {
      ...product,
      id: `p-${Date.now()}`,
    };
    const updated = [newProduct, ...products];
    this.saveProducts(updated);
    return newProduct;
  }

  static updateProduct(product: Product): void {
    const products = this.getProducts();
    const index = products.findIndex((p) => p.id === product.id);
    if (index !== -1) {
      products[index] = product;
      this.saveProducts(products);
    }
  }

  static deleteProduct(productId: string): void {
    const products = this.getProducts();
    const updated = products.filter((p) => p.id !== productId);
    this.saveProducts(updated);
  }

  // Bulk Price Update
  static bulkUpdatePrices(options: {
    categoryFilter?: string;
    type: 'percentage' | 'fixed';
    amount: number;
    priceType: 'retail' | 'purchase' | 'wholesale';
    isIncrease: boolean;
  }): { updatedCount: number } {
    const products = this.getProducts();
    let count = 0;

    const updated = products.map((product) => {
      if (options.categoryFilter && options.categoryFilter !== 'all' && product.categoryId !== options.categoryFilter) {
        return product;
      }

      count++;
      const key = options.priceType === 'retail'
        ? 'retailPrice'
        : options.priceType === 'purchase'
        ? 'purchasePrice'
        : 'wholesalePrice';

      const current = product[key] || 0;
      let newPrice = current;

      if (options.type === 'percentage') {
        const delta = Math.round((current * options.amount) / 100);
        newPrice = options.isIncrease ? current + delta : Math.max(0, current - delta);
      } else {
        newPrice = options.isIncrease ? current + options.amount : Math.max(0, current - options.amount);
      }

      return {
        ...product,
        [key]: newPrice,
      };
    });

    this.saveProducts(updated);
    return { updatedCount: count };
  }

  // Categories
  static getCategories(): Category[] {
    return loadItem<Category[]>(STORAGE_KEYS.CATEGORIES, INITIAL_CATEGORIES);
  }

  // Sales
  static getSales(): Sale[] {
    return loadItem<Sale[]>(STORAGE_KEYS.SALES, INITIAL_SALES);
  }

  static saveSales(sales: Sale[]): void {
    saveItem(STORAGE_KEYS.SALES, sales);
  }

  static addSale(sale: Omit<Sale, 'id' | 'invoiceNumber'>): Sale {
    const sales = this.getSales();
    const nextNum = (sales.length > 0 ? Math.max(...sales.map((s) => parseInt(s.invoiceNumber, 10) || 1000)) + 1 : 1042).toString();

    const newSale: Sale = {
      ...sale,
      id: `s-${Date.now()}`,
      invoiceNumber: nextNum,
    };

    // Deduct stock for products sold
    const products = this.getProducts();
    sale.items.forEach((item) => {
      const prod = products.find((p) => p.id === item.productId);
      if (prod) {
        prod.currentStock = Math.max(0, prod.currentStock - item.quantity);
      }
    });
    this.saveProducts(products);

    // If customer credit payment, update customer balance
    if (sale.customerId && sale.paymentMethod === 'اعتباری') {
      const customers = this.getCustomers();
      const customer = customers.find((c) => c.id === sale.customerId);
      if (customer) {
        customer.creditBalance += sale.finalTotal;
        customer.totalPurchases += sale.finalTotal;
        customer.purchaseCount += 1;
        this.saveCustomers(customers);
      }
    } else if (sale.customerId) {
      const customers = this.getCustomers();
      const customer = customers.find((c) => c.id === sale.customerId);
      if (customer) {
        customer.totalPurchases += sale.finalTotal;
        customer.purchaseCount += 1;
        this.saveCustomers(customers);
      }
    }

    const updated = [newSale, ...sales];
    this.saveSales(updated);
    return newSale;
  }

  static refundSale(saleId: string): { success: boolean; message: string } {
    const sales = this.getSales();
    const index = sales.findIndex((s) => s.id === saleId);
    if (index === -1) {
      return { success: false, message: 'فاکتور یافت نشد' };
    }

    const sale = sales[index];
    if (sale.status === 'مرجوع شده') {
      return { success: false, message: 'این فاکتور قبلاً مرجوع شده است' };
    }

    // Return stock
    const products = this.getProducts();
    sale.items.forEach((item) => {
      const prod = products.find((p) => p.id === item.productId);
      if (prod) {
        prod.currentStock += item.quantity;
      }
    });
    this.saveProducts(products);

    // Update sale status
    sales[index] = {
      ...sale,
      status: 'مرجوع شده',
    };
    this.saveSales(sales);

    return { success: true, message: `فاکتور #${sale.invoiceNumber} مرجوع و موجودی انبار اصلاح گردید` };
  }

  // Proforma Invoices (پیش‌فاکتور)
  static getProformas(): ProformaInvoice[] {
    return loadItem<ProformaInvoice[]>(STORAGE_KEYS.PROFORMAS, INITIAL_PROFORMAS);
  }

  static saveProformas(proformas: ProformaInvoice[]): void {
    saveItem(STORAGE_KEYS.PROFORMAS, proformas);
  }

  static addProforma(proforma: Omit<ProformaInvoice, 'id' | 'proformaNumber'>): ProformaInvoice {
    const list = this.getProformas();
    const nextNum = `PF-${100 + list.length + 1}`;
    const newProforma: ProformaInvoice = {
      ...proforma,
      id: `prof-${Date.now()}`,
      proformaNumber: nextNum,
    };
    const updated = [newProforma, ...list];
    this.saveProformas(updated);
    return newProforma;
  }

  static deleteProforma(proformaId: string): void {
    const list = this.getProformas();
    this.saveProformas(list.filter((p) => p.id !== proformaId));
  }

  // Customers
  static getCustomers(): Customer[] {
    return loadItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
  }

  static saveCustomers(customers: Customer[]): void {
    saveItem(STORAGE_KEYS.CUSTOMERS, customers);
  }

  static addCustomer(customer: Omit<Customer, 'id' | 'code' | 'totalPurchases' | 'purchaseCount'>): Customer {
    const customers = this.getCustomers();
    const newCustomer: Customer = {
      ...customer,
      id: `cust-${Date.now()}`,
      code: `C-${1000 + customers.length + 1}`,
      totalPurchases: 0,
      purchaseCount: 0,
    };
    this.saveCustomers([...customers, newCustomer]);
    return newCustomer;
  }

  // Suppliers
  static getSuppliers(): Supplier[] {
    return loadItem<Supplier[]>(STORAGE_KEYS.SUPPLIERS, INITIAL_SUPPLIERS);
  }

  static saveSuppliers(suppliers: Supplier[]): void {
    saveItem(STORAGE_KEYS.SUPPLIERS, suppliers);
  }

  static addSupplier(supplier: Omit<Supplier, 'id' | 'totalPurchases' | 'balance'>): Supplier {
    const suppliers = this.getSuppliers();
    const newSupplier: Supplier = {
      ...supplier,
      id: `sup-${Date.now()}`,
      totalPurchases: 0,
      balance: 0,
    };
    this.saveSuppliers([...suppliers, newSupplier]);
    return newSupplier;
  }

  // Purchases
  static getPurchases(): Purchase[] {
    return loadItem<Purchase[]>(STORAGE_KEYS.PURCHASES, []);
  }

  static addPurchase(purchase: Omit<Purchase, 'id' | 'referenceNumber'>): Purchase {
    const purchases = this.getPurchases();
    const newPurchase: Purchase = {
      ...purchase,
      id: `pur-${Date.now()}`,
      referenceNumber: `PO-${1000 + purchases.length + 1}`,
    };

    // Increment stock for products purchased
    const products = this.getProducts();
    purchase.items.forEach((item) => {
      const prod = products.find((p) => p.id === item.productId);
      if (prod) {
        prod.currentStock += item.quantity;
      }
    });
    this.saveProducts(products);

    // Update supplier balance and total purchases
    const suppliers = this.getSuppliers();
    const sup = suppliers.find((s) => s.id === purchase.supplierId);
    if (sup) {
      sup.totalPurchases += purchase.totalCost;
      this.saveSuppliers(suppliers);
    }

    const updated = [newPurchase, ...purchases];
    saveItem(STORAGE_KEYS.PURCHASES, updated);
    return newPurchase;
  }

  // Devices
  static getDevices(): Device[] {
    return loadItem<Device[]>(STORAGE_KEYS.DEVICES, INITIAL_DEVICES);
  }

  static updateDevice(device: Device): void {
    const devices = this.getDevices();
    const index = devices.findIndex((d) => d.id === device.id);
    if (index !== -1) {
      devices[index] = device;
      saveItem(STORAGE_KEYS.DEVICES, devices);
    }
  }

  // Users
  static getUsers(): UserAccount[] {
    return loadItem<UserAccount[]>(STORAGE_KEYS.USERS, INITIAL_USERS);
  }

  static saveUsers(users: UserAccount[]): void {
    saveItem(STORAGE_KEYS.USERS, users);
  }

  static addUser(user: Omit<UserAccount, 'id'>): UserAccount {
    const users = this.getUsers();
    const newUser: UserAccount = {
      ...user,
      id: `u-${Date.now()}`,
    };
    this.saveUsers([...users, newUser]);
    return newUser;
  }

  // Store Info
  static getStoreInfo(): StoreInfo {
    return loadItem<StoreInfo>(STORAGE_KEYS.STORE, STORE_CONFIG);
  }

  static saveStoreInfo(info: StoreInfo): void {
    saveItem(STORAGE_KEYS.STORE, info);
  }

  // Reset to initial demo seed
  static resetToDemoData(): void {
    localStorage.removeItem(STORAGE_KEYS.PRODUCTS);
    localStorage.removeItem(STORAGE_KEYS.CATEGORIES);
    localStorage.removeItem(STORAGE_KEYS.SALES);
    localStorage.removeItem(STORAGE_KEYS.CUSTOMERS);
    localStorage.removeItem(STORAGE_KEYS.SUPPLIERS);
    localStorage.removeItem(STORAGE_KEYS.PURCHASES);
    localStorage.removeItem(STORAGE_KEYS.DEVICES);
    localStorage.removeItem(STORAGE_KEYS.USERS);
    localStorage.removeItem(STORAGE_KEYS.STORE);
  }
}
