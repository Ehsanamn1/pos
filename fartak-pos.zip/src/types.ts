export interface Product {
  id: string;
  name: string;
  barcode: string;
  sku: string;
  categoryId: string;
  categoryName: string;
  brand: string;
  purchasePrice: number;
  retailPrice: number;
  wholesalePrice: number;
  specialPrice?: number;
  minStock: number;
  currentStock: number;
  unit: string;
  entryDate: string;
  expiryDate: string; // YYYY/MM/DD in Shamsi
  supplierId: string;
  supplierName: string;
  description?: string;
  imageUrl: string;
  featured?: boolean;
}

export interface Category {
  id: string;
  name: string;
  icon?: string;
  count?: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
  unitPrice: number;
  discount: number;
}

export type PaymentMethod = 'کارتخوان' | 'نقدی' | 'ترکیبی' | 'اعتباری';
export type SaleStatus = 'تکمیل شده' | 'مرجوع شده';

export interface Sale {
  id: string;
  invoiceNumber: string;
  date: string;
  time: string;
  items: {
    productId: string;
    productName: string;
    quantity: number;
    unitPrice: number;
    total: number;
  }[];
  subtotal: number;
  discount: number;
  tax: number;
  finalTotal: number;
  paymentMethod: PaymentMethod;
  customerId?: string;
  customerName?: string;
  cashierName: string;
  status?: SaleStatus;
}

export interface ProformaInvoice {
  id: string;
  proformaNumber: string;
  issueDate: string;
  validUntil: string;
  customerId?: string;
  customerName?: string;
  customerPhone?: string;
  customerAddress?: string;
  items: {
    productId: string;
    productName: string;
    quantity: number;
    unitPrice: number;
    total: number;
  }[];
  subtotal: number;
  discount: number;
  tax: number;
  finalTotal: number;
  notes?: string;
  cashierName: string;
}

export interface Customer {
  id: string;
  name: string;
  code: string;
  phone: string;
  creditBalance: number; // مانده حساب
  totalPurchases: number;
  purchaseCount: number;
  notes?: string;
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  contactInfo: string;
  city: string;
  totalPurchases: number;
  balance: number;
  notes?: string;
}

export interface PurchaseItem {
  productId: string;
  productName: string;
  quantity: number;
  unitCost: number;
  total: number;
}

export interface Purchase {
  id: string;
  referenceNumber: string;
  supplierId: string;
  supplierName: string;
  date: string;
  items: PurchaseItem[];
  totalCost: number;
  status: 'تکمیل شده' | 'در انتظار' | 'لغو شده';
}

export type DeviceType = 'printer' | 'scanner' | 'drawer' | 'pos_terminal';

export interface Device {
  id: string;
  name: string;
  type: DeviceType;
  connectionType: 'USB' | 'Bluetooth' | 'Network';
  status: 'متصل' | 'قطع';
  model: string;
  paperWidth?: '58mm' | '80mm';
}

export interface UserAccount {
  id: string;
  name: string;
  username: string;
  role: 'مالک' | 'مدیر' | 'صندوقدار' | 'انباردار' | 'حسابدار';
  status: 'فعال' | 'غیرفعال';
  avatar?: string;
}

export interface CurrentUser {
  id: string;
  name: string;
  role: string;
}

export type NavItemKey =
  | 'home'
  | 'sales'
  | 'products'
  | 'inventory'
  | 'purchases'
  | 'customers'
  | 'reports'
  | 'devices'
  | 'settings'
  | 'design-system';

export type DeviceMode = 'auto' | 'desktop' | 'tablet' | 'mobile';

export interface StoreInfo {
  name: string;
  branch: string;
  code: string;
  phone: string;
  address: string;
  taxRate: number;
  currency: string;
}
