import React, { useState, useMemo } from 'react';
import { Customer } from '../types';
import { StorageService } from '../services/storage';
import { formatToman, toPersianDigits } from '../design-system/tokens';
import { Modal } from '../design-system/components/Modal';
import { Button } from '../design-system/components/Button';
import { Input } from '../design-system/components/Input';
import {
  Users,
  UserPlus,
  Search,
  Phone,
  CreditCard,
  Receipt,
  FileText,
  CheckCircle2,
  ArrowDownLeft,
} from 'lucide-react';

export const CustomersView: React.FC = () => {
  const [customers, setCustomers] = useState<Customer[]>(() => StorageService.getCustomers());
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  // Modals
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);
  const [isSettleCreditOpen, setIsSettleCreditOpen] = useState(false);
  const [settlementAmount, setSettlementAmount] = useState<number>(0);

  const [formState, setFormState] = useState({
    name: '',
    phone: '',
    creditBalance: 0,
    notes: '',
  });

  const reloadCustomers = () => {
    setCustomers(StorageService.getCustomers());
  };

  const filteredCustomers = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return customers.filter(
      (c) => !q || c.name.toLowerCase().includes(q) || c.phone.includes(q) || c.code.toLowerCase().includes(q)
    );
  }, [customers, searchQuery]);

  const handleAddCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formState.name) return;

    StorageService.addCustomer(formState);
    setIsAddCustomerOpen(false);
    setFormState({ name: '', phone: '', creditBalance: 0, notes: '' });
    reloadCustomers();
  };

  const handleSettleCredit = () => {
    if (!selectedCustomer) return;

    const newBalance = Math.max(0, selectedCustomer.creditBalance - settlementAmount);
    const updated = customers.map((c) =>
      c.id === selectedCustomer.id ? { ...c, creditBalance: newBalance } : c
    );
    StorageService.saveCustomers(updated);
    setSelectedCustomer({ ...selectedCustomer, creditBalance: newBalance });
    setIsSettleCreditOpen(false);
    setSettlementAmount(0);
    reloadCustomers();
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Top Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Users className="w-6 h-6 text-blue-600" />
            <span>مدیریت مشتریان و حساب‌های دفتری</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            سوابق خرید، ثبت مانده حساب نسیه و اعتباری، و تسویه حساب سریع مشتریان
          </p>
        </div>

        <Button
          variant="primary"
          onClick={() => setIsAddCustomerOpen(true)}
          icon={<UserPlus className="w-4 h-4" />}
        >
          مشتری جدید
        </Button>
      </div>

      {/* Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80">
        <div className="relative">
          <input
            type="text"
            placeholder="جستجو در مشتریان با نام، شماره تماس یا کد مشتری..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white focus:outline-none focus:border-blue-600"
          />
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
        </div>
      </div>

      {/* Customers List & Detail Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Customer Cards (matching reference image) */}
        <div className={selectedCustomer ? 'lg:col-span-8' : 'lg:col-span-12'}>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3.5">
            {filteredCustomers.map((cust) => {
              const isSelected = selectedCustomer?.id === cust.id;
              const hasDebt = cust.creditBalance > 0;

              return (
                <div
                  key={cust.id}
                  onClick={() => setSelectedCustomer(cust)}
                  className={`bg-white rounded-2xl border p-4 transition-all duration-200 cursor-pointer flex flex-col justify-between hover:shadow-md ${
                    isSelected
                      ? 'border-blue-600 ring-2 ring-blue-500/20 shadow-xs'
                      : 'border-slate-200/80 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-sm shrink-0">
                        {(cust?.name || 'م').slice(0, 1)}
                      </div>
                      <div>
                        <h4 className="font-bold text-xs text-slate-900">{cust?.name || 'مشتری'}</h4>
                        <div className="text-[11px] text-slate-400 font-mono flex items-center gap-1 mt-0.5">
                          <Phone className="w-3 h-3 text-slate-400" />
                          <span>{toPersianDigits(cust?.phone || '')}</span>
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">{cust.code}</span>
                  </div>

                  <div className="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between">
                    <div>
                      <div className="text-[10px] text-slate-400">مانده حساب دفتری:</div>
                      <div className={`font-sans font-bold text-xs ${hasDebt ? 'text-amber-600' : 'text-slate-500'}`}>
                        {formatToman(cust.creditBalance)}
                      </div>
                    </div>

                    <div className="text-left text-[11px] text-slate-500">
                      <div>{toPersianDigits(cust.purchaseCount)} فاکتور</div>
                      <div className="font-bold text-slate-800">{formatToman(cust.totalPurchases)}</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Customer Profile Panel */}
        {selectedCustomer && (
          <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs sticky top-6 space-y-5 animate-in fade-in duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-black text-sm text-slate-900">پرونده مشتری</h3>
              <button
                type="button"
                onClick={() => setSelectedCustomer(null)}
                className="text-xs text-slate-400 hover:text-slate-700 cursor-pointer font-bold"
              >
                بستن ×
              </button>
            </div>

            <div className="text-center space-y-2">
              <div className="w-16 h-16 rounded-2xl bg-blue-600 text-white font-black text-xl flex items-center justify-center mx-auto shadow-sm">
                {(selectedCustomer?.name || 'م').slice(0, 1)}
              </div>
              <h4 className="font-black text-base text-slate-900">{selectedCustomer?.name || 'مشتری'}</h4>
              <div className="text-xs text-slate-500 font-mono">{toPersianDigits(selectedCustomer?.phone || '')}</div>
            </div>

            {/* Financial summary */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500">مانده بدهی دفتری (اعتباری):</span>
                <span className={`font-bold font-sans ${selectedCustomer.creditBalance > 0 ? 'text-amber-600 text-sm' : 'text-slate-700'}`}>
                  {formatToman(selectedCustomer.creditBalance)}
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500">مجموع خرید تا کنون:</span>
                <span className="font-bold font-sans text-slate-900">
                  {formatToman(selectedCustomer.totalPurchases)}
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500">تعداد فاکتورهای ثبت شده:</span>
                <span className="font-bold text-slate-900">
                  {toPersianDigits(selectedCustomer.purchaseCount)} فاکتور
                </span>
              </div>
            </div>

            {selectedCustomer.notes && (
              <div className="p-3 bg-blue-50/50 rounded-xl border border-blue-100 text-xs text-blue-900">
                <span className="font-bold block mb-1">یادداشت فروشگاه:</span>
                {selectedCustomer.notes}
              </div>
            )}

            {/* Actions */}
            <div className="space-y-2 pt-2 border-t border-slate-100">
              {selectedCustomer.creditBalance > 0 && (
                <Button
                  variant="primary"
                  className="w-full"
                  onClick={() => {
                    setSettlementAmount(selectedCustomer.creditBalance);
                    setIsSettleCreditOpen(true);
                  }}
                  icon={<ArrowDownLeft className="w-4 h-4" />}
                >
                  تسویه بدهی دفتری
                </Button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Add Customer Modal */}
      <Modal
        isOpen={isAddCustomerOpen}
        onClose={() => setIsAddCustomerOpen(false)}
        title="ثبت پرونده مشتری جدید"
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsAddCustomerOpen(false)}>
              انصراف
            </Button>
            <Button variant="primary" onClick={handleAddCustomer} icon={<CheckCircle2 className="w-4 h-4" />}>
              ثبت مشتری
            </Button>
          </>
        }
      >
        <form onSubmit={handleAddCustomer} className="space-y-4">
          <Input
            label="نام و نام خانوادگی مشتری *"
            placeholder="مثال: آقای رضایی، شرکت پارس..."
            value={formState.name}
            onChange={(e) => setFormState({ ...formState, name: e.target.value })}
            required
          />

          <Input
            label="شماره تلفن همراه *"
            placeholder="۰۹۱۲۳۴۵۶۷۸۹"
            value={formState.phone}
            onChange={(e) => setFormState({ ...formState, phone: e.target.value })}
            required
          />

          <Input
            label="مانده بدهی اولیه (تومان)"
            type="number"
            value={formState.creditBalance || ''}
            onChange={(e) => setFormState({ ...formState, creditBalance: parseInt(e.target.value, 10) || 0 })}
          />

          <Input
            label="یادداشت یا آدرس مشتری"
            placeholder="توضیحات تکمیلی درباره مشتری..."
            value={formState.notes}
            onChange={(e) => setFormState({ ...formState, notes: e.target.value })}
          />
        </form>
      </Modal>

      {/* Settle Credit Modal */}
      <Modal
        isOpen={isSettleCreditOpen}
        onClose={() => setIsSettleCreditOpen(false)}
        title={`تسویه حساب بدهی: ${selectedCustomer?.name}`}
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsSettleCreditOpen(false)}>
              انصراف
            </Button>
            <Button variant="primary" onClick={handleSettleCredit} icon={<CheckCircle2 className="w-4 h-4" />}>
              ثبت دریافتی و تسویه
            </Button>
          </>
        }
      >
        <div className="space-y-4 text-xs">
          <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-900">
            مانده بدهی فعلی مشتری: <strong>{formatToman(selectedCustomer?.creditBalance || 0)}</strong>
          </div>

          <Input
            label="مبلغ دریافتی جهت تسویه (تومان):"
            type="number"
            value={settlementAmount || ''}
            onChange={(e) => setSettlementAmount(parseInt(e.target.value, 10) || 0)}
          />
        </div>
      </Modal>
    </div>
  );
};
