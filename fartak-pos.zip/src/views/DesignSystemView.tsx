import React, { useState } from 'react';
import {
  Sparkles,
  Search,
  ShoppingCart,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Clock,
  Printer,
  Barcode,
} from 'lucide-react';
import { FartakLogo } from '@/src/design-system/FartakLogo';
import { Button } from '@/src/design-system/components/Button';
import { Badge } from '@/src/design-system/components/Badge';
import { Card, MetricCard, AlertBanner } from '@/src/design-system/components/Card';
import { Input, SearchBar } from '@/src/design-system/components/Input';
import { Tabs } from '@/src/design-system/components/Tabs';
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableHeaderCell,
  TableCell,
} from '@/src/design-system/components/Table';
import { Modal } from '@/src/design-system/components/Modal';
import { toPersianDigits, formatToman } from '@/src/design-system/tokens';

export const DesignSystemView: React.FC = () => {
  const [activeCategoryTab, setActiveCategoryTab] = useState('all');
  const [activePillTab, setActivePillTab] = useState('retail');
  const [searchValue, setSearchValue] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [buttonLoading, setButtonLoading] = useState(false);

  const categoryTabs = [
    { id: 'all', label: 'همه کالاها', count: 1250 },
    { id: 'drinks', label: 'نوشیدنی‌ها', count: 85 },
    { id: 'snacks', label: 'تنقلات و چیپس', count: 140 },
    { id: 'dairy', label: 'لبنیات', count: 42 },
    { id: 'hygiene', label: 'شوینده و بهداشتی', count: 96 },
  ];

  const toggleLoading = () => {
    setButtonLoading(true);
    setTimeout(() => setButtonLoading(false), 1500);
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-20">
      {/* Intro Header */}
      <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
            مستندات سیستم طراحی فرتاک (Phase 1)
          </span>
          <h2 className="text-2xl font-black text-slate-900 mt-2">
            سیستم طراحی و تایپوگرافی Fartak POS
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            برگرفته دقیق از مراجع تصویری رابط کاربری، تایپوگرافی فارسی، فاصله‌ها، گوشه‌ها و رنگ‌بندی نرم‌افزار فروشگاهی
          </p>
        </div>

        <FartakLogo size="lg" showSubtitle showTagline />
      </div>

      {/* 1. Color Palette */}
      <Card>
        <h3 className="text-base font-bold text-slate-900 mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
          <span>پالت رنگ‌های اصلی سیستم (Design Tokens)</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-3">
          {/* Primary Brand Blue */}
          <div className="p-3 rounded-xl bg-blue-600 text-white shadow-xs">
            <div className="text-xs font-bold">آبی فرتاک (Brand)</div>
            <div className="text-[11px] opacity-80 mt-1 font-mono">#2563EB</div>
            <div className="text-[10px] opacity-70 mt-2">اکشن‌های اصلی، دکمه‌های POS</div>
          </div>

          {/* Soft Tint Blue */}
          <div className="p-3 rounded-xl bg-blue-50 text-blue-800 border border-blue-100">
            <div className="text-xs font-bold">آبی ملایم (Tint)</div>
            <div className="text-[11px] opacity-80 mt-1 font-mono">#EFF6FF</div>
            <div className="text-[10px] opacity-70 mt-2">سطوح اکتیو، بج‌های انتخاب</div>
          </div>

          {/* Success Green */}
          <div className="p-3 rounded-xl bg-emerald-500 text-white shadow-xs">
            <div className="text-xs font-bold">سبز موفقیت (Success)</div>
            <div className="text-[11px] opacity-80 mt-1 font-mono">#10B981</div>
            <div className="text-[10px] opacity-70 mt-2">پرداخت موفق، موجودی کافی</div>
          </div>

          {/* Warning Amber */}
          <div className="p-3 rounded-xl bg-amber-500 text-white shadow-xs">
            <div className="text-xs font-bold">هشدار انقضا (Warning)</div>
            <div className="text-[11px] opacity-80 mt-1 font-mono">#F59E0B</div>
            <div className="text-[10px] opacity-70 mt-2">کالای نزدیک انقضا، کم‌موجودی</div>
          </div>

          {/* Danger Red */}
          <div className="p-3 rounded-xl bg-rose-500 text-white shadow-xs">
            <div className="text-xs font-bold">قرمز خطا (Danger)</div>
            <div className="text-[11px] opacity-80 mt-1 font-mono">#EF4444</div>
            <div className="text-[10px] opacity-70 mt-2">منقضی شده، حذف، ناموجود</div>
          </div>
        </div>
      </Card>

      {/* 2. Buttons Showcase */}
      <Card>
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
            <span>انواع دکمه‌ها و وضعیت‌ها (Button Variants & Sizes)</span>
          </h3>
          <Button size="sm" variant="outline" onClick={toggleLoading}>
            تست لودینگ دکمه‌ها
          </Button>
        </div>

        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-3">
            <Button variant="primary" loading={buttonLoading} icon={<ShoppingCart className="w-4 h-4" />}>
              دکمه اصلی (فروش جدید)
            </Button>
            <Button variant="secondary" icon={<Sparkles className="w-4 h-4" />}>
              دکمه ثانویه
            </Button>
            <Button variant="outline" icon={<Search className="w-4 h-4" />}>
              دکمه بردر دار
            </Button>
            <Button variant="ghost">
              دکمه شبح (Ghost)
            </Button>
            <Button variant="success" icon={<CheckCircle2 className="w-4 h-4" />}>
              تأیید و پرداخت
            </Button>
            <Button variant="danger" icon={<XCircle className="w-4 h-4" />}>
              حذف فاکتور
            </Button>
          </div>

          {/* Sizes */}
          <div className="flex flex-wrap items-center gap-3 pt-3 border-t border-slate-100">
            <Button size="sm" variant="primary">سایز کوچک (sm)</Button>
            <Button size="md" variant="primary">سایز متوسط (md)</Button>
            <Button size="lg" variant="primary">سایز بزرگ (lg)</Button>
            <Button size="xl" variant="primary" icon={<Barcode className="w-5 h-5" />}>
              کلید بزرگ POS (سایز xl)
            </Button>
          </div>
        </div>
      </Card>

      {/* 3. Badges & Status Indicators */}
      <Card>
        <h3 className="text-base font-bold text-slate-900 mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
          <span>بج‌ها و وضعیت‌های کالا (Status Badges)</span>
        </h3>

        <div className="flex flex-wrap items-center gap-3">
          <Badge variant="success" dot size="md">
            موجود در انبار ({toPersianDigits(45)} عدد)
          </Badge>
          <Badge variant="warning" dot size="md">
            کم‌موجودی ({toPersianDigits(4)} عدد باقی‌مانده)
          </Badge>
          <Badge variant="danger" dot size="md">
            ناموجود
          </Badge>
          <Badge variant="danger" size="md">
            منقضی شده (۳ کالا)
          </Badge>
          <Badge variant="info" size="md">
            نوشیدنی‌ها
          </Badge>
          <Badge variant="primary" size="md">
            فروش آنلاین
          </Badge>
          <Badge variant="neutral" size="md">
            دستگاه متصل
          </Badge>
        </div>
      </Card>

      {/* 4. Form Inputs & Search Bar with Barcode Scanner */}
      <Card>
        <h3 className="text-base font-bold text-slate-900 mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
          <span>فیلدهای ورود اطلاعات و نوار جستجوی بارکد</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <SearchBar
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            onScanClick={() => alert('اکشن اسکن بارکد فراخوانی شد (Phase 4 Abstraction)')}
          />

          <Input
            label="نام کالا"
            placeholder="مثال: نوشابه کوکاکولا ۳۳۰ میلی‌لیتر"
            defaultValue="کوکاکولا قوطی ۳۳۰"
            helperText="نام رسمی ثبت شده روی بسته‌بندی کالا"
          />

          <Input
            label="بارکد بین‌المللی کالا (EAN-13)"
            placeholder="۶۲۶۱۲۳۴۵۶۷۸۹۰"
            defaultValue="6261234567890"
            startIcon={<Barcode className="w-4 h-4" />}
          />

          <Input
            label="قیمت فروش (تومان)"
            placeholder="۴۵,۰۰۰"
            defaultValue="۴۵,۰۰۰ تومان"
          />
        </div>
      </Card>

      {/* 5. Pill Tabs & Category Navigation */}
      <Card>
        <h3 className="text-base font-bold text-slate-900 mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
          <span>تب‌های دسته‌بندی و ناوبری سریع کالاها</span>
        </h3>

        <div className="space-y-4">
          <Tabs
            items={categoryTabs}
            activeId={activeCategoryTab}
            onChange={setActiveCategoryTab}
            variant="pill"
          />

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs text-slate-500">نوع قیمت‌گذاری:</span>
            <Tabs
              items={[
                { id: 'retail', label: 'قیمت تک‌فروشی' },
                { id: 'wholesale', label: 'قیمت عمده' },
                { id: 'special', label: 'قیمت ویژه' },
              ]}
              activeId={activePillTab}
              onChange={setActivePillTab}
              variant="contained"
            />
          </div>
        </div>
      </Card>

      {/* 6. Alert Banners */}
      <div className="space-y-3">
        <AlertBanner
          type="warning"
          title={`${toPersianDigits(4)} کالا نزدیک انقضا`}
          subtitle="تا ۷ روز آینده تاریخ مصرف آنها به اتمام می‌رسد. لطفاً در تخفیف ویژه قرار دهید."
          badgeText="هشدار انقضا"
          actionText="مشاهده کالاها"
          icon={<Clock className="w-5 h-5" />}
        />

        <AlertBanner
          type="danger"
          title={`${toPersianDigits(7)} کالا رو به اتمام است`}
          subtitle="موجودی این اقلام به زیر نقطه سفارش مجدد رسیده است. ثبت فاکتور خرید پیشنهاد می‌شود."
          badgeText="کم‌موجودی بحرانی"
          actionText="ثبت سفارش خرید"
          icon={<AlertTriangle className="w-5 h-5" />}
        />
      </div>

      {/* 7. Data Table Showcase */}
      <Card>
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
            <span>جدول استاندارد اطلاعات کالا و انبار (Table Component)</span>
          </h3>
          <Button size="sm" variant="outline" onClick={() => setIsModalOpen(true)}>
            نمایش دیالوگ تایید
          </Button>
        </div>

        <Table>
          <TableHead>
            <TableRow>
              <TableHeaderCell>ردیف</TableHeaderCell>
              <TableHeaderCell>نام کالا و بارکد</TableHeaderCell>
              <TableHeaderCell>دسته‌بندی</TableHeaderCell>
              <TableHeaderCell>قیمت فروش</TableHeaderCell>
              <TableHeaderCell>موجودی</TableHeaderCell>
              <TableHeaderCell>وضعیت</TableHeaderCell>
              <TableHeaderCell>عملیات</TableHeaderCell>
            </TableRow>
          </TableHead>
          <TableBody>
            <TableRow>
              <TableCell className="font-mono text-xs text-slate-400">۰۱</TableCell>
              <TableCell>
                <div>
                  <div className="font-bold text-slate-900">کوکاکولا قوطی ۳۳۰ml</div>
                  <div className="text-[11px] text-slate-400 font-mono">6261234567890</div>
                </div>
              </TableCell>
              <TableCell>
                <Badge variant="info" size="sm">نوشیدنی‌ها</Badge>
              </TableCell>
              <TableCell className="font-bold text-slate-900 font-sans">
                {formatToman(45000)}
              </TableCell>
              <TableCell className="font-bold text-slate-700">
                {toPersianDigits(34)} عدد
              </TableCell>
              <TableCell>
                <Badge variant="success" dot size="sm">موجود</Badge>
              </TableCell>
              <TableCell>
                <button
                  type="button"
                  className="text-xs text-blue-600 hover:text-blue-800 font-bold ml-2 cursor-pointer"
                >
                  ویرایش
                </button>
              </TableCell>
            </TableRow>

            <TableRow>
              <TableCell className="font-mono text-xs text-slate-400">۰۲</TableCell>
              <TableCell>
                <div>
                  <div className="font-bold text-slate-900">چیپس نمکی کتل چیپس ۶۰g</div>
                  <div className="text-[11px] text-slate-400 font-mono">6269876543210</div>
                </div>
              </TableCell>
              <TableCell>
                <Badge variant="info" size="sm">تنقلات</Badge>
              </TableCell>
              <TableCell className="font-bold text-slate-900 font-sans">
                {formatToman(26000)}
              </TableCell>
              <TableCell className="font-bold text-amber-600">
                {toPersianDigits(4)} عدد
              </TableCell>
              <TableCell>
                <Badge variant="warning" dot size="sm">رو به اتمام</Badge>
              </TableCell>
              <TableCell>
                <button
                  type="button"
                  className="text-xs text-blue-600 hover:text-blue-800 font-bold ml-2 cursor-pointer"
                >
                  ویرایش
                </button>
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </Card>

      {/* Modal Example */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="تأیید حذف فاکتور فروش"
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsModalOpen(false)}>
              انصراف
            </Button>
            <Button variant="danger" onClick={() => setIsModalOpen(false)}>
              بله، حذف شود
            </Button>
          </>
        }
      >
        <p className="text-sm text-slate-600 leading-relaxed">
          آیا از حذف این فاکتور مطمئن هستید؟ این عملیات مقادیر موجودی انبار را به حالت قبل بازمی‌گرداند و غیرقابل بازگشت است.
        </p>
      </Modal>
    </div>
  );
};
