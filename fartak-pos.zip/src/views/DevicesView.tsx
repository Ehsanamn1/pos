import React, { useState } from 'react';
import { Device, StoreInfo } from '../types';
import { StorageService } from '../services/storage';
import { PrinterService } from '../services/printer';
import { scannerService } from '../services/barcodeScanner';
import { Button } from '../design-system/components/Button';
import { Badge } from '../design-system/components/Badge';
import {
  Printer,
  Scan,
  Scale,
  CreditCard,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Sliders,
  Usb,
  Wifi,
  Bluetooth,
  FileText,
} from 'lucide-react';

interface DevicesViewProps {
  store: StoreInfo;
}

export const DevicesView: React.FC<DevicesViewProps> = ({ store }) => {
  const [devices, setDevices] = useState<Device[]>(() => StorageService.getDevices());
  const [testStatus, setTestStatus] = useState<string | null>(null);

  const reloadDevices = () => {
    setDevices(StorageService.getDevices());
  };

  const toggleStatus = (device: Device) => {
    const updated: Device = {
      ...device,
      status: device.status === 'متصل' ? 'قطع' : 'متصل',
    };
    StorageService.updateDevice(updated);
    reloadDevices();
  };

  const handleTestPrint = () => {
    const sampleSale = StorageService.getSales()[0];
    if (sampleSale) {
      PrinterService.printReceipt(sampleSale, store, '80mm');
      setTestStatus('دستور چاپ آزمایشی به چاپگر حرارتی ارسال شد.');
    } else {
      setTestStatus('فاکتوری برای تست چاپ در سیستم یافت نشد.');
    }
  };

  const handleTestScannerSound = () => {
    scannerService.playBeep('success');
    setTestStatus('صدای بیپ اسکنر تست شد.');
  };

  const getDeviceIcon = (type: Device['type']) => {
    switch (type) {
      case 'printer':
        return <Printer className="w-5 h-5" />;
      case 'scanner':
        return <Scan className="w-5 h-5" />;
      case 'pos_terminal':
        return <CreditCard className="w-5 h-5" />;
      default:
        return <Scale className="w-5 h-5" />;
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Printer className="w-6 h-6 text-blue-600" />
            <span>دستگاه‌ها، چاپگرها و تجهیزات صندوق</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            پیکربندی چاپگر حرارتی فیش، بارکدخوان لیزری، ترازوی دیجیتال و پایانه‌های بانکی POS
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={handleTestScannerSound} icon={<Scan className="w-4 h-4" />}>
            تست بوق اسکنر
          </Button>
          <Button variant="primary" onClick={handleTestPrint} icon={<FileText className="w-4 h-4" />}>
            چاپ آزمایشی فیش
          </Button>
        </div>
      </div>

      {testStatus && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3 rounded-xl text-xs flex items-center justify-between animate-in fade-in duration-200">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{testStatus}</span>
          </div>
          <button
            type="button"
            onClick={() => setTestStatus(null)}
            className="text-slate-400 hover:text-slate-700 font-bold"
          >
            ×
          </button>
        </div>
      )}

      {/* Connected Devices Grid (Matching reference image) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {devices.map((device) => {
          const isConnected = device.status === 'متصل';

          return (
            <div
              key={device.id}
              className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs space-y-4 flex flex-col justify-between"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      isConnected
                        ? 'bg-blue-50 text-blue-600'
                        : 'bg-slate-100 text-slate-400'
                    }`}
                  >
                    {getDeviceIcon(device.type)}
                  </div>
                  <div>
                    <h4 className="font-bold text-xs text-slate-900">{device.name}</h4>
                    <div className="text-[11px] text-slate-400 font-mono mt-0.5">{device.model}</div>
                  </div>
                </div>

                <Badge variant={isConnected ? 'success' : 'neutral'} dot size="sm">
                  {device.status}
                </Badge>
              </div>

              {/* Hardware specifications */}
              <div className="p-3 bg-slate-50 rounded-xl text-xs text-slate-600 grid grid-cols-2 gap-2 border border-slate-100">
                <div className="flex items-center gap-1.5">
                  <Usb className="w-3.5 h-3.5 text-slate-400" />
                  <span>پورت: <strong>{device.connectionType}</strong></span>
                </div>
                {device.paperWidth && (
                  <div className="flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-slate-400" />
                    <span>اندازه کاغذ: <strong>{device.paperWidth}</strong></span>
                  </div>
                )}
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                  <span>آماده به کار</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => toggleStatus(device)}
                  className={`text-xs font-bold cursor-pointer transition-colors ${
                    isConnected ? 'text-rose-600 hover:text-rose-700' : 'text-blue-600 hover:text-blue-700'
                  }`}
                >
                  {isConnected ? 'قطع اتصال موقت' : 'برقراری اتصال'}
                </button>

                {device.type === 'printer' && (
                  <Button size="sm" variant="outline" onClick={handleTestPrint}>
                    تست چاپ
                  </Button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
