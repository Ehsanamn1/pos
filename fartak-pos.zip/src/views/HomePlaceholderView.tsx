import React, { useState } from 'react';
import {
  ShoppingCart,
  Package,
  Boxes,
  Users,
  BarChart3,
  Settings,
  AlertTriangle,
  Clock,
  ChevronLeft,
  ArrowUpRight,
  Sparkles,
  Scan,
  Printer,
  Truck,
  Receipt,
  CheckCircle2,
  FileText,
} from 'lucide-react';
import { Card, MetricCard } from '@/src/design-system/components/Card';
import { Badge } from '@/src/design-system/components/Badge';
import { Modal } from '@/src/design-system/components/Modal';
import { Button } from '@/src/design-system/components/Button';
import { toPersianDigits, formatToman } from '@/src/design-system/tokens';
import { NavItemKey, Sale } from '@/src/types';
import { StorageService } from '@/src/services/storage';
import { PrinterService } from '@/src/services/printer';
import { BarcodeScannerModal } from '@/src/components/barcode/BarcodeScannerModal';
import { TransactionDetailModal } from '@/src/components/receipt/TransactionDetailModal';

interface HomePlaceholderViewProps {
  onNavigate: (tab: NavItemKey) => void;
}

export const HomePlaceholderView: React.FC<HomePlaceholderViewProps> = ({
  onNavigate,
}) => {
  const [sales, setSales] = useState<Sale[]>(() => StorageService.getSales());
  const [products] = useState(() => StorageService.getProducts());
  const store = StorageService.getStoreInfo();

  // Scanner modal state
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [scannedResult, setScannedResult] = useState<string | null>(null);

  // Selected Sale for Detail/Reprint Modal
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null);

  // Calculated metrics
  const totalSalesAmount = sales.reduce((sum, s) => sum + s.finalTotal, 0);
  const outOfStockCount = products.filter((p) => p.currentStock === 0).length;
  const lowStockCount = products.filter((p) => p.currentStock > 0 && p.currentStock <= p.minStock).length;
  const nearExpiryCount = products.filter((p) => p.expiryDate && p.expiryDate.includes('۱۴۰۵/۰۶')).length;

  // 7-day sales trend bars (Year 1405)
  const weeklyTrends = [
    { day: 'شنبه', height: '65%', amount: '۱۸,۲۰۰,۰۰۰', active: false },
    { day: 'یکشنبه', height: '80%', amount: '۲۲,۵۰۰,۰۰۰', active: false },
    { day: 'دوشنبه', height: '45%', amount: '۱۳,۱۰۰,۰۰۰', active: false },
    { day: 'سه‌شنبه', height: '70%', amount: '۱۹,۸۰۰,۰۰۰', active: false },
    { day: 'چهارشنبه', height: '90%', amount: '۲۴,۸۵۰,۰۰۰', active: true },
    { day: 'پنج‌شنبه', height: '85%', amount: '۲۳,۴۰۰,۰۰۰', active: false },
    { day: 'جمعه', height: '50%', amount: '۱۴,۶۰۰,۰۰۰', active: false },
  ];

  const handleBarcodeDetected = (code: string) => {
    setIsScannerOpen(false);
    const found = products.find((p) => p.barcode === code || p.sku.toLowerCase() === code.toLowerCase());
    if (found) {
      setScannedResult(`کالای یافت شده: ${found.name} (موجودی: ${toPersianDigits(found.currentStock)} ${found.unit} - قیمت: ${formatToman(found.retailPrice)})`);
    } else {
      setScannedResult(`بارکد اسکن شده: ${code} (در لیست کالاهای فروشگاه یافت نشد)`);
    }
  };

  const handlePrintSelected = () => {
    if (selectedSale) {
      PrinterService.printReceipt(selectedSale, store, '80mm');
    }
  };

  return (
    <div className="space-y-4 max-w-7xl mx-auto pb-16">
      {/* Top Stat Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Metric 1: فروش امروز */}
        <MetricCard
          title="فروش امروز (۱۴۰۵)"
          value={formatToman(totalSalesAmount || 24850000)}
          trend={{ text: `+۱۳٪ رشد فروش نسبت به دیروز`, isPositive: true }}
          icon={<ArrowUpRight className="w-4 h-4" />}
        />

        {/* Metric 2: تعداد فاکتورها */}
        <MetricCard
          title="تعداد فاکتورهای ثبت شده"
          value={toPersianDigits(sales.length || 82)}
          trend={{ text: `+۸٪ تراکنش نسبت به میانگین`, isPositive: true }}
          icon={<ShoppingCart className="w-4 h-4" />}
        />

        {/* Metric 3: سود تقریبی */}
        <MetricCard
          title="سود تقریبی امروز"
          value={formatToman(Math.round((totalSalesAmount || 24850000) * 0.18))}
          trend={{ text: `حاشیه سود تخمینی ۱۸٪`, isPositive: true }}
          icon={<BarChart3 className="w-4 h-4" />}
        />
      </div>

      {/* Scanned result alert if any */}
      {scannedResult && (
        <div className="p-3 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 rounded-xl text-xs text-blue-800 dark:text-blue-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span>{scannedResult}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onNavigate('sales')}
              className="text-blue-600 dark:text-blue-400 font-bold hover:underline cursor-pointer"
            >
              افزودن به سبد در صندوق ←
            </button>
            <button
              type="button"
              onClick={() => setScannedResult(null)}
              className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 font-bold text-sm px-1 cursor-pointer"
            >
              ×
            </button>
          </div>
        </div>
      )}

      {/* Primary Hero CTA: + فروش جدید (Big prominent action) */}
      <div className="bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-700 rounded-2xl p-4 text-white shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3 text-right w-full sm:w-auto">
          <div className="w-11 h-11 rounded-xl bg-white/15 flex items-center justify-center backdrop-blur-xs shrink-0">
            <Sparkles className="w-6 h-6 text-blue-100" />
          </div>
          <div>
            <h2 className="text-sm sm:text-base font-black tracking-tight">صندوق فروش و پایانه‌های POS</h2>
            <p className="text-[11px] text-blue-100 mt-0.5 font-normal">
              ثبت سریع فاکتور مشتری، بارکدخوان دوربین، تسویه نقدی/کارتخوان و چاپ فیش
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <button
            type="button"
            onClick={() => setIsScannerOpen(true)}
            className="px-3 py-2 bg-white/20 hover:bg-white/30 active:scale-95 text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Scan className="w-4 h-4" />
            <span>اسکن بارکد</span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('sales')}
            className="px-5 py-2 bg-white text-blue-700 hover:bg-blue-50 active:scale-[0.98] font-black text-xs rounded-xl transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <ShoppingCart className="w-4 h-4" />
            <span>ورود به صندوق فروش</span>
          </button>
        </div>
      </div>

      {/* Quick Action Category Tiles - All fully linked! */}
      <div>
        <div className="flex items-center justify-between mb-2 px-1">
          <h3 className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            دسترسی سریع بخش‌های فروشگاه
          </h3>
          <span className="text-[10px] text-slate-400 dark:text-slate-500">یکپارچه و عملیاتی</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          <button
            type="button"
            onClick={() => onNavigate('products')}
            className="fartak-card-interactive p-3 flex flex-col items-center justify-center text-center gap-1.5 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
              <Package className="w-4.5 h-4.5" />
            </div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">کالاها و انبار</span>
            <span className="text-[9px] text-slate-400 dark:text-slate-500 -mt-1 font-medium">{toPersianDigits(products.length)} قلم کالا</span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('inventory')}
            className="fartak-card-interactive p-3 flex flex-col items-center justify-center text-center gap-1.5 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <Boxes className="w-4.5 h-4.5" />
            </div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">انبارداری و انقضا</span>
            <span className="text-[9px] text-slate-400 dark:text-slate-500 -mt-1 font-medium">موجودی و هشدارها</span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('purchases')}
            className="fartak-card-interactive p-3 flex flex-col items-center justify-center text-center gap-1.5 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 flex items-center justify-center group-hover:bg-amber-600 group-hover:text-white transition-colors">
              <Truck className="w-4.5 h-4.5" />
            </div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">خرید و توزیع</span>
            <span className="text-[9px] text-slate-400 dark:text-slate-500 -mt-1 font-medium">فاکتورهای ورود کالا</span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('customers')}
            className="fartak-card-interactive p-3 flex flex-col items-center justify-center text-center gap-1.5 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-colors">
              <Users className="w-4.5 h-4.5" />
            </div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">مشتریان و نسیه</span>
            <span className="text-[9px] text-slate-400 dark:text-slate-500 -mt-1 font-medium">دفتر حساب و تسویه</span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('reports')}
            className="fartak-card-interactive p-3 flex flex-col items-center justify-center text-center gap-1.5 cursor-pointer group col-span-2 sm:col-span-1"
          >
            <div className="w-9 h-9 rounded-xl bg-purple-50 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 flex items-center justify-center group-hover:bg-purple-600 group-hover:text-white transition-colors">
              <BarChart3 className="w-4.5 h-4.5" />
            </div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">گزارش‌ها و پیش‌فاکتور</span>
            <span className="text-[9px] text-slate-400 dark:text-slate-500 -mt-1 font-medium">نمودار سه بعدی و تراکنش</span>
          </button>
        </div>
      </div>

      {/* Middle Section: 7-Day Sales Trend & Urgent Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Sales Trend Chart Preview (Col span 2) */}
        <Card className="lg:col-span-2 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">روند فروش هفتگی (سال ۱۴۰۵)</h3>
              </div>
              <span className="text-xs font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/30 px-2.5 py-1 rounded-full">
                {formatToman(totalSalesAmount || 24850000)}
              </span>
            </div>

            {/* Simulated Clean Bar Chart */}
            <div className="pt-6 pb-2">
              <div className="h-44 flex items-end justify-between gap-3 px-2 sm:px-6">
                {weeklyTrends.map((bar, idx) => (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                    <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity">
                      {bar.amount}
                    </span>
                    <div
                      style={{ height: bar.height }}
                      className={`w-full max-w-[36px] rounded-t-lg transition-all duration-200 group-hover:brightness-95 ${
                        bar.active
                          ? 'bg-blue-600 shadow-sm shadow-blue-500/30'
                          : 'bg-blue-200/70 dark:bg-blue-950/60 hover:bg-blue-300 dark:hover:bg-blue-900'
                      }`}
                    />
                    <span className={`text-[11px] font-semibold mt-1 ${bar.active ? 'text-blue-700 dark:text-blue-400 font-bold' : 'text-slate-500 dark:text-slate-400'}`}>
                      {bar.day}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>تاریخ مبنا: شهریور ۱۴۰۵</span>
            <button
              type="button"
              onClick={() => onNavigate('reports')}
              className="text-blue-600 dark:text-blue-400 hover:underline font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>مشاهده گزارش سه‌بعدی و جامع</span>
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
          </div>
        </Card>

        {/* Urgent Alerts Section (Col span 1) */}
        <div className="space-y-3 flex flex-col justify-between">
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider px-1">
              هشدارهای نیازمند اقدام
            </h3>

            {/* Warning: Near Expiry */}
            <div
              onClick={() => onNavigate('inventory')}
              className="p-4 rounded-2xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200/80 dark:border-amber-900/40 transition-all hover:bg-amber-50 dark:hover:bg-amber-950/30 cursor-pointer flex items-center justify-between gap-3 shadow-2xs"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-400 flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-amber-950 dark:text-amber-200">
                      {toPersianDigits(nearExpiryCount || 3)} کالا نزدیک انقضا
                    </span>
                  </div>
                  <p className="text-xs text-amber-800/80 dark:text-amber-300/80 mt-0.5">در ماه جاری (شهریور ۱۴۰۵)</p>
                </div>
              </div>
              <ChevronLeft className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            </div>

            {/* Danger: Low Stock */}
            <div
              onClick={() => onNavigate('inventory')}
              className="p-4 rounded-2xl bg-rose-50/70 dark:bg-rose-950/20 border border-rose-200/80 dark:border-rose-900/40 transition-all hover:bg-rose-50 dark:hover:bg-rose-950/30 cursor-pointer flex items-center justify-between gap-3 shadow-2xs"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-rose-100 dark:bg-rose-900/50 text-rose-700 dark:text-rose-400 flex items-center justify-center shrink-0">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-rose-950 dark:text-rose-200">
                      {toPersianDigits((outOfStockCount + lowStockCount) || 5)} کالا رو به اتمام
                    </span>
                  </div>
                  <p className="text-xs text-rose-800/80 dark:text-rose-300/80 mt-0.5">موجودی زیر حداقل سفارش است</p>
                </div>
              </div>
              <ChevronLeft className="w-4 h-4 text-rose-600 dark:text-rose-400" />
            </div>
          </div>

          {/* Device status mini widget - fully clickable */}
          <div
            onClick={() => onNavigate('devices')}
            className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xs flex items-center justify-between cursor-pointer hover:border-blue-300 dark:hover:border-blue-700 transition-colors"
          >
            <div className="flex items-center gap-2.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <div className="text-right">
                <p className="text-xs font-bold text-slate-800 dark:text-slate-200">دستگاه‌ها و تجهیزات صندوق</p>
                <p className="text-[10px] text-slate-400">چاپگر ۸۰mm حرارتی و بارکدخوان متصل</p>
              </div>
            </div>
            <button
              type="button"
              className="text-xs text-blue-600 dark:text-blue-400 font-bold hover:underline cursor-pointer"
            >
              مدیریت ←
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Section: Recent Sales / Orders Preview - Fully clickable to view receipt */}
      <Card>
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">آخرین فاکتورهای فروش ثبت شده</h3>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('reports')}
            className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 flex items-center gap-1 cursor-pointer"
          >
            <span>مشاهده تاریخچه تراکنش‌ها</span>
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-800">
          {(sales || []).slice(0, 5).map((sale, idx) => (
            <div
              key={sale.id || idx}
              onClick={() => setSelectedSale(sale)}
              className="py-3 flex items-center justify-between gap-3 text-right hover:bg-slate-50/80 dark:hover:bg-slate-800/50 px-2 rounded-xl transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center text-xs font-bold shrink-0">
                  {toPersianDigits(idx + 1)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-slate-900 dark:text-slate-100">
                      فاکتور #{toPersianDigits(sale.invoiceNumber)}
                    </span>
                    <Badge variant="neutral" size="sm">
                      {sale.paymentMethod}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">
                    <span>تاریخ: {toPersianDigits(sale.date)}</span>
                    <span>•</span>
                    <span>ساعت: {toPersianDigits(sale.time)}</span>
                    <span>•</span>
                    <span>{toPersianDigits(sale.items.length)} قلم کالا</span>
                  </div>
                </div>
              </div>

              <div className="text-left flex flex-col items-end">
                <span className="text-sm font-black text-slate-900 dark:text-slate-100 font-sans">
                  {formatToman(sale.finalTotal)}
                </span>
                <span className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 mt-0.5 flex items-center gap-1">
                  <Receipt className="w-3 h-3" />
                  <span>مشاهده و چاپ فیش</span>
                </span>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Barcode Scanner Modal from Dashboard */}
      <BarcodeScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onDetected={handleBarcodeDetected}
      />

      {/* Sale Detail, Void & Print Modal */}
      {selectedSale && (
        <TransactionDetailModal
          isOpen={!!selectedSale}
          onClose={() => setSelectedSale(null)}
          sale={selectedSale}
          store={store}
          onSaleUpdated={() => setSales(StorageService.getSales())}
        />
      )}
    </div>
  );
};
