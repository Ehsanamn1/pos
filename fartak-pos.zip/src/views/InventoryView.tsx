import React, { useState, useMemo } from 'react';
import { Product, Purchase } from '../types';
import { StorageService } from '../services/storage';
import { formatToman, toPersianDigits } from '../design-system/tokens';
import { Badge } from '../design-system/components/Badge';
import { Button } from '../design-system/components/Button';
import { Modal } from '../design-system/components/Modal';
import { Input } from '../design-system/components/Input';
import {
  Boxes,
  Clock,
  AlertTriangle,
  ArrowDownToLine,
  ArrowUpFromLine,
  Search,
  CheckCircle2,
  Calendar,
  XCircle,
  Tag,
} from 'lucide-react';

export const InventoryView: React.FC = () => {
  const [products, setProducts] = useState<Product[]>(() => StorageService.getProducts());
  const [activeTab, setActiveTab] = useState<'inventory' | 'expiry'>('inventory');
  const [expiryFilter, setExpiryFilter] = useState<'all' | '7days' | '30days' | 'expired'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Stock Adjustment Modal
  const [selectedProductForAdjust, setSelectedProductForAdjust] = useState<Product | null>(null);
  const [adjustmentQuantity, setAdjustmentQuantity] = useState<number>(0);
  const [adjustmentType, setAdjustmentType] = useState<'in' | 'out' | 'set'>('in');
  const [adjustmentReason, setAdjustmentReason] = useState<string>('ورود کالا');

  const reloadData = () => {
    setProducts(StorageService.getProducts());
  };

  // Inventory Metrics
  const totalStockCount = useMemo(() => {
    return products.reduce((sum, p) => sum + p.currentStock, 0);
  }, [products]);

  const totalInventoryValue = useMemo(() => {
    return products.reduce((sum, p) => sum + p.currentStock * p.purchasePrice, 0);
  }, [products]);

  const lowStockCount = useMemo(() => {
    return products.filter((p) => p.currentStock <= p.minStock && p.currentStock > 0).length;
  }, [products]);

  const outOfStockCount = useMemo(() => {
    return products.filter((p) => p.currentStock === 0).length;
  }, [products]);

  // Expiry categorized
  const expiredProducts = useMemo(() => {
    // Simulated based on sample date 1403/06/25
    return products.filter((p) => {
      if (!p.expiryDate) return false;
      return p.expiryDate <= '۱۴۰۳/۰۶/۲۵';
    });
  }, [products]);

  const near7DaysProducts = useMemo(() => {
    return products.filter((p) => {
      if (!p.expiryDate) return false;
      return p.expiryDate > '۱۴۰۳/۰۶/۲۵' && p.expiryDate <= '۱۴۰۳/۰۷/۰۵';
    });
  }, [products]);

  const near30DaysProducts = useMemo(() => {
    return products.filter((p) => {
      if (!p.expiryDate) return false;
      return p.expiryDate > '۱۴۰۳/۰۶/۲۵' && p.expiryDate <= '۱۴۰۳/۰۷/۲۵';
    });
  }, [products]);

  // Expiry tab list
  const filteredExpiryList = useMemo(() => {
    if (expiryFilter === 'expired') return expiredProducts;
    if (expiryFilter === '7days') return near7DaysProducts;
    if (expiryFilter === '30days') return near30DaysProducts;
    return [...expiredProducts, ...near7DaysProducts, ...near30DaysProducts];
  }, [expiryFilter, expiredProducts, near7DaysProducts, near30DaysProducts]);

  // Filtered inventory list
  const filteredInventory = useMemo(() => {
    return products.filter((p) => {
      const q = searchQuery.trim().toLowerCase();
      return !q || p.name.toLowerCase().includes(q) || p.barcode.includes(q);
    });
  }, [products, searchQuery]);

  const handleApplyAdjustment = () => {
    if (!selectedProductForAdjust) return;

    let newStock = selectedProductForAdjust.currentStock;
    if (adjustmentType === 'in') {
      newStock += adjustmentQuantity;
    } else if (adjustmentType === 'out') {
      newStock = Math.max(0, newStock - adjustmentQuantity);
    } else {
      newStock = Math.max(0, adjustmentQuantity);
    }

    StorageService.updateProduct({
      ...selectedProductForAdjust,
      currentStock: newStock,
    });

    setSelectedProductForAdjust(null);
    setAdjustmentQuantity(0);
    reloadData();
  };

  const handleApplyQuickDiscount = (product: Product, percentage: number) => {
    const newPrice = Math.round(product.retailPrice * (1 - percentage / 100));
    StorageService.updateProduct({
      ...product,
      retailPrice: newPrice,
      specialPrice: newPrice,
    });
    alert(`تخفیف ${percentage}٪ روی کالای «${product.name}» اعمال شد. قیمت جدید: ${formatToman(newPrice)}`);
    reloadData();
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Top Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Boxes className="w-6 h-6 text-blue-600" />
            <span>مدیریت انبار، موجودی و تاریخ انقضا</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            کنترل کاردکس، هشدار کم‌موجودی، محاسبه ارزش ریالی انبار و رصد کالاهای فاسدشدنی
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1.5 rounded-xl border border-slate-200">
          <button
            type="button"
            onClick={() => setActiveTab('inventory')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'inventory'
                ? 'bg-white text-blue-600 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            موجودی و کاردکس
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('expiry')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'expiry'
                ? 'bg-white text-rose-600 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>تاریخ انقضا ({toPersianDigits(expiredProducts.length + near7DaysProducts.length)})</span>
          </button>
        </div>
      </div>

      {activeTab === 'inventory' ? (
        <>
          {/* Inventory Summary Cards (Matching Reference Image) */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
              <div className="text-[11px] text-slate-400 font-bold">کل موجودی انبار</div>
              <div className="text-xl font-black text-slate-900 font-sans mt-1">
                {toPersianDigits(totalStockCount)} <span className="text-xs font-normal text-slate-500">عدد</span>
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
              <div className="text-[11px] text-slate-400 font-bold">ارزش ریالی موجودی</div>
              <div className="text-xl font-black text-blue-600 font-sans mt-1">
                {formatToman(totalInventoryValue)}
              </div>
            </div>

            <div className="bg-amber-50/70 p-4 rounded-2xl border border-amber-200 shadow-xs">
              <div className="text-[11px] text-amber-700 font-bold">نزدیک انقضا</div>
              <div className="text-xl font-black text-amber-900 font-sans mt-1">
                {toPersianDigits(near7DaysProducts.length)} <span className="text-xs font-normal text-amber-700">کالا</span>
              </div>
            </div>

            <div className="bg-rose-50/70 p-4 rounded-2xl border border-rose-200 shadow-xs">
              <div className="text-[11px] text-rose-700 font-bold">ناموجود در قفسه</div>
              <div className="text-xl font-black text-rose-900 font-sans mt-1">
                {toPersianDigits(outOfStockCount)} <span className="text-xs font-normal text-rose-700">کالا</span>
              </div>
            </div>

            <div className="bg-amber-50/50 p-4 rounded-2xl border border-amber-200 shadow-xs">
              <div className="text-[11px] text-amber-700 font-bold">کم‌موجودی</div>
              <div className="text-xl font-black text-amber-900 font-sans mt-1">
                {toPersianDigits(lowStockCount)} <span className="text-xs font-normal text-amber-700">کالا</span>
              </div>
            </div>
          </div>

          {/* Search bar & Inventory Table */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 space-y-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="w-full sm:w-80 relative">
                <input
                  type="text"
                  placeholder="جستجو در موجودی کالاها..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-10 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white focus:outline-none focus:border-blue-600"
                />
                <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            {/* Inventory Items List */}
            <div className="divide-y divide-slate-100">
              {filteredInventory.map((product) => {
                const isLow = product.currentStock <= product.minStock && product.currentStock > 0;
                const isOut = product.currentStock === 0;

                return (
                  <div
                    key={product.id}
                    className="py-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 hover:bg-slate-50/60 px-2 rounded-xl transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-slate-50 border border-slate-100 p-1 flex items-center justify-center shrink-0">
                        <img
                          src={product.imageUrl}
                          alt={product.name}
                          className="max-h-full max-w-full object-contain"
                        />
                      </div>
                      <div>
                        <h4 className="font-bold text-xs text-slate-900">{product.name}</h4>
                        <div className="text-[11px] text-slate-400 font-mono flex items-center gap-2 mt-0.5">
                          <span>{product.sku}</span>
                          <span>•</span>
                          <span>{product.categoryName}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 self-end sm:self-auto">
                      <div className="text-left sm:text-right">
                        <div className="font-black text-sm text-slate-900 font-sans">
                          {toPersianDigits(product.currentStock)} {product.unit}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          نقطه سفارش: {toPersianDigits(product.minStock)} {product.unit}
                        </div>
                      </div>

                      <div className="w-24 text-center">
                        {isOut ? (
                          <Badge variant="danger" dot size="sm">ناموجود</Badge>
                        ) : isLow ? (
                          <Badge variant="warning" dot size="sm">کم‌موجودی</Badge>
                        ) : (
                          <Badge variant="success" dot size="sm">موجود</Badge>
                        )}
                      </div>

                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setSelectedProductForAdjust(product);
                          setAdjustmentQuantity(10);
                          setAdjustmentType('in');
                        }}
                      >
                        اصلاح موجودی
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      ) : (
        /* Expiry Tracker View (Matching Reference Image) */
        <div className="space-y-6">
          {/* Top Expiry Alert Box */}
          <div className="bg-rose-500 rounded-2xl p-6 text-white shadow-md flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-xs font-bold bg-white/20 text-white px-3 py-1 rounded-full inline-block mb-1">
                هشدار سلامت و انقضا
              </span>
              <h3 className="text-2xl font-black tracking-tight">
                {toPersianDigits(expiredProducts.length)} کالا منقضی شده
              </h3>
              <p className="text-xs text-rose-100 max-w-lg leading-relaxed">
                این اقلام تاریخ مصرفشان گذشته است و باید سریعاً از قفسه فروشگاهی جمع‌آوری و در ضایعات ثبت شوند.
              </p>
            </div>
            <div className="w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center shrink-0">
              <XCircle className="w-10 h-10 text-white" />
            </div>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-2">
            {[
              { id: 'all', label: 'همه اقلام حسّاس' },
              { id: 'expired', label: `منقضی شده (${toPersianDigits(expiredProducts.length)})` },
              { id: '7days', label: `تا ۷ روز آینده (${toPersianDigits(near7DaysProducts.length)})` },
              { id: '30days', label: `تا ۳۰ روز آینده (${toPersianDigits(near30DaysProducts.length)})` },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setExpiryFilter(tab.id as any)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  expiryFilter === tab.id
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Expiry Items List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredExpiryList.map((product) => {
              const isExpired = product.expiryDate <= '۱۴۰۳/۰۶/۲۵';

              return (
                <div
                  key={product.id}
                  className={`bg-white rounded-2xl p-4 border transition-all flex flex-col justify-between gap-3 ${
                    isExpired
                      ? 'border-rose-300 bg-rose-50/20'
                      : 'border-amber-200 bg-amber-50/10'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="w-14 h-14 rounded-xl bg-white border border-slate-200 p-1 flex items-center justify-center shrink-0">
                      <img
                        src={product.imageUrl}
                        alt={product.name}
                        className="max-h-full max-w-full object-contain"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] text-slate-400 font-mono">{product.sku}</span>
                        {isExpired ? (
                          <Badge variant="danger" dot size="sm">منقضی شده</Badge>
                        ) : (
                          <Badge variant="warning" dot size="sm">نزدیک انقضا</Badge>
                        )}
                      </div>
                      <h4 className="font-bold text-xs text-slate-900 mt-1">{product.name}</h4>
                      <div className="text-[11px] font-mono text-slate-500 mt-0.5 flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        <span>تاریخ انقضا: <strong>{product.expiryDate}</strong></span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <div className="text-slate-600">
                      موجودی: <strong>{toPersianDigits(product.currentStock)} {product.unit}</strong>
                    </div>

                    <div className="flex items-center gap-2">
                      {!isExpired && (
                        <button
                          type="button"
                          onClick={() => handleApplyQuickDiscount(product, 20)}
                          className="px-2.5 py-1.5 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-lg font-bold text-[11px] cursor-pointer flex items-center gap-1 transition-colors"
                        >
                          <Tag className="w-3 h-3" />
                          <span>تخفیف ۲۰٪ سریع</span>
                        </button>
                      )}
                      <Button
                        size="sm"
                        variant={isExpired ? 'danger' : 'outline'}
                        onClick={() => {
                          setSelectedProductForAdjust(product);
                          setAdjustmentType('out');
                          setAdjustmentQuantity(product.currentStock);
                          setAdjustmentReason('ثبت ضایعات انقضا');
                        }}
                      >
                        {isExpired ? 'خروج به ضایعات' : 'اصلاح موجودی'}
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Stock Adjustment Modal */}
      <Modal
        isOpen={!!selectedProductForAdjust}
        onClose={() => setSelectedProductForAdjust(null)}
        title={`اصلاح موجودی: ${selectedProductForAdjust?.name || ''}`}
        footer={
          <>
            <Button variant="ghost" onClick={() => setSelectedProductForAdjust(null)}>
              انصراف
            </Button>
            <Button variant="primary" onClick={handleApplyAdjustment} icon={<CheckCircle2 className="w-4 h-4" />}>
              ثبت در کاردکس انبار
            </Button>
          </>
        }
      >
        <div className="space-y-4 text-xs">
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
            <span className="text-slate-500">موجودی فعلی در سیستم:</span>
            <span className="font-bold text-slate-900 text-sm">
              {toPersianDigits(selectedProductForAdjust?.currentStock || 0)} {selectedProductForAdjust?.unit}
            </span>
          </div>

          <div className="space-y-1.5">
            <label className="font-bold text-slate-700">نوع عملیات:</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setAdjustmentType('in')}
                className={`p-2 rounded-xl text-center font-bold transition-all cursor-pointer ${
                  adjustmentType === 'in'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                ورود کالا (+)
              </button>
              <button
                type="button"
                onClick={() => setAdjustmentType('out')}
                className={`p-2 rounded-xl text-center font-bold transition-all cursor-pointer ${
                  adjustmentType === 'out'
                    ? 'bg-rose-600 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                خروج کالا / ضایعات (-)
              </button>
              <button
                type="button"
                onClick={() => setAdjustmentType('set')}
                className={`p-2 rounded-xl text-center font-bold transition-all cursor-pointer ${
                  adjustmentType === 'set'
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                شمارش دقیق انبار (=)
              </button>
            </div>
          </div>

          <Input
            label="تعداد (عدد/بسته):"
            type="number"
            value={adjustmentQuantity || ''}
            onChange={(e) => setAdjustmentQuantity(Math.max(0, parseInt(e.target.value, 10) || 0))}
          />

          <Input
            label="علت تغییر موجودی:"
            placeholder="مثال: فاکتور خرید، ضایعات، مغایرت انبارگردانی..."
            value={adjustmentReason}
            onChange={(e) => setAdjustmentReason(e.target.value)}
          />
        </div>
      </Modal>
    </div>
  );
};
