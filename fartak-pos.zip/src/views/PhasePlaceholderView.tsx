import React from 'react';
import { Card } from '@/src/design-system/components/Card';
import { Button } from '@/src/design-system/components/Button';
import { NavItemKey } from '@/src/types';
import { Sparkles, ArrowRight, Construction } from 'lucide-react';

interface PhasePlaceholderViewProps {
  title: string;
  phaseNumber: number;
  description: string;
  onNavigateHome: () => void;
  onNavigateDesignSystem: () => void;
}

export const PhasePlaceholderView: React.FC<PhasePlaceholderViewProps> = ({
  title,
  phaseNumber,
  description,
  onNavigateHome,
  onNavigateDesignSystem,
}) => {
  return (
    <div className="max-w-2xl mx-auto py-12 px-4 text-center">
      <Card className="p-8 sm:p-12 text-center space-y-5 border-dashed border-2 border-slate-200">
        <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto shadow-xs">
          <Construction className="w-8 h-8" />
        </div>

        <div className="space-y-2">
          <span className="inline-block text-xs font-bold text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
            مرحله آینده • فاز {phaseNumber}
          </span>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            بخش {title}
          </h2>
          <p className="text-sm text-slate-500 max-w-md mx-auto leading-relaxed">
            {description}
          </p>
        </div>

        <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 text-xs text-slate-600 space-y-1">
          <p className="font-bold text-slate-800">
            وضعیت فعلی: تکمیل فاز ۱ (سیستم طراحی و پوسته تعاملی)
          </p>
          <p className="text-slate-500">
            طبق دستورالعمل پروژه، منطق این بخش در فاز {phaseNumber} پیاده‌سازی خواهد شد.
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-3 pt-3">
          <Button variant="primary" onClick={onNavigateHome}>
            بازگشت به داشبورد اصلی
          </Button>
          <Button variant="outline" onClick={onNavigateDesignSystem} icon={<Sparkles className="w-4 h-4 text-blue-600" />}>
            مشاهده سیستم طراحی
          </Button>
        </div>
      </Card>
    </div>
  );
};
