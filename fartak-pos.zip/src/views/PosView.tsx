import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Product,
  CartItem,
  Sale,
  StoreInfo,
  Customer,
  ProformaInvoice,
} from '../types';
import { StorageService } from '../services/storage';
import { scannerService } from '../services/barcodeScanner';
import { formatToman, toPersianDigits } from '../design-system/tokens';
import { CheckoutModal } from '../components/checkout/CheckoutModal';
import { ReceiptModal } from '../components/receipt/ReceiptModal';
import { TransactionDetailModal } from '../components/receipt/TransactionDetailModal';
import { BarcodeScannerModal } from '../components/barcode/BarcodeScannerModal';
import { ProformaModal } from '../components/receipt/ProformaModal';
import { SmartProductSearch } from '../components/pos/SmartProductSearch';
import {
  Search,
  Scan,
  Plus,
  Minus,
  Trash2,
  Receipt,
  RotateCcw,
  Bell,
  Sparkles,
  Barcode,
  PackagePlus,
  ArrowDownToLine,
  Boxes,
  TrendingUp,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Volume2,
  FileText,
  Filter,
} from 'lucide-react';

interface PosViewProps {
  onNavigate: (tab: any) => void;
  store: StoreInfo;
}

export const PosView: React.FC<PosViewProps> = ({ onNavigate, store }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [recentSales, setRecentSales] = useState<Sale[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [cart, setCart] = useState<CartItem[]>([]);

  // Modals
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isReceiptOpen, setIsReceiptOpen] = useState(false);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isProformaOpen, setIsProformaOpen] = useState(false);
  const [currentProforma, setCurrentProforma] = useState<ProformaInvoice | null>(null);
  const [lastCompletedSale, setLastCompletedSale] = useState<Sale | null>(null);
  const [selectedHistoricalSale, setSelectedHistoricalSale] = useState<Sale | null>(null);

  // Invoice number simulation
  const nextInvoiceNumber = useMemo(() => {
    if (recentSales.length === 0) return '1042';
    const max = Math.max(...recentSales.map((s) => parseInt(s.invoiceNumber, 10) || 1000));
    return (max + 1).toString();
  }, [recentSales]);

  // Load initial data
  const loadData = () => {
    const loadedProducts = StorageService.getProducts();
    const loadedCustomers = StorageService.getCustomers();
    const loadedSales = StorageService.getSales();
    setProducts(loadedProducts);
    setCustomers(loadedCustomers);
    setRecentSales(loadedSales);
  };

  useEffect(() => {
    loadData();

    // Init hardware scanner listener
    const cleanupInit = scannerService.init(() => StorageService.getProducts());
    const cleanupSub = scannerService.subscribe((barcode, product) => {
      if (product) {
        addToCart(product);
      } else {
        setIsScannerOpen(true);
      }
    });

    return () => {
      cleanupInit();
      cleanupSub();
    };
  }, []);

  // Cart operations
  const addToCart = (product: Product) => {
    scannerService.playBeep('success');
    setCart((prevCart) => {
      const existing = prevCart.find((item) => item.product.id === product.id);
      if (existing) {
        return prevCart.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [
        {
          product,
          quantity: 1,
          unitPrice: product.retailPrice,
          discount: 0,
        },
        ...prevCart,
      ];
    });
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart((prevCart) => {
      return prevCart
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.product.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
  };

  // Filtered products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchCat = selectedCategory === 'all' || p.categoryId === selectedCategory;
      const matchQuery =
        !searchQuery.trim() ||
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.barcode.includes(searchQuery.trim()) ||
        p.sku.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCat && matchQuery;
    });
  }, [products, selectedCategory, searchQuery]);

  // Quick products (top 4 featured)
  const quickProducts = useMemo(() => {
    return (products || []).slice(0, 4);
  }, [products]);

  // Cart totals
  const subtotal = cart.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  const totalDiscount = cart.reduce((sum, item) => sum + item.discount * item.quantity, 0);
  const tax = Math.round(((subtotal - totalDiscount) * store.taxRate) / 100);
  const finalTotal = Math.max(0, subtotal - totalDiscount + tax);
  const totalItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Categories list
  const categories = [
    { id: 'all', name: 'همه' },
    { id: 'drinks', name: 'نوشیدنی‌ها' },
    { id: 'snacks', name: 'تنقلات' },
    { id: 'dairy', name: 'لبنیات' },
    { id: 'groceries', name: 'مواد غذایی' },
    { id: 'hygiene', name: 'بهداشتی' },
    { id: 'other', name: 'دیگر' },
  ];

  // Stock alerts count
  const lowStockCount = products.filter((p) => p.currentStock <= p.minStock).length;
  const nearExpiryCount = products.filter((p) => p.expiryDate && p.expiryDate.startsWith('۱۴۰۳/۰۶/')).length;

  const handleCheckoutSuccess = (sale: Sale) => {
    setIsCheckoutOpen(false);
    setLastCompletedSale(sale);
    setIsReceiptOpen(true);
    setCart([]);
    loadData();
  };

  const handleGenerateProforma = () => {
    if (cart.length === 0) return;
    const newProforma = StorageService.addProforma({
      issueDate: new Date().toLocaleDateString('fa-IR'),
      validUntil: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toLocaleDateString('fa-IR'),
      items: cart.map((c) => ({
        productId: c.product.id,
        productName: c.product.name,
        quantity: c.quantity,
        unitPrice: c.unitPrice,
        total: c.unitPrice * c.quantity - c.discount * c.quantity,
      })),
      subtotal,
      discount: totalDiscount,
      tax,
      finalTotal,
      notes: 'اعتبار این پیش‌فاکتور تا ۵ روز کاری از زمان صدور می‌باشد.',
      cashierName: 'رضا کمالی (صندوق‌دار)',
    });
    setCurrentProforma(newProforma);
    setIsProformaOpen(true);
  };

  const handleConvertProformaToSale = (prof: ProformaInvoice) => {
    // Open checkout directly with cart items
    setIsCheckoutOpen(true);
  };

  return (
    <div className="space-y-4 max-w-[1400px] mx-auto pb-16">
      {/* Top Mobile/Tablet Bar */}
      <div className="flex items-center justify-between bg-white rounded-xl p-3 border border-slate-200/80 shadow-2xs gap-2">
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => setIsScannerOpen(true)}
            className="w-8.5 h-8.5 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center hover:bg-blue-100 transition-all cursor-pointer"
            title="اسکن بارکد"
          >
            <Scan className="w-4 h-4" />
          </button>
          <div>
            <div className="text-[11px] text-slate-400 font-medium">فاکتور جاری</div>
            <div className="text-xs font-black text-slate-900 flex items-center gap-1">
              <span>فروش جدید</span>
              <span className="font-mono text-blue-600">#{toPersianDigits(nextInvoiceNumber)}</span>
            </div>
          </div>
        </div>

        {/* Global Smart Search Bar */}
        <div className="flex-1 max-w-md mx-3 hidden sm:block">
          <SmartProductSearch
            products={products}
            onSelectProduct={(product) => addToCart(product)}
            onOpenScanner={() => setIsScannerOpen(true)}
            placeholder="جستجوی هوشمند کالا (نام، بارکد، کد SKU)..."
          />
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setIsScannerOpen(true)}
            className="hidden md:flex items-center gap-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer"
          >
            <Scan className="w-3.5 h-3.5" />
            <span>اسکنر بارکد</span>
          </button>

          <button
            type="button"
            className="w-8.5 h-8.5 rounded-lg bg-slate-50 hover:bg-slate-100 text-slate-600 flex items-center justify-center transition-all relative cursor-pointer"
          >
            <Bell className="w-3.5 h-3.5" />
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 absolute top-2 right-2 ring-1 ring-white" />
          </button>
        </div>
      </div>

      {/* Main Grid: POS Products (Left/Center in RTL) vs Cart Panel (Right in RTL) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Left/Center Area (8 cols on desktop): Categories + Products Grid + Bottom Widgets */}
        <div className="lg:col-span-7 xl:col-span-8 space-y-4">
          {/* Mobile search bar (visible on mobile only) */}
          <div className="sm:hidden">
            <SmartProductSearch
              products={products}
              onSelectProduct={(product) => addToCart(product)}
              onOpenScanner={() => setIsScannerOpen(true)}
              placeholder="جستجوی هوشمند کالا یا بارکد..."
            />
          </div>

          {/* Category Pill Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-lg text-[11px] font-bold whitespace-nowrap transition-all cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-blue-600 text-white shadow-2xs'
                    : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200/70'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>

          {/* Products Grid (compact, refined sizing) */}
          <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-2.5">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="bg-white rounded-xl border border-slate-200/80 p-2.5 flex flex-col justify-between hover:shadow-sm hover:border-blue-300 transition-all duration-150 group relative overflow-hidden"
              >
                {/* Stock warning pill if low */}
                {product.currentStock <= product.minStock && (
                  <span className="absolute top-1.5 right-1.5 text-[9px] font-bold bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded-md z-10">
                    کم‌موجودی ({toPersianDigits(product.currentStock)})
                  </span>
                )}

                {/* Product Image */}
                <div className="w-full h-22 rounded-lg bg-slate-50 flex items-center justify-center p-1.5 mb-2 overflow-hidden group-hover:scale-105 transition-transform duration-200">
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    className="max-h-full max-w-full object-contain mix-blend-multiply"
                    loading="lazy"
                  />
                </div>

                {/* Info */}
                <div className="space-y-0.5">
                  <h4 className="font-bold text-[11px] text-slate-800 line-clamp-1 group-hover:text-blue-600 transition-colors">
                    {product.name}
                  </h4>
                  <div className="text-[10px] text-slate-400 font-mono flex items-center justify-between">
                    <span>{product.unit}</span>
                    <span>{toPersianDigits(product.currentStock)} عدد</span>
                  </div>
                </div>

                {/* Price and Add button */}
                <div className="flex items-center justify-between pt-2 mt-1.5 border-t border-slate-100">
                  <div className="font-sans font-black text-[11px] sm:text-xs text-slate-900">
                    {formatToman(product.retailPrice)}
                  </div>
                  <button
                    type="button"
                    onClick={() => addToCart(product)}
                    className="w-6 h-6 rounded-md bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white flex items-center justify-center transition-all cursor-pointer shadow-2xs active:scale-90"
                    title="افزودن به سبد"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}

            {filteredProducts.length === 0 && (
              <div className="col-span-full bg-white rounded-xl p-8 text-center border border-dashed border-slate-300 text-slate-400 space-y-1.5">
                <Search className="w-8 h-8 mx-auto text-slate-300" />
                <p className="text-xs font-bold text-slate-600">کالایی با این مشخصات یافت نشد!</p>
                <p className="text-[11px] text-slate-400">عبارت جستجو یا دسته‌بندی را تغییر دهید.</p>
              </div>
            )}
          </div>

          {/* Bottom Interactive POS Widgets (Matching reference image) */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
            {/* 1. Interactive Barcode Scanner Banner (5 cols) */}
            <div className="md:col-span-6 bg-linear-to-r from-blue-600 to-indigo-700 rounded-xl p-3 text-white flex items-center justify-between shadow-2xs relative overflow-hidden">
              <div className="relative z-10 space-y-1.5">
                <span className="text-[9px] font-bold bg-white/20 text-white px-2 py-0.2 rounded-full inline-block">
                  سریع، دقیق، بدون خطا
                </span>
                <h4 className="font-black text-xs">اسکنر هوشمند بارکد</h4>
                <p className="text-[10px] text-blue-100 max-w-[190px] leading-relaxed">
                  اتصال خودکار به بارکدخوان فیزیکی و دوربین گوشی
                </p>
                <button
                  type="button"
                  onClick={() => setIsScannerOpen(true)}
                  className="mt-0.5 bg-white text-blue-700 font-bold text-[11px] px-2.5 py-1 rounded-lg hover:bg-blue-50 transition-all cursor-pointer shadow-2xs flex items-center gap-1.5"
                >
                  <Scan className="w-3 h-3" />
                  <span>شروع اسکن</span>
                </button>
              </div>

              <div className="w-16 h-16 shrink-0 flex items-center justify-center opacity-90 relative z-10">
                <Barcode className="w-12 h-12 text-white/80" />
              </div>

              {/* Decorative background blur circle */}
              <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-white/10 rounded-full blur-xl pointer-events-none" />
            </div>

            {/* 2. Quick Action Tiles (6 cols) */}
            <div className="md:col-span-6 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => onNavigate('products')}
                className="p-2.5 bg-white rounded-xl border border-slate-200/80 hover:border-blue-400 hover:shadow-2xs transition-all text-right flex items-center gap-2 cursor-pointer group"
              >
                <div className="w-7.5 h-7.5 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                  <PackagePlus className="w-3.5 h-3.5" />
                </div>
                <div>
                  <div className="font-bold text-[11px] text-slate-800">کالای جدید</div>
                  <div className="text-[9px] text-slate-400">ثبت در انبار</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => onNavigate('inventory')}
                className="p-2.5 bg-white rounded-xl border border-slate-200/80 hover:border-blue-400 hover:shadow-2xs transition-all text-right flex items-center gap-2 cursor-pointer group"
              >
                <div className="w-7.5 h-7.5 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                  <ArrowDownToLine className="w-3.5 h-3.5" />
                </div>
                <div>
                  <div className="font-bold text-[11px] text-slate-800">ورود کالا</div>
                  <div className="text-[9px] text-slate-400">فاکتور خرید</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => onNavigate('inventory')}
                className="p-2.5 bg-white rounded-xl border border-slate-200/80 hover:border-blue-400 hover:shadow-2xs transition-all text-right flex items-center gap-2 cursor-pointer group"
              >
                <div className="w-7.5 h-7.5 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shrink-0 group-hover:bg-amber-600 group-hover:text-white transition-colors">
                  <Boxes className="w-3.5 h-3.5" />
                </div>
                <div>
                  <div className="font-bold text-[11px] text-slate-800">موجودی انبار</div>
                  <div className="text-[9px] text-slate-400">کنترل کاردکس</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => onNavigate('reports')}
                className="p-2.5 bg-white rounded-xl border border-slate-200/80 hover:border-blue-400 hover:shadow-2xs transition-all text-right flex items-center gap-2 cursor-pointer group"
              >
                <div className="w-7.5 h-7.5 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center shrink-0 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                  <TrendingUp className="w-3.5 h-3.5" />
                </div>
                <div>
                  <div className="font-bold text-[11px] text-slate-800">گزارش فروش</div>
                  <div className="text-[9px] text-slate-400">سود و آمار</div>
                </div>
              </button>
            </div>
          </div>

          {/* Recent Sales & Alerts row */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            {/* Recent Sales mini table (8 cols) */}
            <div className="md:col-span-7 bg-white rounded-2xl p-4 border border-slate-200/80 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Receipt className="w-3.5 h-3.5 text-blue-600" />
                  <span>فروش‌های اخیر</span>
                </span>
                <button
                  type="button"
                  onClick={() => onNavigate('reports')}
                  className="text-[11px] text-blue-600 hover:underline cursor-pointer font-bold"
                >
                  مشاهده همه
                </button>
              </div>

              <div className="space-y-2">
                {(recentSales || []).slice(0, 4).map((sale) => (
                  <div
                    key={sale.id}
                    onClick={() => {
                      setSelectedHistoricalSale(sale);
                    }}
                    className="flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 transition-all cursor-pointer text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[11px] font-bold text-slate-400">
                        #{toPersianDigits(sale.invoiceNumber)}
                      </span>
                      <span className="font-medium text-slate-700 truncate max-w-[140px]">
                        {sale.items[0]?.productName || 'اقلام متفرقه'}
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-[10px] text-slate-400 font-mono">{toPersianDigits(sale.time)}</span>
                      <span className="font-sans font-bold text-slate-900">{formatToman(sale.finalTotal)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Warnings list (5 cols) */}
            <div className="md:col-span-5 bg-white rounded-2xl p-4 border border-slate-200/80 space-y-3">
              <div className="pb-2 border-b border-slate-100 text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                <span>هشدارها و اطلاعیه‌ها</span>
              </div>

              <div className="space-y-2">
                <div
                  onClick={() => onNavigate('inventory')}
                  className="p-2.5 rounded-xl bg-rose-50 border border-rose-100 hover:bg-rose-100/70 transition-all cursor-pointer flex items-center justify-between text-xs text-rose-900"
                >
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                    <div>
                      <div className="font-bold">{toPersianDigits(lowStockCount)} کالا رو به اتمام</div>
                      <div className="text-[10px] text-rose-700">موجودی کمتر از حد مجاز</div>
                    </div>
                  </div>
                </div>

                <div
                  onClick={() => onNavigate('inventory')}
                  className="p-2.5 rounded-xl bg-amber-50 border border-amber-100 hover:bg-amber-100/70 transition-all cursor-pointer flex items-center justify-between text-xs text-amber-900"
                >
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-600 shrink-0" />
                    <div>
                      <div className="font-bold">{toPersianDigits(nearExpiryCount)} کالا نزدیک انقضا</div>
                      <div className="text-[10px] text-amber-700">تا ۷ روز آینده</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Area (5 cols on desktop): Live Shopping Cart (Matching reference image) */}
        <div className="lg:col-span-5 xl:col-span-4 sticky top-6">
          <div className="bg-white rounded-xl border border-slate-200/80 shadow-2xs p-3 flex flex-col min-h-[460px] justify-between">
            {/* Cart Header */}
            <div>
              <div className="flex items-center justify-between pb-2.5 border-b border-slate-100">
                <div className="flex items-center gap-1.5">
                  <h3 className="font-black text-xs text-slate-900">سبد خرید</h3>
                  {totalItemCount > 0 && (
                    <span className="w-4.5 h-4.5 rounded-full bg-blue-600 text-white font-mono text-[10px] flex items-center justify-center font-bold">
                      {toPersianDigits(totalItemCount)}
                    </span>
                  )}
                </div>

                {cart.length > 0 && (
                  <button
                    type="button"
                    onClick={clearCart}
                    className="text-[11px] text-rose-600 hover:text-rose-700 font-medium cursor-pointer flex items-center gap-1"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>پاک کردن</span>
                  </button>
                )}
              </div>

              {/* Cart Items List */}
              <div className="py-2 space-y-2 max-h-[300px] overflow-y-auto scrollbar-thin">
                {cart.map((item) => (
                  <div
                    key={item.product.id}
                    className="p-2 rounded-lg bg-slate-50/70 border border-slate-100 flex items-center justify-between gap-1.5"
                  >
                    {/* Image & Title */}
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-8 h-8 rounded-md bg-white p-0.5 border border-slate-200 shrink-0 flex items-center justify-center">
                        <img
                          src={item.product.imageUrl}
                          alt={item.product.name}
                          className="max-h-full max-w-full object-contain"
                        />
                      </div>
                      <div className="min-w-0">
                        <h5 className="font-bold text-[11px] text-slate-800 truncate">
                          {item.product.name}
                        </h5>
                        <div className="text-[9px] text-slate-500 font-sans">
                          {toPersianDigits(item.quantity)} × {formatToman(item.unitPrice)}
                        </div>
                      </div>
                    </div>

                    {/* Quantity Controls & Trash */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      <div className="flex items-center gap-0.5 bg-white border border-slate-200 rounded-md p-0.5 shadow-2xs">
                        <button
                          type="button"
                          onClick={() => updateQuantity(item.product.id, -1)}
                          className="w-5 h-5 rounded flex items-center justify-center text-slate-600 hover:bg-slate-100 cursor-pointer active:scale-95"
                        >
                          <Minus className="w-2.5 h-2.5" />
                        </button>
                        <span className="w-5 text-center font-mono font-bold text-[11px] text-slate-800">
                          {toPersianDigits(item.quantity)}
                        </span>
                        <button
                          type="button"
                          onClick={() => updateQuantity(item.product.id, 1)}
                          className="w-5 h-5 rounded flex items-center justify-center text-slate-600 hover:bg-slate-100 cursor-pointer active:scale-95"
                        >
                          <Plus className="w-2.5 h-2.5" />
                        </button>
                      </div>

                      <button
                        type="button"
                        onClick={() => removeFromCart(item.product.id)}
                        className="text-slate-400 hover:text-rose-600 p-0.5 cursor-pointer transition-colors"
                        title="حذف قلم"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}

                {cart.length === 0 && (
                  <div className="text-center py-10 space-y-2">
                    <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-500 flex items-center justify-center mx-auto">
                      <Receipt className="w-5 h-5" />
                    </div>
                    <div className="space-y-0.5">
                      <p className="text-xs font-bold text-slate-700">سبد خرید خالی است</p>
                      <p className="text-[10px] text-slate-400 max-w-[190px] mx-auto">
                        کالایی را از لیست انتخاب کرده یا بارکد آن را اسکن کنید.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Cart Summary & Checkout Action */}
            <div className="pt-2.5 border-t border-slate-100 space-y-2">
              <div className="space-y-1 text-xs text-slate-600">
                <div className="flex justify-between">
                  <span>جمع کل:</span>
                  <span className="font-sans font-bold text-slate-800">{formatToman(subtotal)}</span>
                </div>
                {totalDiscount > 0 && (
                  <div className="flex justify-between text-emerald-600">
                    <span>تخفیف:</span>
                    <span className="font-sans font-bold">- {formatToman(totalDiscount)}</span>
                  </div>
                )}
                {tax > 0 && (
                  <div className="flex justify-between">
                    <span>مالیات ({toPersianDigits(store.taxRate)}٪):</span>
                    <span className="font-sans font-bold">+ {formatToman(tax)}</span>
                  </div>
                )}
                <div className="flex justify-between items-center pt-1.5 border-t border-slate-100">
                  <span className="font-bold text-xs text-slate-900">مبلغ قابل پرداخت:</span>
                  <span className="font-black text-base text-blue-600 font-sans tracking-tight">
                    {formatToman(finalTotal)}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  disabled={cart.length === 0}
                  onClick={handleGenerateProforma}
                  className="py-2.5 px-2 rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition-all border border-blue-200 bg-blue-50/70 hover:bg-blue-100 text-blue-700 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed active:scale-[0.99]"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>پیش‌فاکتور چاپی</span>
                </button>

                <button
                  type="button"
                  disabled={cart.length === 0}
                  onClick={() => setIsCheckoutOpen(true)}
                  className={`py-2.5 px-2 rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-2xs ${
                    cart.length > 0
                      ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/20 active:scale-[0.99]'
                      : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <Receipt className="w-3.5 h-3.5" />
                  <span>تسویه حساب</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Floating Cart Summary Bar (Quick App Checkout) */}
      {cart.length > 0 && (
        <div className="fixed bottom-14 left-3 right-3 z-30 lg:hidden">
          <div className="bg-slate-900/95 backdrop-blur-md text-white rounded-xl p-2.5 shadow-xl border border-slate-700/60 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7.5 h-7.5 rounded-lg bg-blue-600 flex items-center justify-center font-mono font-bold text-xs text-white">
                {toPersianDigits(totalItemCount)}
              </div>
              <div>
                <div className="text-[10px] text-slate-300">مبلغ قابل پرداخت</div>
                <div className="text-xs font-black font-sans">{formatToman(finalTotal)}</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleGenerateProforma}
                className="bg-slate-800 hover:bg-slate-700 text-blue-300 font-bold text-xs px-2.5 py-1.5 rounded-lg flex items-center gap-1 border border-slate-700 active:scale-95 transition-all cursor-pointer"
              >
                <FileText className="w-3 h-3" />
                <span>پیش‌فاکتور</span>
              </button>
              <button
                type="button"
                onClick={() => setIsCheckoutOpen(true)}
                className="bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-3 py-1.5 rounded-lg flex items-center gap-1.5 shadow-sm active:scale-95 transition-all cursor-pointer"
              >
                <Receipt className="w-3.5 h-3.5" />
                <span>تسویه سریع</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cartItems={cart}
        customers={customers}
        store={store}
        onSuccess={handleCheckoutSuccess}
      />

      {/* Receipt Modal */}
      <ReceiptModal
        isOpen={isReceiptOpen}
        onClose={() => setIsReceiptOpen(false)}
        sale={lastCompletedSale}
        store={store}
        onNewSale={() => {
          setCart([]);
          setIsReceiptOpen(false);
        }}
      />

      {/* Barcode Scanner Modal */}
      <BarcodeScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        products={products}
        onProductScanned={(product) => {
          addToCart(product);
        }}
      />

      {/* Historical Transaction Detail, Void & Print Modal */}
      {selectedHistoricalSale && (
        <TransactionDetailModal
          isOpen={!!selectedHistoricalSale}
          onClose={() => setSelectedHistoricalSale(null)}
          sale={selectedHistoricalSale}
          store={store}
          onSaleUpdated={loadData}
        />
      )}

      {/* Printable Proforma Modal */}
      <ProformaModal
        isOpen={isProformaOpen}
        onClose={() => setIsProformaOpen(false)}
        proforma={currentProforma}
        store={store}
        onConvertToSale={handleConvertProformaToSale}
      />
    </div>
  );
};
