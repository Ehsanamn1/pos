import React, { useState, useMemo } from 'react';
import { Product, Category, Supplier } from '../types';
import { StorageService } from '../services/storage';
import { formatToman, toPersianDigits } from '../design-system/tokens';
import { Modal } from '../design-system/components/Modal';
import { Button } from '../design-system/components/Button';
import { Input } from '../design-system/components/Input';
import { Badge } from '../design-system/components/Badge';
import {
  Plus,
  Search,
  Barcode,
  Edit2,
  Trash2,
  Package,
  TrendingUp,
  AlertTriangle,
  Clock,
  Sparkles,
  DollarSign,
  CheckCircle2,
  Image as ImageIcon,
} from 'lucide-react';

export const ProductsView: React.FC = () => {
  const [products, setProducts] = useState<Product[]>(() => StorageService.getProducts());
  const [categories] = useState<Category[]>(() => StorageService.getCategories());
  const [suppliers] = useState<Supplier[]>(() => StorageService.getSuppliers());

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'in_stock' | 'low_stock' | 'out_of_stock' | 'near_expiry'>('all');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Modals
  const [isAddEditOpen, setIsAddEditOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [isBulkPriceOpen, setIsBulkPriceOpen] = useState(false);

  // Form State for Add/Edit
  const [formState, setFormState] = useState<Partial<Product>>({
    name: '',
    barcode: '',
    sku: '',
    categoryId: 'drinks',
    categoryName: 'نوشیدنی‌ها',
    brand: '',
    purchasePrice: 0,
    retailPrice: 0,
    wholesalePrice: 0,
    minStock: 5,
    currentStock: 10,
    unit: 'عدد',
    entryDate: '۱۴۰۳/۰۶/۲۵',
    expiryDate: '۱۴۰۴/۰۶/۲۵',
    supplierId: 'sup-1',
    supplierName: 'شرکت پخش زمزم و خوشگوار',
    imageUrl: 'https://images.unsplash.com/photo-1548839140-29a749e1bc4e?w=300&auto=format&fit=crop&q=80',
  });

  // Bulk price form
  const [bulkConfig, setBulkConfig] = useState<{
    categoryFilter: string;
    type: 'percentage' | 'fixed';
    amount: number;
    priceType: 'retail' | 'purchase' | 'wholesale';
    isIncrease: boolean;
  }>({
    categoryFilter: 'all',
    type: 'percentage',
    amount: 10,
    priceType: 'retail',
    isIncrease: true,
  });

  const reloadProducts = () => {
    setProducts(StorageService.getProducts());
  };

  // Filtered list
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // status filter
      let matchStatus = true;
      if (statusFilter === 'in_stock') matchStatus = p.currentStock > p.minStock;
      if (statusFilter === 'low_stock') matchStatus = p.currentStock > 0 && p.currentStock <= p.minStock;
      if (statusFilter === 'out_of_stock') matchStatus = p.currentStock === 0;
      if (statusFilter === 'near_expiry') matchStatus = p.expiryDate && p.expiryDate.startsWith('۱۴۰۳/۰۶/');

      // query filter
      const query = searchQuery.trim().toLowerCase();
      const matchQuery =
        !query ||
        p.name.toLowerCase().includes(query) ||
        p.barcode.includes(query) ||
        p.sku.toLowerCase().includes(query) ||
        p.brand.toLowerCase().includes(query);

      return matchStatus && matchQuery;
    });
  }, [products, statusFilter, searchQuery]);

  const openCreateModal = () => {
    setEditingProduct(null);
    setFormState({
      name: '',
      barcode: `626${Math.floor(1000000000 + Math.random() * 9000000000)}`,
      sku: `PR-${Math.floor(1000 + Math.random() * 9000)}`,
      categoryId: categories[1]?.id || 'drinks',
      categoryName: categories[1]?.name || 'نوشیدنی‌ها',
      brand: '',
      purchasePrice: 0,
      retailPrice: 0,
      wholesalePrice: 0,
      minStock: 5,
      currentStock: 12,
      unit: 'عدد',
      entryDate: '۱۴۰۳/۰۶/۲۵',
      expiryDate: '۱۴۰۴/۰۶/۲۵',
      supplierId: suppliers[0]?.id || 'sup-1',
      supplierName: suppliers[0]?.name || 'پخش آریا',
      imageUrl: 'https://images.unsplash.com/photo-1548839140-29a749e1bc4e?w=300&auto=format&fit=crop&q=80',
    });
    setIsAddEditOpen(true);
  };

  const openEditModal = (product: Product) => {
    setEditingProduct(product);
    setFormState({ ...product });
    setIsAddEditOpen(true);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formState.name || !formState.barcode) return;

    if (editingProduct) {
      StorageService.updateProduct({
        ...editingProduct,
        ...(formState as Product),
      });
    } else {
      StorageService.addProduct(formState as Omit<Product, 'id'>);
    }

    setIsAddEditOpen(false);
    reloadProducts();
  };

  const handleDeleteProduct = () => {
    if (selectedProduct) {
      StorageService.deleteProduct(selectedProduct.id);
      setIsDeleteConfirmOpen(false);
      setSelectedProduct(null);
      reloadProducts();
    }
  };

  const handleApplyBulkPrice = () => {
    StorageService.bulkUpdatePrices(bulkConfig);
    setIsBulkPriceOpen(false);
    reloadProducts();
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Top Action Bar */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Package className="w-6 h-6 text-blue-600" />
            <span>مدیریت کالاها و انبارک</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            تعریف، ویرایش، قیمت‌گذاری و مدیریت بارکد {toPersianDigits(products.length)} قلم کالا
          </p>
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto">
          <Button
            variant="outline"
            onClick={() => setIsBulkPriceOpen(true)}
            icon={<TrendingUp className="w-4 h-4 text-blue-600" />}
          >
            تغییر گروهی قیمت‌ها
          </Button>
          <Button
            variant="primary"
            onClick={openCreateModal}
            icon={<Plus className="w-4 h-4" />}
          >
            افزودن کالای جدید
          </Button>
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="جستجو بر اساس نام، بارکد، برند یا SKU کالا..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white focus:outline-none focus:border-blue-600"
            />
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
            <Barcode className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            {[
              { id: 'all', label: 'همه کالاها' },
              { id: 'in_stock', label: 'موجود در انبار' },
              { id: 'low_stock', label: 'کم‌موجودی' },
              { id: 'out_of_stock', label: 'ناموجود' },
              { id: 'near_expiry', label: 'نزدیک انقضا' },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setStatusFilter(tab.id as any)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  statusFilter === tab.id
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Products Grid & Detail Drawer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Products Table/Cards (8 cols if item selected, 12 cols otherwise) */}
        <div className={selectedProduct ? 'lg:col-span-8' : 'lg:col-span-12'}>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3.5">
            {filteredProducts.map((product) => {
              const isSelected = selectedProduct?.id === product.id;
              const isLow = product.currentStock <= product.minStock && product.currentStock > 0;
              const isOut = product.currentStock === 0;

              return (
                <div
                  key={product.id}
                  onClick={() => setSelectedProduct(product)}
                  className={`bg-white rounded-2xl border p-4 transition-all duration-200 cursor-pointer flex flex-col justify-between hover:shadow-md ${
                    isSelected
                      ? 'border-blue-600 ring-2 ring-blue-500/20 shadow-sm'
                      : 'border-slate-200/80 hover:border-slate-300'
                  }`}
                >
                  <div className="flex gap-3 items-start">
                    {/* Thumbnail */}
                    <div className="w-16 h-16 rounded-xl bg-slate-50 border border-slate-100 p-1.5 flex items-center justify-center shrink-0">
                      <img
                        src={product.imageUrl}
                        alt={product.name}
                        className="max-h-full max-w-full object-contain mix-blend-multiply"
                      />
                    </div>

                    {/* Details */}
                    <div className="min-w-0 flex-1 space-y-1">
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-[10px] text-blue-600 font-bold bg-blue-50 px-2 py-0.5 rounded-md">
                          {product.categoryName}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {product.sku}
                        </span>
                      </div>
                      <h4 className="font-bold text-xs text-slate-800 truncate">
                        {product.name}
                      </h4>
                      <div className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                        <Barcode className="w-3 h-3 text-slate-400" />
                        <span>{product.barcode}</span>
                      </div>
                    </div>
                  </div>

                  {/* Pricing & Stock Footer */}
                  <div className="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between">
                    <div>
                      <div className="text-[10px] text-slate-400">قیمت فروش:</div>
                      <div className="font-sans font-black text-xs text-slate-900">
                        {formatToman(product.retailPrice)}
                      </div>
                    </div>

                    <div className="text-left">
                      {isOut ? (
                        <Badge variant="danger" dot size="sm">ناموجود</Badge>
                      ) : isLow ? (
                        <Badge variant="warning" dot size="sm">
                          کم‌موجودی ({toPersianDigits(product.currentStock)})
                        </Badge>
                      ) : (
                        <Badge variant="success" dot size="sm">
                          موجود ({toPersianDigits(product.currentStock)})
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredProducts.length === 0 && (
            <div className="bg-white rounded-2xl p-12 text-center border border-dashed border-slate-300 text-slate-400 space-y-2">
              <Package className="w-8 h-8 mx-auto text-slate-300" />
              <p className="text-xs font-bold text-slate-600">کالایی با فیلتر انتخابی پیدا نشد!</p>
            </div>
          )}
        </div>

        {/* Selected Product Detail Panel (Matching Reference Image) */}
        {selectedProduct && (
          <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs sticky top-6 space-y-5 animate-in fade-in duration-200">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-black text-sm text-slate-900">مشخصات کالا</h3>
              <button
                type="button"
                onClick={() => setSelectedProduct(null)}
                className="text-xs text-slate-400 hover:text-slate-700 cursor-pointer font-bold"
              >
                بستن ×
              </button>
            </div>

            {/* Photo & Main Title */}
            <div className="text-center space-y-2">
              <div className="w-32 h-32 mx-auto rounded-2xl bg-slate-50 border border-slate-200 p-3 flex items-center justify-center">
                <img
                  src={selectedProduct.imageUrl}
                  alt={selectedProduct.name}
                  className="max-h-full max-w-full object-contain mix-blend-multiply"
                />
              </div>
              <h4 className="font-black text-base text-slate-900">{selectedProduct.name}</h4>
              <div className="text-xs text-slate-500 font-mono flex items-center justify-center gap-1">
                <span>بارکد:</span>
                <strong>{selectedProduct.barcode}</strong>
              </div>
            </div>

            {/* Pricing Comparison */}
            <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs">
              <div>
                <div className="text-slate-400 text-[10px]">قیمت خرید:</div>
                <div className="font-sans font-bold text-slate-700 mt-0.5">
                  {formatToman(selectedProduct.purchasePrice)}
                </div>
              </div>
              <div>
                <div className="text-slate-400 text-[10px]">قیمت فروش:</div>
                <div className="font-sans font-bold text-blue-600 mt-0.5">
                  {formatToman(selectedProduct.retailPrice)}
                </div>
              </div>
              <div>
                <div className="text-slate-400 text-[10px]">موجودی فعلی:</div>
                <div className="font-bold text-slate-800 mt-0.5">
                  {toPersianDigits(selectedProduct.currentStock)} {selectedProduct.unit}
                </div>
              </div>
              <div>
                <div className="text-slate-400 text-[10px]">نقطه سفارش مجدد:</div>
                <div className="font-bold text-slate-800 mt-0.5">
                  {toPersianDigits(selectedProduct.minStock)} {selectedProduct.unit}
                </div>
              </div>
            </div>

            {/* Additional info */}
            <div className="space-y-2 text-xs text-slate-600 divide-y divide-slate-100">
              <div className="flex justify-between pt-1">
                <span className="text-slate-400">دسته‌بندی:</span>
                <span className="font-bold text-slate-800">{selectedProduct.categoryName}</span>
              </div>
              <div className="flex justify-between pt-2">
                <span className="text-slate-400">برند تجاری:</span>
                <span className="font-bold text-slate-800">{selectedProduct.brand || '---'}</span>
              </div>
              <div className="flex justify-between pt-2">
                <span className="text-slate-400">تأمین‌کننده:</span>
                <span className="font-bold text-slate-800">{selectedProduct.supplierName}</span>
              </div>
              <div className="flex justify-between pt-2">
                <span className="text-slate-400">تاریخ انقضا:</span>
                <span className="font-bold font-mono text-slate-800">{selectedProduct.expiryDate}</span>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex items-center gap-2 pt-3 border-t border-slate-100">
              <Button
                variant="primary"
                className="flex-1"
                icon={<Edit2 className="w-4 h-4" />}
                onClick={() => openEditModal(selectedProduct)}
              >
                ویرایش مشخصات
              </Button>
              <Button
                variant="danger"
                icon={<Trash2 className="w-4 h-4" />}
                onClick={() => setIsDeleteConfirmOpen(true)}
              >
                حذف
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Add / Edit Product Modal */}
      <Modal
        isOpen={isAddEditOpen}
        onClose={() => setIsAddEditOpen(false)}
        title={editingProduct ? 'ویرایش مشخصات کالا' : 'افزودن کالای جدید به انبار'}
        size="lg"
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsAddEditOpen(false)}>
              انصراف
            </Button>
            <Button variant="primary" onClick={handleSaveProduct} icon={<CheckCircle2 className="w-4 h-4" />}>
              ذخیره مشخصات کالا
            </Button>
          </>
        }
      >
        <form onSubmit={handleSaveProduct} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="نام رسمی کالا *"
              placeholder="مثال: نوشابه کوکاکولا قوطی ۳۳۰ml"
              value={formState.name}
              onChange={(e) => setFormState({ ...formState, name: e.target.value })}
              required
            />

            <Input
              label="بارکد بین‌المللی کالا (EAN-13) *"
              placeholder="مثال: ۶۲۶۱۲۳۴۵۶۷۸۹۰"
              value={formState.barcode}
              onChange={(e) => setFormState({ ...formState, barcode: e.target.value })}
              startIcon={<Barcode className="w-4 h-4 text-slate-400" />}
              required
            />

            <Input
              label="شناسه انبار / SKU"
              placeholder="مثال: BV-COCA-330"
              value={formState.sku}
              onChange={(e) => setFormState({ ...formState, sku: e.target.value })}
            />

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700">دسته‌بندی کالا:</label>
              <select
                value={formState.categoryId}
                onChange={(e) => {
                  const cat = categories.find((c) => c.id === e.target.value);
                  setFormState({
                    ...formState,
                    categoryId: e.target.value,
                    categoryName: cat?.name || '',
                  });
                }}
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-600"
              >
                {categories.filter((c) => c.id !== 'all').map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>

            <Input
              label="برند کالا"
              placeholder="مثال: کوکاکولا، کاله، چیتوز..."
              value={formState.brand}
              onChange={(e) => setFormState({ ...formState, brand: e.target.value })}
            />

            <Input
              label="واحد شمارش"
              placeholder="عدد، بسته، کیلوگرم، قوطی..."
              value={formState.unit}
              onChange={(e) => setFormState({ ...formState, unit: e.target.value })}
            />

            <Input
              label="قیمت خرید (تومان) *"
              type="number"
              value={formState.purchasePrice || ''}
              onChange={(e) => setFormState({ ...formState, purchasePrice: parseInt(e.target.value, 10) || 0 })}
            />

            <Input
              label="قیمت فروش تک‌فروشی (تومان) *"
              type="number"
              value={formState.retailPrice || ''}
              onChange={(e) => setFormState({ ...formState, retailPrice: parseInt(e.target.value, 10) || 0 })}
            />

            <Input
              label="موجودی فعلی در انبار"
              type="number"
              value={formState.currentStock ?? ''}
              onChange={(e) => setFormState({ ...formState, currentStock: parseInt(e.target.value, 10) || 0 })}
            />

            <Input
              label="حداقل موجودی (نقطه هشدار)"
              type="number"
              value={formState.minStock ?? ''}
              onChange={(e) => setFormState({ ...formState, minStock: parseInt(e.target.value, 10) || 0 })}
            />

            <Input
              label="تاریخ انقضا (شمسی)"
              placeholder="۱۴۰۴/۰۶/۲۵"
              value={formState.expiryDate}
              onChange={(e) => setFormState({ ...formState, expiryDate: e.target.value })}
            />

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700">تأمین‌کننده اصلی:</label>
              <select
                value={formState.supplierId}
                onChange={(e) => {
                  const sup = suppliers.find((s) => s.id === e.target.value);
                  setFormState({
                    ...formState,
                    supplierId: e.target.value,
                    supplierName: sup?.name || '',
                  });
                }}
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-600"
              >
                {suppliers.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <Input
            label="آدرس تصویر کالا (URL)"
            value={formState.imageUrl}
            onChange={(e) => setFormState({ ...formState, imageUrl: e.target.value })}
            startIcon={<ImageIcon className="w-4 h-4 text-slate-400" />}
          />
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={isDeleteConfirmOpen}
        onClose={() => setIsDeleteConfirmOpen(false)}
        title="تأیید حذف کالا"
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsDeleteConfirmOpen(false)}>
              انصراف
            </Button>
            <Button variant="danger" onClick={handleDeleteProduct}>
              بله، کالا حذف شود
            </Button>
          </>
        }
      >
        <p className="text-xs text-slate-600 leading-relaxed">
          آیا از حذف کالای <strong>«{selectedProduct?.name}»</strong> مطمئن هستید؟ این عملیات سوابق فروش را حفظ کرده ولی کالا از کاتالوگ فروش و انبار خارج خواهد شد.
        </p>
      </Modal>

      {/* Bulk Price Change Modal */}
      <Modal
        isOpen={isBulkPriceOpen}
        onClose={() => setIsBulkPriceOpen(false)}
        title="تغییر گروهی قیمت کالاها (Bulk Pricing)"
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsBulkPriceOpen(false)}>
              انصراف
            </Button>
            <Button variant="primary" onClick={handleApplyBulkPrice} icon={<Sparkles className="w-4 h-4" />}>
              اعمال تغییر قیمت
            </Button>
          </>
        }
      >
        <div className="space-y-4 text-xs">
          <p className="text-slate-600">
            با استفاده از این بخش می‌توانید قیمت فروش یا خرید کالاها را به‌صورت درصدی یا مبلغ ثابت افزایش یا کاهش دهید.
          </p>

          <div className="space-y-1.5">
            <label className="font-bold text-slate-700">فیلتر بر اساس دسته‌بندی:</label>
            <select
              value={bulkConfig.categoryFilter}
              onChange={(e) => setBulkConfig({ ...bulkConfig, categoryFilter: e.target.value })}
              className="w-full rounded-xl border border-slate-200 bg-white p-2.5 text-xs text-slate-800"
            >
              <option value="all">همه کالاها (کل فروشگاه)</option>
              {categories.filter((c) => c.id !== 'all').map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700">نوع قیمت:</label>
              <select
                value={bulkConfig.priceType}
                onChange={(e) => setBulkConfig({ ...bulkConfig, priceType: e.target.value as any })}
                className="w-full rounded-xl border border-slate-200 bg-white p-2.5 text-xs text-slate-800"
              >
                <option value="retail">قیمت تک‌فروشی</option>
                <option value="wholesale">قیمت عمده</option>
                <option value="purchase">قیمت خرید</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-slate-700">جهت تغییر:</label>
              <select
                value={bulkConfig.isIncrease ? 'increase' : 'decrease'}
                onChange={(e) => setBulkConfig({ ...bulkConfig, isIncrease: e.target.value === 'increase' })}
                className="w-full rounded-xl border border-slate-200 bg-white p-2.5 text-xs text-slate-800"
              >
                <option value="increase">افزایش قیمت (+)</option>
                <option value="decrease">کاهش قیمت (-)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700">نحوه محاسبه:</label>
              <select
                value={bulkConfig.type}
                onChange={(e) => setBulkConfig({ ...bulkConfig, type: e.target.value as any })}
                className="w-full rounded-xl border border-slate-200 bg-white p-2.5 text-xs text-slate-800"
              >
                <option value="percentage">درصدی (٪)</option>
                <option value="fixed">مبلغ ثابت (تومان)</option>
              </select>
            </div>

            <Input
              label={bulkConfig.type === 'percentage' ? 'درصد تغییر (٪)' : 'مبلغ تغییر (تومان)'}
              type="number"
              value={bulkConfig.amount}
              onChange={(e) => setBulkConfig({ ...bulkConfig, amount: parseInt(e.target.value, 10) || 0 })}
            />
          </div>
        </div>
      </Modal>
    </div>
  );
};
