import React, { useState } from 'react';
import { Supplier, Product, Purchase } from '../types';
import { StorageService } from '../services/storage';
import { formatToman, toPersianDigits } from '../design-system/tokens';
import { Modal } from '../design-system/components/Modal';
import { Button } from '../design-system/components/Button';
import { Input } from '../design-system/components/Input';
import {
  Truck,
  Plus,
  ArrowDownToLine,
  Phone,
  Building2,
  CheckCircle2,
  Receipt,
  Search,
} from 'lucide-react';

export const PurchasingView: React.FC = () => {
  const [suppliers, setSuppliers] = useState<Supplier[]>(() => StorageService.getSuppliers());
  const [purchases, setPurchases] = useState<Purchase[]>(() => StorageService.getPurchases());
  const [products] = useState<Product[]>(() => StorageService.getProducts());

  const [isAddSupplierOpen, setIsAddSupplierOpen] = useState(false);
  const [isAddPurchaseOpen, setIsAddPurchaseOpen] = useState(false);

  // Supplier Form
  const [supForm, setSupForm] = useState({
    name: '',
    phone: '',
    contactInfo: '',
    city: 'تهران',
    notes: '',
  });

  // Purchase Form
  const [selectedSupplierId, setSelectedSupplierId] = useState<string>(suppliers[0]?.id || '');
  const [purchaseItems, setPurchaseItems] = useState<{ productId: string; quantity: number; unitCost: number }[]>([
    { productId: products[0]?.id || '', quantity: 20, unitCost: products[0]?.purchasePrice || 35000 },
  ]);

  const reloadData = () => {
    setSuppliers(StorageService.getSuppliers());
    setPurchases(StorageService.getPurchases());
  };

  const handleCreateSupplier = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supForm.name) return;
    StorageService.addSupplier(supForm);
    setIsAddSupplierOpen(false);
    setSupForm({ name: '', phone: '', contactInfo: '', city: 'تهران', notes: '' });
    reloadData();
  };

  const handleCreatePurchase = () => {
    const sup = suppliers.find((s) => s.id === selectedSupplierId);
    if (!sup) return;

    const items = purchaseItems.map((pi) => {
      const prod = products.find((p) => p.id === pi.productId);
      return {
        productId: pi.productId,
        productName: prod?.name || 'کالا',
        quantity: pi.quantity,
        unitCost: pi.unitCost,
        total: pi.quantity * pi.unitCost,
      };
    });

    const totalCost = items.reduce((sum, item) => sum + item.total, 0);

    StorageService.addPurchase({
      supplierId: sup.id,
      supplierName: sup.name,
      date: '۱۴۰۳/۰۶/۲۵',
      items,
      totalCost,
      status: 'تکمیل شده',
    });

    setIsAddPurchaseOpen(false);
    reloadData();
    alert('فاکتور خرید با موفقیت ثبت شد و موجودی کالاها در انبار افزایش یافت.');
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Top Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Truck className="w-6 h-6 text-blue-600" />
            <span>خرید و تأمین‌کنندگان</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            ثبت فاکتورهای ورود کالا، مدیریت شرکت‌های پخش و تسویه حساب با توزیع‌کنندگان
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <Button
            variant="outline"
            onClick={() => setIsAddSupplierOpen(true)}
            icon={<Building2 className="w-4 h-4 text-blue-600" />}
          >
            تأمین‌کننده جدید
          </Button>
          <Button
            variant="primary"
            onClick={() => setIsAddPurchaseOpen(true)}
            icon={<ArrowDownToLine className="w-4 h-4" />}
          >
            ثبت فاکتور خرید (ورود کالا)
          </Button>
        </div>
      </div>

      {/* Suppliers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {suppliers.map((sup) => (
          <div key={sup.id} className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-xs space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-sm">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-xs text-slate-900">{sup.name}</h4>
                  <div className="text-[11px] text-slate-400 font-mono mt-0.5">{toPersianDigits(sup.phone)}</div>
                </div>
              </div>
              <span className="text-[10px] text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                {sup.city}
              </span>
            </div>

            <div className="p-2.5 bg-slate-50 rounded-xl text-xs text-slate-600 space-y-1">
              <div className="flex justify-between">
                <span>مسئول سفارشات:</span>
                <span className="font-bold text-slate-800">{sup.contactInfo}</span>
              </div>
              <div className="flex justify-between">
                <span>مانده حساب / بدهی ما:</span>
                <span className="font-bold text-slate-800">{formatToman(sup.balance)}</span>
              </div>
              <div className="flex justify-between">
                <span>مجموع خریدهای قبلی:</span>
                <span className="font-bold text-slate-800">{formatToman(sup.totalPurchases)}</span>
              </div>
            </div>

            {sup.notes && (
              <p className="text-[11px] text-slate-500">{sup.notes}</p>
            )}
          </div>
        ))}
      </div>

      {/* Add Supplier Modal */}
      <Modal
        isOpen={isAddSupplierOpen}
        onClose={() => setIsAddSupplierOpen(false)}
        title="تعریف شرکت تأمین‌کننده جدید"
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsAddSupplierOpen(false)}>
              انصراف
            </Button>
            <Button variant="primary" onClick={handleCreateSupplier} icon={<CheckCircle2 className="w-4 h-4" />}>
              ثبت شرکت پخش
            </Button>
          </>
        }
      >
        <form onSubmit={handleCreateSupplier} className="space-y-4">
          <Input
            label="نام شرکت پخش / تأمین‌کننده *"
            placeholder="مثال: شرکت لبنیات کاله و پگاه"
            value={supForm.name}
            onChange={(e) => setSupForm({ ...supForm, name: e.target.value })}
            required
          />
          <Input
            label="شماره تلفن واحد سفارشات *"
            placeholder="۰۲۱-۸۸۹۹۰۰۱۱"
            value={supForm.phone}
            onChange={(e) => setSupForm({ ...supForm, phone: e.target.value })}
            required
          />
          <Input
            label="نماینده فروش / مسئول سفارشات"
            placeholder="نام ویزیتور یا کارشناس فروش..."
            value={supForm.contactInfo}
            onChange={(e) => setSupForm({ ...supForm, contactInfo: e.target.value })}
          />
          <Input
            label="توضیحات و روزهای توزیع"
            placeholder="توزیع یکشنبه‌ها و چهارشنبه‌ها..."
            value={supForm.notes}
            onChange={(e) => setSupForm({ ...supForm, notes: e.target.value })}
          />
        </form>
      </Modal>

      {/* Add Purchase Order Modal */}
      <Modal
        isOpen={isAddPurchaseOpen}
        onClose={() => setIsAddPurchaseOpen(false)}
        title="ثبت فاکتور خرید جدید (ورود کالا به انبار)"
        size="lg"
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsAddPurchaseOpen(false)}>
              انصراف
            </Button>
            <Button variant="primary" onClick={handleCreatePurchase} icon={<CheckCircle2 className="w-4 h-4" />}>
              تأیید فاکتور و افزایش موجودی انبار
            </Button>
          </>
        }
      >
        <div className="space-y-4 text-xs">
          <div className="space-y-1.5">
            <label className="font-bold text-slate-700">انتخاب شرکت پخش (تأمین‌کننده):</label>
            <select
              value={selectedSupplierId}
              onChange={(e) => setSelectedSupplierId(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-white p-2.5 text-xs text-slate-800"
            >
              {suppliers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.city})
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-3 pt-2">
            <div className="font-bold text-slate-800">اقلام خریداری شده:</div>
            {purchaseItems.map((item, idx) => (
              <div key={idx} className="grid grid-cols-12 gap-2 p-2.5 bg-slate-50 rounded-xl border border-slate-200 items-center">
                <div className="col-span-6">
                  <select
                    value={item.productId}
                    onChange={(e) => {
                      const prod = products.find((p) => p.id === e.target.value);
                      const updated = [...purchaseItems];
                      updated[idx] = {
                        ...updated[idx],
                        productId: e.target.value,
                        unitCost: prod?.purchasePrice || 0,
                      };
                      setPurchaseItems(updated);
                    }}
                    className="w-full rounded-lg border border-slate-200 bg-white p-2 text-xs"
                  >
                    {products.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="col-span-3">
                  <input
                    type="number"
                    placeholder="تعداد"
                    value={item.quantity}
                    onChange={(e) => {
                      const updated = [...purchaseItems];
                      updated[idx] = { ...updated[idx], quantity: parseInt(e.target.value, 10) || 0 };
                      setPurchaseItems(updated);
                    }}
                    className="w-full rounded-lg border border-slate-200 bg-white p-2 text-xs"
                  />
                </div>
                <div className="col-span-3">
                  <input
                    type="number"
                    placeholder="فی خرید (تومان)"
                    value={item.unitCost}
                    onChange={(e) => {
                      const updated = [...purchaseItems];
                      updated[idx] = { ...updated[idx], unitCost: parseInt(e.target.value, 10) || 0 };
                      setPurchaseItems(updated);
                    }}
                    className="w-full rounded-lg border border-slate-200 bg-white p-2 text-xs"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </Modal>
    </div>
  );
};
