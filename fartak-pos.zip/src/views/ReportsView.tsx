import React, { useState, useMemo } from 'react';
import { Sale, StoreInfo, ProformaInvoice } from '../types';
import { StorageService } from '../services/storage';
import { formatToman, toPersianDigits } from '../design-system/tokens';
import { ReceiptModal } from '../components/receipt/ReceiptModal';
import { TransactionDetailModal } from '../components/receipt/TransactionDetailModal';
import { ProformaModal } from '../components/receipt/ProformaModal';
import { ThreeDLinearChart } from '../components/reports/ThreeDLinearChart';
import { PrinterService } from '../services/printer';
import { scannerService } from '../services/barcodeScanner';
import {
  TrendingUp,
  Calendar,
  CreditCard,
  Banknote,
  Receipt,
  Download,
  Filter,
  BarChart3,
  Award,
  Search,
  FileText,
  RotateCcw,
  Printer,
  CheckCircle2,
  Clock,
  Trash2,
  Eye,
  Check,
  AlertTriangle,
} from 'lucide-react';

interface ReportsViewProps {
  store: StoreInfo;
}

export const ReportsView: React.FC<ReportsViewProps> = ({ store }) => {
  const [sales, setSales] = useState<Sale[]>(() => StorageService.getSales());
  const [proformas, setProformas] = useState<ProformaInvoice[]>(() => StorageService.getProformas());

  const [activeTab, setActiveTab] = useState<'sales' | 'proformas'>('sales');
  const [searchHistoryQuery, setSearchHistoryQuery] = useState('');
  const [methodFilter, setMethodFilter] = useState<'all' | 'کارتخوان' | 'نقدی'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'completed' | 'refunded'>('all');
  const [periodFilter, setPeriodFilter] = useState<'today' | 'week' | 'month'>('today');

  const [selectedSaleForReceipt, setSelectedSaleForReceipt] = useState<Sale | null>(null);
  const [selectedProforma, setSelectedProforma] = useState<ProformaInvoice | null>(null);

  // Reload data
  const refreshData = () => {
    setSales(StorageService.getSales());
    setProformas(StorageService.getProformas());
  };

  // Stats calculations
  const totalSalesAmount = useMemo(
    () => sales.filter((s) => s.status !== 'مرجوع شده').reduce((sum, s) => sum + s.finalTotal, 0),
    [sales]
  );
  const totalInvoicesCount = sales.length;

  const posPaymentsTotal = useMemo(
    () =>
      sales
        .filter((s) => s.paymentMethod === 'کارتخوان' && s.status !== 'مرجوع شده')
        .reduce((sum, s) => sum + s.finalTotal, 0),
    [sales]
  );

  const cashPaymentsTotal = useMemo(
    () =>
      sales
        .filter((s) => s.paymentMethod === 'نقدی' && s.status !== 'مرجوع شده')
        .reduce((sum, s) => sum + s.finalTotal, 0),
    [sales]
  );

  // Filtered Sales History
  const filteredSales = useMemo(() => {
    return sales.filter((sale) => {
      // Query match (invoice number, customer, cashier, item name)
      const q = searchHistoryQuery.trim().toLowerCase();
      const matchQuery =
        !q ||
        sale.invoiceNumber.includes(q) ||
        sale.cashierName.toLowerCase().includes(q) ||
        (sale.customerName && sale.customerName.toLowerCase().includes(q)) ||
        sale.items.some((item) => item.productName.toLowerCase().includes(q));

      // Method match
      const matchMethod = methodFilter === 'all' || sale.paymentMethod === methodFilter;

      // Status match
      const isRefunded = sale.status === 'مرجوع شده';
      const matchStatus =
        statusFilter === 'all' ||
        (statusFilter === 'refunded' && isRefunded) ||
        (statusFilter === 'completed' && !isRefunded);

      return matchQuery && matchMethod && matchStatus;
    });
  }, [sales, searchHistoryQuery, methodFilter, statusFilter]);

  // Handle Refund
  const handleRefund = (sale: Sale, e: React.MouseEvent) => {
    e.stopPropagation();
    const confirmed = window.confirm(
      `آیا از مرجوع کردن فاکتور شماره #${toPersianDigits(sale.invoiceNumber)} و بازگشت اقلام به موجودی انبار اطمینان دارید؟`
    );
    if (confirmed) {
      StorageService.refundSale(sale.id);
      scannerService.playBeep('success');
      refreshData();
    }
  };

  // Handle Delete Proforma
  const handleDeleteProforma = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('آیا از حذف این پیش‌فاکتور اطمینان دارید؟')) {
      StorageService.deleteProforma(id);
      refreshData();
    }
  };

  const bestSellers = [
    { name: 'نوشابه کوکاکولا ۳۳۰ml', count: 322, sales: 14490000 },
    { name: 'چیپس نمکی لیز', count: 287, sales: 18655000 },
    { name: 'شیر کم‌چرب کاله', count: 195, sales: 10530000 },
    { name: 'نان تست طلایی', count: 168, sales: 5880000 },
    { name: 'آب معدنی ۱.۵ لیتری', count: 142, sales: 2840000 },
  ];

  return (
    <div className="space-y-5 max-w-7xl mx-auto pb-16">
      {/* Top Header */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />
            <span>گزارش‌ها، نمودارها و تاریخچه تراکنش‌ها</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            تحلیل هوشمند و ۳ بعدی فروش، سودآوری، پیش‌فاکتورها و سوابق مالی صندوق
          </p>
        </div>

        {/* Period Selector */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1.5 rounded-xl border border-slate-200">
          <button
            type="button"
            onClick={() => setPeriodFilter('today')}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              periodFilter === 'today' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            امروز
          </button>
          <button
            type="button"
            onClick={() => setPeriodFilter('week')}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              periodFilter === 'week' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            هفته جاری
          </button>
          <button
            type="button"
            onClick={() => setPeriodFilter('month')}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              periodFilter === 'month' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            ماه جاری
          </button>
        </div>
      </div>

      {/* Top Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400">فروش کل دوره‌ای</span>
            <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md">
              ۱۲٪+ نسبت به قبل
            </span>
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900 font-sans mt-2">
            {formatToman(totalSalesAmount)}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            تعداد {toPersianDigits(totalInvoicesCount)} تراکنش ثبت شده در سیستم
          </div>
        </div>

        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="text-xs font-bold text-slate-400">فروش دستگاه کارتخوان (POS)</div>
          <div className="text-xl sm:text-2xl font-black text-blue-600 font-sans mt-2">
            {formatToman(posPaymentsTotal || 820000)}
          </div>
          <div className="text-xs text-slate-400 mt-1">تراکنش‌های مستقیم پایانه فروش بانکی</div>
        </div>

        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="text-xs font-bold text-slate-400">دریافتی نقدی صندوق</div>
          <div className="text-xl sm:text-2xl font-black text-emerald-600 font-sans mt-2">
            {formatToman(cashPaymentsTotal || 216000)}
          </div>
          <div className="text-xs text-slate-400 mt-1">وجه نقد فیزیکی موجود در کشوی صندوق</div>
        </div>
      </div>

      {/* 3D Interactive Linear Chart Component */}
      <ThreeDLinearChart />

      {/* Products & Payment breakdown Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Best Sellers List */}
        <div className="lg:col-span-6 bg-white rounded-2xl border border-slate-200/80 p-4 sm:p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="font-black text-sm text-slate-900 flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-500" />
              <span>محصولات پرفروش</span>
            </h3>
            <span className="text-xs text-slate-400">بر اساس تعداد فروش</span>
          </div>

          <div className="space-y-2.5">
            {bestSellers.map((item, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50/70 border border-slate-100"
              >
                <div className="flex items-center gap-2.5">
                  <span className="w-6 h-6 rounded-lg bg-blue-100 text-blue-700 text-xs font-bold font-mono flex items-center justify-center">
                    {toPersianDigits(idx + 1)}
                  </span>
                  <div>
                    <h5 className="font-bold text-xs text-slate-800">{item.name}</h5>
                    <span className="text-[10px] text-slate-400">{formatToman(item.sales)} درآمد</span>
                  </div>
                </div>
                <div className="font-mono font-bold text-xs text-slate-700 bg-white px-2.5 py-1 rounded-lg border border-slate-200">
                  {toPersianDigits(item.count)} عدد
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Payment Gateways breakdown */}
        <div className="lg:col-span-6 bg-white rounded-2xl border border-slate-200/80 p-4 sm:p-5 shadow-xs space-y-4">
          <div className="pb-3 border-b border-slate-100">
            <h3 className="font-black text-sm text-slate-900 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-blue-600" />
              <span>تفکیک درگاه‌های دریافت وجه</span>
            </h3>
          </div>

          <div className="space-y-3 pt-1">
            <div className="p-3.5 bg-blue-50/60 rounded-xl border border-blue-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center">
                  <CreditCard className="w-4.5 h-4.5" />
                </div>
                <div>
                  <div className="font-bold text-xs text-slate-900">دستگاه کارتخوان (POS)</div>
                  <div className="text-[11px] text-slate-500">۸۸٪ کل تراکنش‌ها</div>
                </div>
              </div>
              <div className="font-sans font-black text-sm text-blue-900">
                {formatToman(posPaymentsTotal || 820000)}
              </div>
            </div>

            <div className="p-3.5 bg-emerald-50/60 rounded-xl border border-emerald-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center">
                  <Banknote className="w-4.5 h-4.5" />
                </div>
                <div>
                  <div className="font-bold text-xs text-slate-900">دریافتی نقدی (صندوق)</div>
                  <div className="text-[11px] text-slate-500">۱۲٪ کل تراکنش‌ها</div>
                </div>
              </div>
              <div className="font-sans font-black text-sm text-emerald-900">
                {formatToman(cashPaymentsTotal || 216000)}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Transaction History & Proforma Invoices Section */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-4 sm:p-5 shadow-xs space-y-4">
        {/* Section Tabs Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('sales')}
              className={`px-3.5 py-1.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'sales'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Receipt className="w-3.5 h-3.5" />
              <span>تاریخچه تراکنش‌ها و فروش ({toPersianDigits(sales.length)})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('proformas')}
              className={`px-3.5 py-1.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'proformas'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>پیش‌فاکتورهای چاپی ({toPersianDigits(proformas.length)})</span>
            </button>
          </div>

          {/* Quick Search */}
          <div className="relative w-full sm:w-64">
            <input
              type="text"
              placeholder="جستجو در سوابق..."
              value={searchHistoryQuery}
              onChange={(e) => setSearchHistoryQuery(e.target.value)}
              className="w-full pl-8 pr-8 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:border-blue-600 transition-all"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>

        {/* Tab 1: Sales / Transaction History */}
        {activeTab === 'sales' && (
          <div className="space-y-3">
            {/* Filters Bar */}
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-1.5">
                <span className="text-slate-400 font-medium">روش پرداخت:</span>
                <button
                  type="button"
                  onClick={() => setMethodFilter('all')}
                  className={`px-2 py-0.5 rounded-md cursor-pointer ${
                    methodFilter === 'all'
                      ? 'bg-slate-800 text-white font-bold'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  همه
                </button>
                <button
                  type="button"
                  onClick={() => setMethodFilter('کارتخوان')}
                  className={`px-2 py-0.5 rounded-md cursor-pointer ${
                    methodFilter === 'کارتخوان'
                      ? 'bg-blue-600 text-white font-bold'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  کارتخوان POS
                </button>
                <button
                  type="button"
                  onClick={() => setMethodFilter('نقدی')}
                  className={`px-2 py-0.5 rounded-md cursor-pointer ${
                    methodFilter === 'نقدی'
                      ? 'bg-emerald-600 text-white font-bold'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  نقدی
                </button>
              </div>

              <div className="flex items-center gap-1.5">
                <span className="text-slate-400 font-medium">وضعیت:</span>
                <button
                  type="button"
                  onClick={() => setStatusFilter('all')}
                  className={`px-2 py-0.5 rounded-md cursor-pointer ${
                    statusFilter === 'all'
                      ? 'bg-slate-800 text-white font-bold'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  همه
                </button>
                <button
                  type="button"
                  onClick={() => setStatusFilter('completed')}
                  className={`px-2 py-0.5 rounded-md cursor-pointer ${
                    statusFilter === 'completed'
                      ? 'bg-emerald-600 text-white font-bold'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  تکمیل شده
                </button>
                <button
                  type="button"
                  onClick={() => setStatusFilter('refunded')}
                  className={`px-2 py-0.5 rounded-md cursor-pointer ${
                    statusFilter === 'refunded'
                      ? 'bg-rose-600 text-white font-bold'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  مرجوع شده
                </button>
              </div>
            </div>

            {/* Invoices List */}
            <div className="divide-y divide-slate-100">
              {filteredSales.length > 0 ? (
                filteredSales.map((sale) => {
                  const isRefunded = sale.status === 'مرجوع شده';

                  return (
                    <div
                      key={sale.id}
                      onClick={() => setSelectedSaleForReceipt(sale)}
                      className={`py-3 px-2 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50 transition-colors cursor-pointer text-xs ${
                        isRefunded ? 'bg-rose-50/40 opacity-80' : ''
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="font-mono font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200">
                          #{toPersianDigits(sale.invoiceNumber)}
                        </span>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900">
                              {sale.items[0]?.productName || 'اقلام سفارش'}
                            </span>
                            {sale.items.length > 1 && (
                              <span className="text-slate-500 text-[10px] bg-slate-100 px-1.5 py-0.5 rounded">
                                +{toPersianDigits(sale.items.length - 1)} قلم
                              </span>
                            )}
                            {isRefunded && (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-rose-100 text-rose-700 border border-rose-200">
                                مرجوع شده
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                            {toPersianDigits(sale.date)} - ساعت {toPersianDigits(sale.time)} • صندوق‌دار: {sale.cashierName}
                            {sale.customerName && ` • مشتری: ${sale.customerName}`}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 self-end sm:self-auto shrink-0">
                        <span className="text-[11px] bg-slate-100 px-2 py-0.5 rounded-md text-slate-600 font-medium">
                          {sale.paymentMethod}
                        </span>

                        <span
                          className={`font-sans font-black text-sm ${
                            isRefunded ? 'line-through text-slate-400' : 'text-slate-900'
                          }`}
                        >
                          {formatToman(sale.finalTotal)}
                        </span>

                        {/* Actions */}
                        <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                          <button
                            type="button"
                            onClick={() => setSelectedSaleForReceipt(sale)}
                            className="p-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 transition-colors cursor-pointer"
                            title="مشاهده و چاپ فیش"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>

                          {!isRefunded && (
                            <button
                              type="button"
                              onClick={(e) => handleRefund(sale, e)}
                              className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 transition-colors cursor-pointer text-[11px] font-bold flex items-center gap-1"
                              title="مرجوع کردن فاکتور و بازگشت موجودی"
                            >
                              <RotateCcw className="w-3 h-3" />
                              <span className="hidden sm:inline">مرجوع</span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-8 text-slate-400 text-xs">
                  هیچ فاکتوری با فیلترهای انتخابی یافت نشد.
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 2: Proforma Invoices (پیش‌فاکتورها) */}
        {activeTab === 'proformas' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-500 bg-blue-50/50 border border-blue-100 p-2.5 rounded-xl">
              <span>
                پیش‌فاکتورها اسناد استعلام قیمت برای مشتریان هستند و بر موجودی انبار تأثیری ندارند.
              </span>
              <span className="font-bold text-blue-700 font-mono">
                {toPersianDigits(proformas.length)} پیش‌فاکتور ثبت شده
              </span>
            </div>

            <div className="divide-y divide-slate-100">
              {proformas.length > 0 ? (
                proformas.map((prof) => (
                  <div
                    key={prof.id}
                    onClick={() => setSelectedProforma(prof)}
                    className="py-3 px-2 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50 transition-colors cursor-pointer text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <span className="font-mono font-bold text-blue-800 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200">
                        {prof.proformaNumber}
                      </span>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900">
                            {prof.items[0]?.productName || 'اقلام استعلام'}
                          </span>
                          {prof.items.length > 1 && (
                            <span className="text-slate-500 text-[10px] bg-slate-100 px-1.5 py-0.5 rounded">
                              +{toPersianDigits(prof.items.length - 1)} قلم
                            </span>
                          )}
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200">
                            اعتبار تا: {prof.validUntil}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                          تاریخ صدور: {prof.issueDate} • مشتری: {prof.customerName || 'بدون نام'} • کارشناس: {prof.cashierName}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 self-end sm:self-auto shrink-0">
                      <span className="font-sans font-black text-sm text-blue-700">
                        {formatToman(prof.finalTotal)}
                      </span>

                      <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          onClick={() => setSelectedProforma(prof)}
                          className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-[11px] flex items-center gap-1 transition-colors cursor-pointer shadow-2xs"
                        >
                          <Printer className="w-3 h-3" />
                          <span>مشاهده و چاپ</span>
                        </button>

                        <button
                          type="button"
                          onClick={(e) => handleDeleteProforma(prof.id, e)}
                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-rose-50 hover:text-rose-600 text-slate-400 transition-colors cursor-pointer"
                          title="حذف پیش‌فاکتور"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-slate-400 text-xs">
                  هیچ پیش‌فاکتوری تاکنون ثبت نشده است. می‌توانید در بخش «صندوق» با دکمه «پیش‌فاکتور چاپی» فاکتور استعلام صادر فرمایید.
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Transaction Detail, Void & Print Modal */}
      <TransactionDetailModal
        isOpen={!!selectedSaleForReceipt}
        onClose={() => setSelectedSaleForReceipt(null)}
        sale={selectedSaleForReceipt}
        store={store}
        onSaleUpdated={refreshData}
      />

      {/* Proforma Modal */}
      <ProformaModal
        isOpen={!!selectedProforma}
        onClose={() => setSelectedProforma(null)}
        proforma={selectedProforma}
        store={store}
      />
    </div>
  );
};
