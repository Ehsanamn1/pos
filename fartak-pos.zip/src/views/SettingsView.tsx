import React, { useState } from 'react';
import { StoreInfo, UserAccount } from '../types';
import { StorageService } from '../services/storage';
import { toPersianDigits } from '../design-system/tokens';
import { Button } from '../design-system/components/Button';
import { Input } from '../design-system/components/Input';
import { Modal } from '../design-system/components/Modal';
import {
  Settings,
  Store,
  Users,
  Percent,
  Receipt,
  RotateCcw,
  ShieldCheck,
  UserPlus,
  CheckCircle2,
  Lock,
} from 'lucide-react';

interface SettingsViewProps {
  store: StoreInfo;
  onUpdateStore: (info: StoreInfo) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ store, onUpdateStore }) => {
  const [activeTab, setActiveTab] = useState<'store' | 'users' | 'advanced'>('store');
  const [storeForm, setStoreForm] = useState<StoreInfo>(store);
  const [users, setUsers] = useState<UserAccount[]>(() => StorageService.getUsers());
  const [isSavedMessage, setIsSavedMessage] = useState(false);

  // Add User Modal
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);
  const [newUserForm, setNewUserForm] = useState<{
    name: string;
    username: string;
    role: UserAccount['role'];
  }>({
    name: '',
    username: '',
    role: 'صندوقدار',
  });

  const handleSaveStore = (e: React.FormEvent) => {
    e.preventDefault();
    StorageService.saveStoreInfo(storeForm);
    onUpdateStore(storeForm);
    setIsSavedMessage(true);
    setTimeout(() => setIsSavedMessage(false), 3000);
  };

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserForm.name || !newUserForm.username) return;

    const created = StorageService.addUser({
      name: newUserForm.name,
      username: newUserForm.username,
      role: newUserForm.role,
      status: 'فعال',
    });

    setUsers(StorageService.getUsers());
    setIsAddUserOpen(false);
    setNewUserForm({ name: '', username: '', role: 'صندوقدار' });
  };

  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);

  const handleResetData = () => {
    StorageService.resetToDemoData();
    setIsResetConfirmOpen(false);
    window.location.reload();
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Settings className="w-6 h-6 text-blue-600" />
            <span>تنظیمات سیستم و پیکربندی فروشگاه</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            اطلاعات سربرگ فاکتور، نرخ مالیات ارزش افزوده، کاربران و سطوح دسترسی
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1.5 rounded-xl border border-slate-200">
          <button
            type="button"
            onClick={() => setActiveTab('store')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'store' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600'
            }`}
          >
            <Store className="w-3.5 h-3.5" />
            <span>اطلاعات فروشگاه</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('users')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'users' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>کاربران و دسترسی‌ها</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('advanced')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'advanced' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>تنظیمات پیشرفته</span>
          </button>
        </div>
      </div>

      {isSavedMessage && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3 rounded-xl text-xs flex items-center gap-2 animate-in fade-in duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>تغییرات با موفقیت ذخیره شد.</span>
        </div>
      )}

      {activeTab === 'store' && (
        <form onSubmit={handleSaveStore} className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-xs space-y-6">
          <h3 className="font-bold text-sm text-slate-900 pb-2 border-b border-slate-100 flex items-center gap-2">
            <Store className="w-4 h-4 text-blue-600" />
            <span>مشخصات سربرگ فاکتور و هویت فروشگاه</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="نام فروشگاه *"
              value={storeForm.name}
              onChange={(e) => setStoreForm({ ...storeForm, name: e.target.value })}
              required
            />
            <Input
              label="نام شعبه"
              value={storeForm.branch}
              onChange={(e) => setStoreForm({ ...storeForm, branch: e.target.value })}
            />
            <Input
              label="کد شعبه / فروشگاه"
              value={storeForm.code}
              onChange={(e) => setStoreForm({ ...storeForm, code: e.target.value })}
            />
            <Input
              label="شماره تلفن تماس"
              value={storeForm.phone}
              onChange={(e) => setStoreForm({ ...storeForm, phone: e.target.value })}
            />
            <div className="col-span-full">
              <Input
                label="آدرس دقیق فروشگاه (جهت درج در زیر فاکتور)"
                value={storeForm.address}
                onChange={(e) => setStoreForm({ ...storeForm, address: e.target.value })}
              />
            </div>
            <Input
              label="درصد مالیات و عوارض ارزش افزوده (VAT)"
              type="number"
              value={storeForm.taxRate}
              onChange={(e) => setStoreForm({ ...storeForm, taxRate: parseInt(e.target.value, 10) || 0 })}
              helperText="در صورت معافیت، عدد ۰ را وارد فرمایید."
            />
            <Input
              label="واحد پولی سیستم"
              value={storeForm.currency}
              onChange={(e) => setStoreForm({ ...storeForm, currency: e.target.value })}
            />
          </div>

          <div className="flex justify-end pt-4 border-t border-slate-100">
            <Button type="submit" variant="primary" icon={<CheckCircle2 className="w-4 h-4" />}>
              ذخیره تنظیمات فروشگاه
            </Button>
          </div>
        </form>
      )}

      {activeTab === 'users' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-slate-900">لیست پرسنل و سطوح دسترسی</h3>
              <p className="text-xs text-slate-500 mt-0.5">تعیین نقش‌های مدیریتی، صندوقداری و انبارداری</p>
            </div>
            <Button variant="primary" onClick={() => setIsAddUserOpen(true)} icon={<UserPlus className="w-4 h-4" />}>
              کاربر جدید
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {users.map((u) => (
              <div key={u.id} className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-xs flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
                    {(u?.name || 'ک').slice(0, 1)}
                  </div>
                  <div>
                    <h4 className="font-bold text-xs text-slate-900">{u?.name || 'کاربر'}</h4>
                    <div className="text-[11px] text-slate-400 font-mono mt-0.5">@{u?.username || 'user'}</div>
                  </div>
                </div>

                <div className="text-left">
                  <span className="text-xs font-bold bg-blue-50 text-blue-700 px-3 py-1 rounded-full">
                    {u.role}
                  </span>
                  <div className="text-[10px] text-slate-400 mt-1">
                    {u.role === 'مالک' && 'دسترسی کامل'}
                    {u.role === 'مدیر' && 'دسترسی مدیریتی'}
                    {u.role === 'صندوقدار' && 'فقط صدور فاکتور'}
                    {u.role === 'انباردار' && 'فقط ورود و خروج کالا'}
                    {u.role === 'حسابدار' && 'گزارش‌ها و تسویه‌ها'}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'advanced' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-xs space-y-6">
          <div className="space-y-2">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-rose-600" />
              <span>بازنشانی پایگاه داده به اطلاعات پیش‌فرض دمو</span>
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed max-w-xl">
              اگر می‌خواهید تمام کالاها، مشتریان و تراکنش‌های آزمایشی را پاک کرده و برنامه را مجدداً با اطلاعات اولیه نمونه فروشگاهی شارژ نمایید، دکمه زیر را بزنید.
            </p>
            <Button variant="danger" onClick={() => setIsResetConfirmOpen(true)} icon={<RotateCcw className="w-4 h-4" />}>
              بازنشانی داده‌های نمونه
            </Button>
          </div>
        </div>
      )}

      {/* Reset Confirmation Modal */}
      <Modal
        isOpen={isResetConfirmOpen}
        onClose={() => setIsResetConfirmOpen(false)}
        title="تأیید بازنشانی داده‌های فروشگاه"
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsResetConfirmOpen(false)}>
              انصراف
            </Button>
            <Button variant="danger" onClick={handleResetData} icon={<RotateCcw className="w-4 h-4" />}>
              بله، بازنشانی شود
            </Button>
          </>
        }
      >
        <p className="text-xs text-slate-600 leading-relaxed">
          آیا از بازنشانی داده‌های فروشگاه به مقادیر اولیه نمونه مطمئن هستید؟ با این کار داده‌های تستی ریست می‌شوند.
        </p>
      </Modal>

      {/* Add User Modal */}
      <Modal
        isOpen={isAddUserOpen}
        onClose={() => setIsAddUserOpen(false)}
        title="افزودن کاربر و صندوق‌دار جدید"
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsAddUserOpen(false)}>
              انصراف
            </Button>
            <Button variant="primary" onClick={handleAddUser} icon={<CheckCircle2 className="w-4 h-4" />}>
              ثبت کاربر
            </Button>
          </>
        }
      >
        <form onSubmit={handleAddUser} className="space-y-4">
          <Input
            label="نام و نام خانوادگی پرسنل *"
            placeholder="مثال: رضا احمدی"
            value={newUserForm.name}
            onChange={(e) => setNewUserForm({ ...newUserForm, name: e.target.value })}
            required
          />
          <Input
            label="نام کاربری لاگین *"
            placeholder="reza_pos"
            value={newUserForm.username}
            onChange={(e) => setNewUserForm({ ...newUserForm, username: e.target.value })}
            required
          />
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-700">سطح دسترسی و نقش:</label>
            <select
              value={newUserForm.role}
              onChange={(e) => setNewUserForm({ ...newUserForm, role: e.target.value as any })}
              className="w-full rounded-xl border border-slate-200 bg-white p-2.5 text-xs text-slate-800"
            >
              <option value="صندوقدار">صندوق‌دار (فروش و فاکتور)</option>
              <option value="انباردار">انباردار (کاردکس و موجودی)</option>
              <option value="حسابدار">حسابدار (گزارش و تسویه)</option>
              <option value="مدیر">مدیر فروشگاه</option>
            </select>
          </div>
        </form>
      </Modal>
    </div>
  );
};
